# Third-party source notices

- The I08 application source excerpts and snapshots are from [blhafner/scam-slayer](https://github.com/blhafner/scam-slayer), commit 0b09accf3a19bb9712b28e9c2044c7db05fec669. The [README at that commit](https://raw.githubusercontent.com/blhafner/scam-slayer/0b09accf3a19bb9712b28e9c2044c7db05fec669/README.md) declares MIT. The constructor artifact records the original source path and hashes. Source identifiers and available notices are retained.
- [Web3 Agent Lab V0.16.0](https://github.com/ZhanHaowen/Web3-Agent-Lab/releases/tag/V0.16.0) is a separate upstream runtime. The artifact pins its release and records its binary hashes. The release binaries are obtained from upstream.
- npm dependencies are named and locked in the relevant package-lock.json files and installed from their registries.
