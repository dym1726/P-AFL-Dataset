import { readFileSync, writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const dir = new URL('.', import.meta.url);
const data = JSON.parse(readFileSync(new URL('fig-intro-policy-data.json', dir), 'utf8'));
const requests = [
  ['Named spender', 'named', '0'],
  ['Named spender', 'named', '91'],
  ['Named spender', 'named', '36'],
  ['Second spender', 'second', '0'],
];
assert.equal(data.cases.length, 8);

const ink = '#182631', navy = '#1C567A', cyan = '#07A9E7';
const teal = '#006E59', mint = '#5CD4B1', green = '#22AD68';
const crimson = '#A92046', gold = '#FFBF32', gray = '#435662';
const rule = '#A3B2BC';
const art = [];

function esc(s) {
  return String(s).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
}
function t(x, y, label, size = 22, color = ink, weight = 400, anchor = 'start') {
  art.push('<text x="'+x+'" y="'+y+'" font-family="Arial, sans-serif" font-size="'+size+'" font-weight="'+weight+'" text-anchor="'+anchor+'" fill="'+color+'">'+esc(label)+'</text>');
}
function p(d, fill, stroke = 'none', width = 1) {
  art.push('<path d="'+d+'" fill="'+fill+'" stroke="'+stroke+'" stroke-width="'+width+'" stroke-linejoin="round" stroke-linecap="round"/>');
}
function rect(x,y,w,h,fill,stroke='none',r=0) {
  art.push('<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+h+'" rx="'+r+'" fill="'+fill+'" stroke="'+stroke+'" stroke-width="3"/>');
}
function circle(x,y,r,fill) {
  art.push('<circle cx="'+x+'" cy="'+y+'" r="'+r+'" fill="'+fill+'"/>');
}
function arrow(x1,x2,y,label) {
  p('M'+x1+' '+y+'H'+(x2-12),'none',ink,3);
  p('M'+(x2-13)+' '+(y-7)+'L'+x2+' '+y+'L'+(x2-13)+' '+(y+7)+'Z',ink);
  t((x1+x2)/2, y-15, label, 19, gray, 400, 'middle');
}
function sign(x,y,success,color) {
  circle(x,y,12,color);
  const d=success?'M'+(x-5)+' '+y+'l3.6 4 6.6-8':'M'+(x-4)+' '+(y-4)+'l8 8m0-8l-8 8';
  p(d,'none','#FFFFFF',2.3);
}
function label(x,title,detail,color=gray) {
  t(x,162,title,23,ink,700,'middle');
  t(x,192,detail,20,color,700,'middle');
}

rect(0,0,1260,590,'#FFFFFF');
t(16,34,'(a) From interface to token allowance',26,ink,700);
t(1244,33,'I08 revoke-only delegation',19,gray,400,'end');

// Application browser with a revoke control.
rect(79,62,92,68,'#E6F6FB',ink,7);
p('M80 82h90','none',ink,3);
p('M81 70q0-6 6-6h76q6 0 6 6v10H81z',cyan);
circle(91,72,2.6,'#FFFFFF'); circle(102,72,2.6,'#FFFFFF'); circle(113,72,2.6,'#FFFFFF');
circle(124,105,14,teal);
p('M117 105l5 5 9-10','none','#FFFFFF',2.7);

// Signed credential with an issue seal.
p('M418 60h44l18 18v54h-62z',cyan,navy,3);
p('M462 60v18h18','#B9ECFA',navy,2.6);
p('M429 88h35m-35 12h27m-27 12h19','none','#FFFFFF',3);
p('M472 112l4 23 8-5 8 5-1-23',navy);
circle(482,116,13,gold);

// Delegation manager and execution.
p('M775 58c10 8 24 13 37 14v21c0 20-15 33-37 42-23-9-38-22-38-42V72c15-1 27-7 38-14z',cyan);
circle(795,111,18,green);
p('M786 111l6 6 12-13','none','#FFFFFF',3);

// ERC-20 asset and storage.
p('M1100 60l39 21v39l-39 22-39-22V81z',mint,ink,3);
p('M1061 81l39 22 39-22m-39 22v39','none',ink,3);
p('M1080 70l39 22v19','none','#F4FFFF',3);
p('M1061 81l39 22v39l-39-22z','#219B87',ink,3);

arrow(186,400,102,'Construct');
arrow(505,721,102,'Redeem');
arrow(826,1045,102,'Execute as root');
label(125,'Application','Revoke only · q = 0',teal);
label(450,'Signed root grant','Amount check missing',crimson);
label(775,'Delegation manager','Checks signed conditions',navy);
label(1100,'ERC-20 token','Writes allowance',teal);
p('M16 216H1244','none',rule,1.5);

t(16,257,'(b) Matched constructor replay',26,ink,700);
t(1244,256,'Common start  ('+data.start.named+', '+data.start.second+')',21,navy,700,'end');

rect(16,277,329,51,'#E5EFF7');
rect(360,277,420,51,'#E5EFF7');
rect(795,277,449,51,'#DDF4EA');
t(29,298,'Approval request',22,navy,700);
t(29,319,'Spender and amount q',17,gray);
t(374,298,'Original signed grant',22,navy,700);
t(374,319,'Amount condition omitted',17,crimson);
t(809,298,'Patched signed grant',22,teal,700);
t(809,319,'Root requires q = 0',17,teal);
p('M16 332H1244','none',ink,2);

for(const [i,[name,spender,amount]] of requests.entries()){
  const y=361+i*46;
  t(29,y,name,22,ink);
  t(330,y,'q = '+amount,22,navy,700,'end');
  for(const [j,variant] of ['original','patched'].entries()){
    const found=data.cases.filter(row=>row.variant===variant&&row.spender===spender&&row.amount===amount);
    assert.equal(found.length,1,[variant,spender,amount].join('/'));
    const row=found[0];
    const success=row.receipt==='Success';
    const outside=success&&row.amount!=='0';
    const col=j===0?{x:360,w:420}:{x:795,w:449};
    if(outside){
      rect(col.x,y-23,col.w,34,'#F9E5E9');
      p('M'+col.x+' '+(y-23)+'v34','none',crimson,3);
    }
    sign(col.x+31,y-7,success,outside?crimson:success?teal:navy);
    t(col.x+col.w-20,y,'('+row.final.named+', '+row.final.second+')',24,outside?crimson:ink,700,'end');
  }
  p('M16 '+(y+13)+'H1244','none',i===3?ink:rule,i===3?2.1:1);
}

sign(29,555,true,teal);
t(49,562,'Successful receipt',18,gray);
sign(243,555,false,navy);
t(263,562,'Included revert',18,gray);
rect(441,544,22,20,'#F9E5E9');
p('M441 544v20','none',crimson,3);
t(474,562,'Out-of-policy approval',18,crimson,700);
t(1244,562,'Final (named, second) allowances in base units',18,gray,400,'end');

const svg='<svg xmlns="http://www.w3.org/2000/svg" width="504pt" height="236pt" viewBox="0 0 1260 590">\n'+art.join('\n')+'\n</svg>\n';
writeFileSync(new URL('fig-intro-policy.svg', dir),svg,'utf8');
