# I08 revocation-only delegation artifact

This repository contains experimental code, saved receipts, allowance and balance reads, and offline checks for the I08 study. Transactions use local test accounts and contracts. The archived transaction counts exclude deployment and seeding unless a record says otherwise.

## Directory map

| Location | Contents |
| --- | --- |
| experiments/constructor | Original and patched constructor replay, pinned source excerpts, dependency lock, eight included receipts, and verifier |
| experiments/signed-delegation/signed-manager | Signed-path harness, locked dependencies, 390 single requests, five management transactions, 20 ordered batches, and verifier |
| experiments/signed-delegation/lab-wallet | Stock fixed-amount versus revoke-only wallet adapter, 15 cases, raw receipts and allowance queries, and verifier |
| historical/direct-manager | Earlier local manager and constructor controls, source scan code, pinned runtime, JSON/CSV and offline verifier |
| historical/direct-manager-extended | The manuscript’s 16-case direct-manager JSON and CSV plus the corresponding replay script |
| historical/browser | Instrumented browser runner, local harness, captured signing and transaction record, source snapshots and test reports |
| historical/repository-screen | 47-snapshot screening data, manual dispositions, AST analyzer, C01 reproduction scripts and records, and fix prototypes |
| historical/reported-only | Reported manuscript outcomes and names of unrecovered older raw files |

The Lab wallet directory appears once. It matches the stand-alone wallet archive byte for byte.

## Verify the saved records

Use Python 3.10 or later. From the repository root run:

    python scripts/verify_artifact.py

This checks SHA256SUMS.txt and runs four archived offline verifiers. A separate comparison reconciles the recovered 16-case JSON and CSV. The older direct-manager verifier checks eight specified outcomes against its own archive. Offline checks inspect saved records. Native replay creates a new run.

## Rerun the three core experiments

Use the official [Web3 Agent Lab V0.16.0 Windows x64 release](https://github.com/ZhanHaowen/Web3-Agent-Lab/releases/tag/V0.16.0). The portable ZIP SHA-256 is:

    289ffd557c417f22a72ab3b19589f37e999bd7d2c9129dca098d06cecde19609

Extract it to a short path such as C:/Web3Lab. The scripts use the bundled Node, Anvil and server module. No model weights are needed. Use a fresh output directory for every rerun. The original local replay was tested on Windows x64.

From experiments/constructor in PowerShell:

    npm ci --no-audit --no-fund --ignore-scripts
    & 'C:/Web3Lab/runtime/node.exe' ./run-constructor.mjs C:/Web3Lab C:/Web3Lab/runtime/anvil.exe ./rerun
    python ./verify-constructor.py ./rerun/experiment.json

From experiments/signed-delegation/signed-manager:

    npm ci --no-audit --no-fund --ignore-scripts
    & 'C:/Web3Lab/runtime/node.exe' ./run-signed.mjs C:/Web3Lab C:/Web3Lab/runtime/anvil.exe ./rerun
    python ./verify-signed.py ./rerun --write

From experiments/signed-delegation/lab-wallet:

    & 'C:/Web3Lab/runtime/node.exe' ./run-allowances.mjs C:/Web3Lab C:/Web3Lab/runtime/anvil.exe ./rerun
    python ./verify-evidence.py ./rerun --write

Transactions and block hashes can differ across reruns. Compare the requested fields, receipts, event sequences and state changes. The harnesses use public local-development fixture accounts on chain 31337.

## Regenerate Figure 1

Run node figures/figure-1/draw-intro-policy.mjs to reproduce the SVG from the eight receipt-derived rows. The JSON records the source experiment hash and the transaction IDs.

## Earlier runs

The portable direct-manager workflow is documented in historical/direct-manager/README.md. The browser and C01 folders preserve the earlier harnesses and saved evidence. Their local module and output paths have been made configurable. See historical/README.md for setup and evidence boundaries. The old browser replay and the older local Alto replay are separate experiments.

Source attribution and collection details are in THIRD_PARTY_NOTICES.md and historical/README.md.
