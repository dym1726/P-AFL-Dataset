from csv import DictReader
from hashlib import sha256
import json
from pathlib import Path
from subprocess import run
import sys

root = Path(__file__).resolve().parents[1]
manifest = root / "SHA256SUMS.txt"
checks = manifest.read_text(encoding="utf-8").splitlines()

for entry in checks:
    digest, name = entry.split("  ", 1)
    path = root / name
    if sha256(path.read_bytes()).hexdigest() != digest:
        raise SystemExit(f"Checksum mismatch: {name}")

print(f"Verified {len(checks)} file checksums.", flush=True)
runs = [
    ("experiments/constructor", "verify-constructor.py", "experiment.json"),
    ("experiments/signed-delegation", "signed-manager/verify-signed.py", "signed-manager/evidence"),
    ("experiments/signed-delegation/lab-wallet", "verify-evidence.py", "."),
    ("historical/direct-manager", "tools/verify-results.py"),
]
for directory, *command in runs:
    print(f"Checking {directory}", flush=True)
    run([sys.executable, *command], cwd=root / directory, check=True)

extended = root / "historical" / "direct-manager-extended" / "evidence"
cases = json.loads((extended / "manager-experiment.json").read_text(encoding="utf-8"))["results"]
with (extended / "manager-scenarios.csv").open(encoding="utf-8", newline="") as stream:
    rows = list(DictReader(stream))
assert len(cases) == len(rows) == 16
fields = ("name", "status", "transactionHash", "initialAllowance", "finalAllowance", "logCount")
for case, row in zip(cases, rows):
    for field in fields:
        assert str(case[field]) == row[field], (case["name"], field)
assert len({case["transactionHash"] for case in cases}) == 16
reverted = [case for case in cases if case["status"] == "reverted"]
assert sum(case["status"] == "success" for case in cases) == 9
assert len(reverted) == 7
assert all(case["initialAllowance"] == case["finalAllowance"] and case["logCount"] == 0 for case in reverted)
print("Verified the 16-case direct-manager JSON/CSV pair.")
print("All four archived evidence verifiers and the extended record check passed.")
