# Earlier results with incomplete raw records

These are reported outcomes from the manuscript, with evidence boundaries preserved. The individual raw files listed below were not recovered in the workspace search.

| Older run | Retained report | Expected raw records |
| --- | --- | --- |
| I08 local Hybrid / Alto | Original revoke cleared to 0. Original positive request succeeded and set 91. Repaired revoke cleared to 0. Repaired positive request failed at estimation and left 37, without an included receipt. | evidence/v07-i08/trial-07-alto018/results.json and run.json |
| Generic paired relation | 27 requests. Independent sets produced 12 effects (10 outside the intended relation). One recipient produced four effects (three outside, one intended effect missed). Grouped and exact grants each produced two intended effects. | evidence/v02-redemption/histories.json, decisions.csv and controls.csv |
| Ucanto and Biscuit | Two policy profiles over 27 requests per system. Each admitted two paired-policy and 12 product-policy requests, including ten outside the intended relation. | evidence/v02-ucanto-relation/ and evidence/v03-biscuit/ |
| Stateful controls | Eight positive requests rejected in the owner-alignment fixture. The eight zero requests partitioned into four rejected, one successful without clearing a positive allowance, and three clearings. Separate nonce and quota controls are described in the manuscript. | evidence/v03-stateful/histories.json, approval.csv, once.csv and quota.csv |
| Earlier integration pool and controls | The manuscript reports a separate 33-repository pool, I03's two-call control and I32's 12 expected effects and 15 rejected requests. | evidence/v02-integrations/, evidence/v07-i03/exact-token/ and evidence/v03-i32/ |

These summaries do not substitute for receipts, replay harnesses, or machine-readable per-case records. The three core replay suites and the recovered historical browser, direct-manager and repository-screen files have their own directories.
