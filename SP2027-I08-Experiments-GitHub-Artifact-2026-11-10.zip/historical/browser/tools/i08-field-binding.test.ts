import { describe, expect, it } from "vitest";
import { getSmartAccountsEnvironment } from "@metamask/smart-accounts-kit";
import { sepolia } from "viem/chains";
import {
  createAgentDelegation,
  setActiveChain,
} from "./wallet";

describe("I08 constructor field binding", () => {
  it("emits target, selector, and value limits without spender or amount binding", async () => {
    setActiveChain(sepolia.id);
    const environment = getSmartAccountsEnvironment(sepolia.id);
    const names = new Map(
      Object.entries(environment.caveatEnforcers).map(([name, address]) => [
        address.toLowerCase(),
        name,
      ]),
    );

    const operator = {
      address: "0x1000000000000000000000000000000000000001" as const,
      signDelegation: async () => "0x1234" as const,
    };
    const delegation = await createAgentDelegation(
      operator,
      "0x1000000000000000000000000000000000000002",
      {
        allowedTargets: [
          "0x036CbD53842c5426634e7929541eC2318f3dCF7e",
        ],
        maxCalls: 10,
        expiryDays: 30,
      },
    );

    const caveatNames = delegation.caveats.map(
      (caveat) => names.get(caveat.enforcer.toLowerCase()) ?? "Unknown",
    );

    expect(caveatNames).toEqual([
      "AllowedTargetsEnforcer",
      "AllowedMethodsEnforcer",
      "ValueLteEnforcer",
      "LimitedCallsEnforcer",
      "TimestampEnforcer",
    ]);
    expect(caveatNames).not.toContain("AllowedCalldataEnforcer");
    expect(caveatNames).not.toContain("ApprovalRevocationEnforcer");
    expect(caveatNames).not.toContain("ExactExecutionEnforcer");
    expect(delegation.caveats[0].terms.toLowerCase()).toBe(
      "0x036cbd53842c5426634e7929541ec2318f3dcf7e",
    );
    expect(delegation.caveats[1].terms.toLowerCase()).toBe("0x095ea7b3");
  });
});
