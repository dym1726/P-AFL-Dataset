import { Buffer } from "buffer";
import { createRoot } from "react-dom/client";
import { overrideDeployedEnvironment } from "@metamask/smart-accounts-kit/utils";

(globalThis as any).Buffer = (globalThis as any).Buffer || Buffer;
(globalThis as any).process = (globalThis as any).process || { env: {} };

const environment = (window as any).__I08_ENVIRONMENT__;
if (!environment) {
  throw new Error("I08 local environment was not injected");
}
overrideDeployedEnvironment(11155111, "1.3.0", environment);

const { default: App } = await import("./App");
createRoot(document.getElementById("root")!).render(<App />);
