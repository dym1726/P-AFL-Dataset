# Historical artifact records

## Earlier I08 and browser paths

The direct-manager folder is the retained portable experiment package. Its README pins the application revision and explains how to replay the local manager controls and scanner. The browser folder preserves the separate instrumented browser experiment. For a new browser run, prepare a disposable checkout at the pinned application revision, install its original locked dependencies, copy browser/browser-test.html to the checkout root, browser/src/test-browser-main.tsx to the checkout's src/ directory, and tools/i08-browser-experiment.mjs to its tools/ directory. Install playwright-core in the checkout. Install the locked Ganache/Solidity runtime with:

    npm ci --prefix historical/direct-manager/tools/runtime --ignore-scripts --no-audit --no-fund

Set I08_RUNTIME_ROOT to that runtime directory. The browser runner uses Edge by default and accepts I08_EDGE_EXE for the executable path. Invoke the script from the disposable checkout. The injected local signer and relay replace ordinary browser and submission components. The browser GUI may label the fixture chain Sepolia because the runner uses that chain ID with a loopback provider. The browser path is separate from the historical Alto experiment. The retained browser evidence was checked as an archive. Its relocated runner was syntax-checked.

## Repository screen and C01

evidence/repository-dispositions.csv records 47 snapshots. ground-truth.csv contains manual annotations. funnel.json and repository-disposition-summary.json retain separate denominators. The C01 JSON files contain the original constructor output and the seven local manager scenarios. I08 is the confirmed local application mismatch. C01 remains policy unresolved.

The analyzer accepts --corpus, --scan, --manual and --out-dir arguments. The fixed scan and manual-review inputs are in ../direct-manager/evidence/. Use a separate output directory. The 47 upstream repositories are inputs to the scanner. Their names and pinned revisions are in the archived metadata.

For C01, install the archived application dependencies and shared runtime:

    npm ci --prefix historical/repository-screen/evidence/c01-dependencies --ignore-scripts --no-audit --no-fund
    npm ci --prefix historical/direct-manager/tools/runtime --ignore-scripts --no-audit --no-fund

The C01 scripts default to those two locations. They accept C01_DEPENDENCY_ROOT and I08_RUNTIME_ROOT and write new outputs to historical/repository-screen/reruns/. The relocated scripts were syntax-checked. Their archived results come from the original runs.

## Collection notes

The direct-manager package and three core experiment directories preserve their archived bytes. The browser and repository-screen subtrees use selected files from the original FieldBinding Artifact and FieldCompleteness Prep archives. The copied test reports and screening metadata use relative paths in place of workstation-only path fields. Receipt records, allowances, decisions, transaction hashes and case counts are preserved. The redistributed historical runners change only dependency lookup and output locations. The original archive filenames and digests are listed in source-archives.json.

Working disclosure drafts and the downloaded public build bundles are separate from the experiment package. The saved app-path evidence retains the build provenance and hash information. The 47 upstream repository trees can be retrieved from the pinned metadata with the historical corpus script.
