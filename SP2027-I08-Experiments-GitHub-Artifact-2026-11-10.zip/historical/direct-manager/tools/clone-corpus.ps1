$ErrorActionPreference = "Stop"

$artifactRoot = Split-Path -Parent $PSScriptRoot
$searchPath = Join-Path $artifactRoot "evidence/github-search.json"
$scanPath = Join-Path $artifactRoot "evidence/integration-scan.json"
$corpusRoot = Join-Path $artifactRoot "corpus"
$search = Get-Content -Raw -LiteralPath $searchPath | ConvertFrom-Json
$commits = @{}
if (Test-Path -LiteralPath $scanPath) {
    $scan = Get-Content -Raw -LiteralPath $scanPath | ConvertFrom-Json
    foreach ($record in $scan.records) {
        $commits[$record.repo] = $record.commit
    }
}

New-Item -ItemType Directory -Force -Path $corpusRoot | Out-Null

$search.items | ForEach-Object {
    $repo = $_.full_name
    $key = $repo -replace "/", "__"
    $dest = Join-Path $corpusRoot $key
    if (-not (Test-Path -LiteralPath $dest)) {
        git -c http.proxy= -c https.proxy= clone --depth 1 --single-branch `
            ("https://github.com/" + $repo + ".git") $dest
    }
    $commit = $commits[$key]
    if ($commit) {
        git -C $dest fetch --depth 1 origin $commit | Out-Null
        git -C $dest checkout --detach $commit | Out-Null
    }
    [pscustomobject]@{
        repo = $repo
        cloned = Test-Path -LiteralPath (Join-Path $dest ".git")
        commit = $commit
    }
} | Sort-Object repo | Format-Table -AutoSize
