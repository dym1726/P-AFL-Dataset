import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import {
  createPublicClient,
  createWalletClient,
  custom,
  bytesToHex,
  encodeAbiParameters,
  encodeFunctionData,
  pad,
  parseAbi,
  toHex,
} from "viem";
import { mnemonicToAccount } from "viem/accounts";
import { sepolia } from "viem/chains";
import {
  ExecutionMode,
  Implementation,
  createDelegation,
  createExecution,
  getSmartAccountsEnvironment,
  signDelegation,
  toMetaMaskSmartAccount,
} from "@metamask/smart-accounts-kit";
import {
  createCaveatBuilder,
  deploySmartAccountsEnvironment,
  overrideDeployedEnvironment,
} from "@metamask/smart-accounts-kit/utils";
import { DelegationManager } from "@metamask/smart-accounts-kit/contracts";

process.env.DO_NOT_TRACK = "1";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(new URL("./runtime/package.json", import.meta.url));
const ganache = require("ganache");
const solc = require("solc");

const mnemonic =
  "test test test test test test test test test test test junk";
const chainId = sepolia.id;
const tempRoot = process.env.TEMP || os.tmpdir();
const runDir = fs.mkdtempSync(path.join(tempRoot, "i08-manager-"));
const dbPath = path.join(runDir, "ganache-chain");
const outputPath = path.resolve(
  __dirname,
  "../artifacts/manager-experiment.json",
);

const tokenSource = `
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;

contract AuditToken {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    event Approval(address indexed owner, address indexed spender, uint256 value);
    event Transfer(address indexed from, address indexed to, uint256 value);

    constructor() {
        balanceOf[msg.sender] = 1_000_000;
        emit Transfer(address(0), msg.sender, 1_000_000);
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        require(balanceOf[msg.sender] >= amount, "balance");
        balanceOf[msg.sender] -= amount;
        balanceOf[to] += amount;
        emit Transfer(msg.sender, to, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        require(allowance[from][msg.sender] >= amount, "allowance");
        require(balanceOf[from] >= amount, "balance");
        allowance[from][msg.sender] -= amount;
        balanceOf[from] -= amount;
        balanceOf[to] += amount;
        emit Transfer(from, to, amount);
        return true;
    }

    function setAllowance(address owner, address spender, uint256 amount) external {
        allowance[owner][spender] = amount;
        emit Approval(owner, spender, amount);
    }

    function setBalance(address owner, uint256 amount) external {
        balanceOf[owner] = amount;
    }
}
`;

function compileToken() {
  const input = {
    language: "Solidity",
    sources: { "AuditToken.sol": { content: tokenSource } },
    settings: {
      optimizer: { enabled: true, runs: 200 },
      outputSelection: {
        "*": { "*": ["abi", "evm.bytecode.object"] },
      },
    },
  };
  const output = JSON.parse(solc.compile(JSON.stringify(input)));
  const errors = (output.errors ?? []).filter(
    (entry) => entry.severity === "error",
  );
  if (errors.length) {
    throw new Error(errors.map((entry) => entry.formattedMessage).join("\n"));
  }
  const contract = output.contracts["AuditToken.sol"].AuditToken;
  return {
    abi: contract.abi,
    bytecode: `0x${contract.evm.bytecode.object}`,
  };
}

const tokenArtifact = compileToken();
const tokenAbi = tokenArtifact.abi;
const approveAbi = parseAbi([
  "function approve(address spender, uint256 amount) returns (bool)",
]);
const amountZero = encodeAbiParameters([{ type: "uint256" }], [0n]);

const provider = ganache.provider({
  chain: {
    chainId,
    networkId: chainId,
    hardfork: "shanghai",
  },
  wallet: {
    mnemonic,
    totalAccounts: 12,
    defaultBalance: 1000,
  },
  miner: {
    blockGasLimit: 30_000_000,
    callGasLimit: 50_000_000,
  },
  database: { dbPath },
  logging: { quiet: true },
});

const admin = mnemonicToAccount(mnemonic, { addressIndex: 0 });
const operatorOwner = mnemonicToAccount(mnemonic, { addressIndex: 1 });
const coordinatorOwner = mnemonicToAccount(mnemonic, { addressIndex: 2 });
const revoker = mnemonicToAccount(mnemonic, { addressIndex: 3 });
const originalSpender = mnemonicToAccount(mnemonic, { addressIndex: 4 });
const attackerSpender = mnemonicToAccount(mnemonic, { addressIndex: 5 });

const publicClient = createPublicClient({
  chain: sepolia,
  transport: custom(provider),
});
const walletClient = createWalletClient({
  chain: sepolia,
  transport: custom(provider),
  account: admin,
});

async function wait(hash) {
  return publicClient.waitForTransactionReceipt({ hash });
}

async function deployHybrid(owner, salt) {
  const account = await toMetaMaskSmartAccount({
    client: publicClient,
    implementation: Implementation.Hybrid,
    deployParams: [owner.address, [], [], []],
    deploySalt: salt,
    signer: { account: owner },
  });
  if (!(await account.isDeployed())) {
    const { factory, factoryData } = await account.getFactoryArgs();
    const hash = await walletClient.sendTransaction({
      to: factory,
      data: factoryData,
    });
    await wait(hash);
  }
  if (!(await account.isDeployed())) {
    throw new Error(`Hybrid account not deployed: ${account.address}`);
  }
  return account;
}

function makeCaveats(expiresAt) {
  return createCaveatBuilder(getSmartAccountsEnvironment(chainId))
    .addCaveat("limitedCalls", { limit: 10 })
    .addCaveat("timestamp", {
      afterThreshold: 0,
      beforeThreshold: expiresAt,
    })
    .build();
}

function makeRoot({
  operator,
  coordinator,
  token,
  expiresAt,
  salt,
  caveats,
}) {
  return createDelegation({
    environment: getSmartAccountsEnvironment(chainId),
    from: operator.address,
    to: coordinator.address,
    salt,
    scope: {
      type: "functionCall",
      targets: [token],
      selectors: ["approve(address,uint256)"],
    },
    caveats: [...makeCaveats(expiresAt), ...caveats],
  });
}

function makeChild({ coordinator, revoker, parentDelegation, salt }) {
  return createDelegation({
    environment: getSmartAccountsEnvironment(chainId),
    from: coordinator.address,
    to: revoker,
    parentDelegation,
    salt,
    caveats: createCaveatBuilder(getSmartAccountsEnvironment(chainId))
      .addCaveat("limitedCalls", { limit: 5 })
      .build(),
  });
}

async function signChain({
  operatorAccount,
  coordinatorAccount,
  token,
  expiresAt,
  scenarioIndex,
  extraRootCaveats,
}) {
  const environment = getSmartAccountsEnvironment(chainId);
  const root = makeRoot({
    operator: operatorAccount,
    coordinator: coordinatorAccount,
    token,
    expiresAt,
    salt: toHex(scenarioIndex, { size: 32 }),
    caveats: extraRootCaveats,
  });
  if (!root.delegate || !root.delegator) {
    throw new Error(`Malformed root delegation: ${JSON.stringify(root)}`);
  }
  if (root.caveats.some((caveat) => !caveat?.enforcer)) {
    throw new Error(
      `Malformed root caveats: ${JSON.stringify(root.caveats, null, 2)}`,
    );
  }
  const operatorKey = bytesToHex((await operatorOwner.getHdKey()).privKeyBytes);
  const coordinatorKey = bytesToHex(
    (await coordinatorOwner.getHdKey()).privKeyBytes,
  );
  const rootSignature = await signDelegation({
    privateKey: operatorKey,
    delegation: root,
    delegationManager: environment.DelegationManager,
    chainId,
  });
  const signedRoot = { ...root, signature: rootSignature };
  const child = makeChild({
    coordinator: coordinatorAccount,
    revoker: revoker.address,
    parentDelegation: signedRoot,
    salt: toHex(scenarioIndex + 100, { size: 32 }),
  });
  if (!child.delegate || !child.delegator) {
    throw new Error(`Malformed child delegation: ${JSON.stringify(child)}`);
  }
  if (child.caveats.some((caveat) => !caveat?.enforcer)) {
    throw new Error(
      `Malformed child caveats: ${JSON.stringify(child.caveats, null, 2)}`,
    );
  }
  const childSignature = await signDelegation({
    privateKey: coordinatorKey,
    delegation: child,
    delegationManager: environment.DelegationManager,
    chainId,
  });
  return [{ ...child, signature: childSignature }, signedRoot];
}

async function runScenario({
  name,
  operatorAccount,
  coordinatorAccount,
  token,
  expiresAt,
  scenarioIndex,
  extraRootCaveats,
  spender,
  amount,
  initialAllowance,
  testTransfer = false,
}) {
  await wait(
    await walletClient.writeContract({
      address: token,
      abi: tokenAbi,
      functionName: "setAllowance",
      args: [operatorAccount.address, spender.address, initialAllowance],
      account: admin,
    }),
  );
  const initial = await publicClient.readContract({
    address: token,
    abi: tokenAbi,
    functionName: "allowance",
    args: [operatorAccount.address, spender.address],
  });
  await wait(
    await walletClient.writeContract({
      address: token,
      abi: tokenAbi,
      functionName: "setBalance",
      args: [operatorAccount.address, 1_000n],
      account: admin,
    }),
  );

  const chain = await signChain({
    operatorAccount,
    coordinatorAccount,
    token,
    expiresAt,
    scenarioIndex,
    extraRootCaveats,
  });
  const callData = encodeFunctionData({
    abi: approveAbi,
    functionName: "approve",
    args: [spender.address, amount],
  });
  const execution = createExecution({
    target: token,
    value: 0n,
    callData,
  });
  const redeemData = DelegationManager.encode.redeemDelegations({
    delegations: [chain],
    modes: [ExecutionMode.SingleDefault],
    executions: [[execution]],
  });

  let status;
  let receipt = null;
  let error = null;
  try {
    const hash = await walletClient.sendTransaction({
      account: revoker,
      to: getSmartAccountsEnvironment(chainId).DelegationManager,
      data: redeemData,
      gas: 5_000_000n,
    });
    receipt = await wait(hash);
    status = receipt.status;
  } catch (caught) {
    status = "submission_error";
    error = {
      name: caught.name,
      message: caught.message,
      shortMessage: caught.shortMessage ?? null,
      details: caught.details ?? null,
      cause: caught.cause
        ? {
            name: caught.cause.name,
            message: caught.cause.message,
            shortMessage: caught.cause.shortMessage ?? null,
            details: caught.cause.details ?? null,
            reason: caught.cause.reason ?? null,
            data: caught.cause.data ?? null,
          }
        : null,
    };
  }

  const finalAllowance = await publicClient.readContract({
    address: token,
    abi: tokenAbi,
    functionName: "allowance",
    args: [operatorAccount.address, spender.address],
  });
  let transfer = null;
  if (testTransfer && status === "success") {
    const transferBefore = await publicClient.readContract({
      address: token,
      abi: tokenAbi,
      functionName: "balanceOf",
      args: [spender.address],
    });
    const transferHash = await walletClient.writeContract({
      account: spender,
      address: token,
      abi: tokenAbi,
      functionName: "transferFrom",
      args: [operatorAccount.address, spender.address, 55n],
    });
    const transferReceipt = await wait(transferHash);
    const transferAfter = await publicClient.readContract({
      address: token,
      abi: tokenAbi,
      functionName: "balanceOf",
      args: [spender.address],
    });
    transfer = {
      amount: "55",
      status: transferReceipt.status,
      transactionHash: transferReceipt.transactionHash,
      blockNumber: transferReceipt.blockNumber.toString(),
      spenderBalanceBefore: transferBefore.toString(),
      spenderBalanceAfter: transferAfter.toString(),
    };
  }
  const root = chain.at(-1);
  const child = chain[0];
  return {
    name,
    spender: spender.address,
    amount: amount.toString(),
    initialAllowance: initial.toString(),
    finalAllowance: finalAllowance.toString(),
    status,
    transactionHash: receipt?.transactionHash ?? null,
    blockNumber: receipt?.blockNumber?.toString() ?? null,
    gasUsed: receipt?.gasUsed?.toString() ?? null,
    logCount: receipt?.logs?.length ?? null,
    rootCaveatNames: root.caveats.map((caveat) =>
      Object.entries(getSmartAccountsEnvironment(chainId).caveatEnforcers).find(
        ([, address]) =>
          address.toLowerCase() === caveat.enforcer.toLowerCase(),
      )?.[0],
    ),
    rootCaveatTerms: root.caveats.map((caveat) => ({
      enforcer: caveat.enforcer,
      terms: caveat.terms,
      args: caveat.args,
    })),
    childCaveatNames: child.caveats.map((caveat) =>
      Object.entries(getSmartAccountsEnvironment(chainId).caveatEnforcers).find(
        ([, address]) =>
          address.toLowerCase() === caveat.enforcer.toLowerCase(),
      )?.[0],
    ),
    execution: {
      target: execution.target,
      value: execution.value.toString(),
      callData: execution.callData,
    },
    redeemCalldata: redeemData,
    transfer,
    error,
  };
}

let results = [];
let metadata;
try {
  const environment = await deploySmartAccountsEnvironment(
    walletClient,
    publicClient,
    sepolia,
  );
  overrideDeployedEnvironment(chainId, "1.3.0", environment);

  const operatorAccount = await deployHybrid(operatorOwner, "0x11");
  const coordinatorAccount = await deployHybrid(coordinatorOwner, "0x22");
  const tokenDeployment = await walletClient.deployContract({
    abi: tokenAbi,
    bytecode: tokenArtifact.bytecode,
    args: [],
  });
  const tokenReceipt = await wait(tokenDeployment);
  const token = tokenReceipt.contractAddress;
  if (!token) throw new Error("Token deployment produced no address");

  const amountCaveat = createCaveatBuilder(environment)
    .addCaveat("allowedCalldata", {
      startIndex: 36,
      value: amountZero,
    })
    .build()[0];
  const spenderCaveat = createCaveatBuilder(environment)
    .addCaveat("allowedCalldata", {
      startIndex: 4,
      value: pad(originalSpender.address),
    })
    .build()[0];
  const expiresAt = Math.floor(Date.now() / 1000) + 30 * 86400;

  results = [
    await runScenario({
      name: "original_known_spender_revoke",
      operatorAccount,
      coordinatorAccount,
      token,
      expiresAt,
      scenarioIndex: 1,
      extraRootCaveats: [],
      spender: originalSpender,
      amount: 0n,
      initialAllowance: 37n,
    }),
    await runScenario({
      name: "original_known_spender_nonzero",
      operatorAccount,
      coordinatorAccount,
      token,
      expiresAt,
      scenarioIndex: 2,
      extraRootCaveats: [],
      spender: originalSpender,
      amount: 91n,
      initialAllowance: 37n,
    }),
    await runScenario({
      name: "original_attacker_spender_nonzero",
      operatorAccount,
      coordinatorAccount,
      token,
      expiresAt,
      scenarioIndex: 3,
      extraRootCaveats: [],
      spender: attackerSpender,
      amount: 91n,
      initialAllowance: 37n,
      testTransfer: true,
    }),
    await runScenario({
      name: "amount_bound_attacker_spender_zero",
      operatorAccount,
      coordinatorAccount,
      token,
      expiresAt,
      scenarioIndex: 4,
      extraRootCaveats: [amountCaveat],
      spender: attackerSpender,
      amount: 0n,
      initialAllowance: 37n,
    }),
    await runScenario({
      name: "amount_bound_attacker_spender_nonzero",
      operatorAccount,
      coordinatorAccount,
      token,
      expiresAt,
      scenarioIndex: 5,
      extraRootCaveats: [amountCaveat],
      spender: attackerSpender,
      amount: 91n,
      initialAllowance: 37n,
    }),
    await runScenario({
      name: "spender_bound_attacker_spender_nonzero",
      operatorAccount,
      coordinatorAccount,
      token,
      expiresAt,
      scenarioIndex: 6,
      extraRootCaveats: [spenderCaveat],
      spender: attackerSpender,
      amount: 91n,
      initialAllowance: 37n,
    }),
    await runScenario({
      name: "fully_bound_original_spender_zero",
      operatorAccount,
      coordinatorAccount,
      token,
      expiresAt,
      scenarioIndex: 7,
      extraRootCaveats: [spenderCaveat, amountCaveat],
      spender: originalSpender,
      amount: 0n,
      initialAllowance: 37n,
    }),
    await runScenario({
      name: "fully_bound_attacker_spender_nonzero",
      operatorAccount,
      coordinatorAccount,
      token,
      expiresAt,
      scenarioIndex: 8,
      extraRootCaveats: [spenderCaveat, amountCaveat],
      spender: attackerSpender,
      amount: 91n,
      initialAllowance: 37n,
    }),
  ];
  metadata = {
    operatorAccount: operatorAccount.address,
    coordinatorAccount: coordinatorAccount.address,
    revoker: revoker.address,
    originalSpender: originalSpender.address,
    attackerSpender: attackerSpender.address,
    token,
    delegationManager: environment.DelegationManager,
  };
} catch (error) {
  results = [
    {
      name: "experiment_failure",
      status: "error",
      error: error.stack || error.message,
    },
  ];
} finally {
  await provider.disconnect?.();
}

const report = {
  generatedAt: new Date().toISOString(),
  sourceRevision: "0b09accf3a19bb9712b28e9c2044c7db05fec669",
  sdkVersion: "1.6.0",
  chainId,
  substitutions: [
    "The root and coordinator use the official Hybrid implementation and local EOA owners.",
    "The leaf delegate is a local EOA so it can call the manager directly without a hosted bundler.",
    "The target token is a source-included local ERC-20 fixture with test-only allowance/balance setters.",
  ],
  metadata,
  results,
};

const expected = {
  original_known_spender_revoke: {
    status: "success",
    finalAllowance: "0",
  },
  original_known_spender_nonzero: {
    status: "success",
    finalAllowance: "91",
  },
  original_attacker_spender_nonzero: {
    status: "success",
    finalAllowance: "91",
    transferStatus: "success",
    transferBalance: "55",
  },
  amount_bound_attacker_spender_zero: {
    status: "success",
    finalAllowance: "0",
  },
  amount_bound_attacker_spender_nonzero: {
    status: "reverted",
    finalAllowance: "37",
  },
  spender_bound_attacker_spender_nonzero: {
    status: "reverted",
    finalAllowance: "37",
  },
  fully_bound_original_spender_zero: {
    status: "success",
    finalAllowance: "0",
  },
  fully_bound_attacker_spender_nonzero: {
    status: "reverted",
    finalAllowance: "37",
  },
};
const mismatches = [];
for (const [name, expectation] of Object.entries(expected)) {
  const result = results.find((entry) => entry.name === name);
  if (!result) {
    mismatches.push(`${name}: missing result`);
    continue;
  }
  for (const key of ["status", "finalAllowance"]) {
    if (result[key] !== expectation[key]) {
      mismatches.push(
        `${name}: ${key}=${result[key]}, expected=${expectation[key]}`,
      );
    }
  }
  if (
    expectation.transferStatus &&
    result.transfer?.status !== expectation.transferStatus
  ) {
    mismatches.push(
      `${name}: transfer status=${result.transfer?.status}, expected=${expectation.transferStatus}`,
    );
  }
  if (
    expectation.transferBalance &&
    result.transfer?.spenderBalanceAfter !== expectation.transferBalance
  ) {
    mismatches.push(
      `${name}: spender balance=${result.transfer?.spenderBalanceAfter}, expected=${expectation.transferBalance}`,
    );
  }
}
report.assertions = {
  passed: mismatches.length === 0,
  mismatches,
};

fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(
  outputPath,
  `${JSON.stringify(
    report,
    (_key, value) => (typeof value === "bigint" ? value.toString() : value),
    2,
  )}\n`,
);
const resolvedRunDir = path.resolve(runDir);
const allowedTempRoot = `${path.resolve(tempRoot)}${path.sep}`;
if (!resolvedRunDir.startsWith(allowedTempRoot)) {
  throw new Error(`Refusing to remove unexpected path: ${resolvedRunDir}`);
}
fs.rmSync(resolvedRunDir, { recursive: true, force: true });
console.log(
  JSON.stringify(
    {
      outputPath,
      metadata,
      assertions: report.assertions,
      results: results.map((result) => ({
        name: result.name,
        status: result.status,
        allowance: `${result.initialAllowance}->${result.finalAllowance}`,
        transfer: result.transfer,
      })),
    },
    null,
    2,
  ),
);
if (mismatches.length > 0) {
  process.exitCode = 1;
}
