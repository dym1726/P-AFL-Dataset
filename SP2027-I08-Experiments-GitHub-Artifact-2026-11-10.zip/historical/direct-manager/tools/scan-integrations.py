import json
import os
import re
import subprocess
from pathlib import Path


ARTIFACT_ROOT = Path(__file__).resolve().parents[1]
ROOT = Path(os.environ.get("I08_CORPUS_ROOT", ARTIFACT_ROOT / "corpus"))
OUT = Path(
    os.environ.get(
        "I08_SCAN_OUTPUT",
        ARTIFACT_ROOT / "evidence" / "integration-scan.json",
    )
)
CODE_SUFFIXES = {
    ".ts",
    ".tsx",
    ".js",
    ".jsx",
    ".mjs",
    ".cjs",
    ".sol",
    ".md",
    ".json",
}
EXCLUDED_PARTS = {
    "node_modules",
    ".git",
    "dist",
    "build",
    "coverage",
    ".next",
    "out",
}


def git(repo: Path, *args: str) -> str:
    result = subprocess.run(
        ["git", "-C", str(repo), *args],
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    return result.stdout.strip() if result.returncode == 0 else ""


def iter_text_files(repo: Path):
    for path in repo.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in CODE_SUFFIXES:
            continue
        if any(part in EXCLUDED_PARTS for part in path.relative_to(repo).parts):
            continue
        if path.stat().st_size > 1_000_000:
            continue
        yield path


def version_from_lockfile(repo: Path, package: str) -> str:
    candidates = [
        repo / "package-lock.json",
        repo / "npm-shrinkwrap.json",
        repo / "pnpm-lock.yaml",
        repo / "yarn.lock",
    ]
    for path in candidates:
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if path.name.endswith(".json"):
            try:
                data = json.loads(text)
                packages = data.get("packages", {})
                for key, value in packages.items():
                    if key.endswith(f"node_modules/{package}"):
                        return str(value.get("version", ""))
                deps = data.get("dependencies", {})
                if package in deps:
                    return str(deps[package].get("version", ""))
            except json.JSONDecodeError:
                pass
        escaped = re.escape(package)
        patterns = [
            rf"{escaped}@(?:npm:)?[^\s:]*(?::\s*version\s+)?[\"']?([0-9][^\"'\s]*)",
            rf"[\"']?{escaped}[\"']?\s*:\s*(?:\{{[^}}]*version[\"']?\s*:\s*)?[\"']?([0-9][^\"'\s,}}]*)",
        ]
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1).strip("'\"")
    return ""


def line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def find_windows(text: str, regex: str, radius: int = 900):
    results = []
    for match in re.finditer(regex, text, re.I):
        start = max(0, match.start() - radius)
        end = min(len(text), match.end() + radius)
        results.append(
            {
                "line": line_number(text, match.start()),
                "match": match.group(0)[:160],
                "context": re.sub(r"\s+", " ", text[start:end]).strip()[:1800],
            }
        )
    return results


records = []
for repo in sorted(path for path in ROOT.iterdir() if path.is_dir()):
    files = list(iter_text_files(repo))
    source_hits = []
    policy_hits = []
    field_caveat_hits = []
    exact_hits = []
    approval_hits = []
    for path in files:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        relative = path.relative_to(repo).as_posix()
        if path.suffix.lower() not in {".md", ".json"}:
            for hit in find_windows(
                text,
                r"createDelegation\s*\(|createCaveatBuilder\s*\(|functionCall\b",
            ):
                source_hits.append({"file": relative, **hit})
        for hit in find_windows(
            text,
            r"revoke[- ]only|approval revocation|cancel token approvals|set them to zero|approve\s*\([^,\n]+,\s*0\s*\)",
            500,
        ):
            policy_hits.append({"file": relative, **hit})
        if path.suffix.lower() not in {".md", ".json"}:
            for hit in find_windows(
                text,
                r"allowedCalldata|approvalRevocation",
                500,
            ):
                field_caveat_hits.append({"file": relative, **hit})
            for hit in find_windows(
                text,
                r"exactCalldata|exactExecution|exactExecutionBatch",
                500,
            ):
                exact_hits.append({"file": relative, **hit})
            for hit in find_windows(
                text,
                r"\bapprove\s*\(|selector[^\n]{0,100}(?:approve|transfer|mint)|selectors\s*:",
                500,
            ):
                approval_hits.append({"file": relative, **hit})

    joined_source = "\n".join(item["context"] for item in source_hits)
    if not source_hits:
        classification = "no_delegation_constructor"
    elif exact_hits:
        classification = "exact_or_field_bound"
    elif field_caveat_hits:
        classification = "calldata_or_semantic_bound"
    elif re.search(r"functionCall|selectors\s*:", joined_source, re.I):
        classification = "scope_only_candidate"
    else:
        classification = "delegation_use_unclassified"

    records.append(
        {
            "repo": repo.name,
            "commit": git(repo, "rev-parse", "HEAD"),
            "remote": git(repo, "config", "--get", "remote.origin.url"),
            "file_count_scanned": len(files),
            "smart_accounts_kit_version": version_from_lockfile(
                repo, "@metamask/smart-accounts-kit"
            ),
            "viem_version": version_from_lockfile(repo, "viem"),
            "classification": classification,
            "source_hits": source_hits[:30],
            "policy_hits": policy_hits[:20],
            "field_caveat_hits": field_caveat_hits[:20],
            "exact_hits": exact_hits[:20],
            "approval_hits": approval_hits[:20],
        }
    )

counts = {}
for record in records:
    counts[record["classification"]] = counts.get(record["classification"], 0) + 1
report = {
    "corpus_root": str(ROOT),
    "repository_count": len(records),
    "classification_counts": counts,
    "records": records,
}
OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
print(
    json.dumps(
        {
            "output": str(OUT),
            "repository_count": len(records),
            "classification_counts": counts,
        },
        indent=2,
    )
)
