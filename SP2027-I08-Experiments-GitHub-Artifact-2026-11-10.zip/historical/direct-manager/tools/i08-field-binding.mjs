import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  createDelegation,
  getSmartAccountsEnvironment,
} from "@metamask/smart-accounts-kit";
import {
  createCaveatBuilder,
  decodeCaveat,
} from "@metamask/smart-accounts-kit/utils";
import { encodeAbiParameters, pad, toFunctionSelector } from "viem";

process.env.DO_NOT_TRACK = "1";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const outputPath = path.resolve(__dirname, "../artifacts/field-binding.json");
const chainId = 11155111;
const environment = getSmartAccountsEnvironment(chainId);

const operator = "0x1000000000000000000000000000000000000001";
const coordinator = "0x1000000000000000000000000000000000000002";
const revoker = "0x1000000000000000000000000000000000000003";
const token = "0x036CbD53842c5426634e7929541eC2318f3dCF7e";
const originalSpender = "0x2000000000000000000000000000000000000001";
const attackerSpender = "0x2000000000000000000000000000000000000002";
const expiresAt = 2_000_000_000;

const enforcerNames = new Map(
  Object.entries(environment.caveatEnforcers).map(([name, address]) => [
    address.toLowerCase(),
    name,
  ]),
);

function makeRootCaveats() {
  return createCaveatBuilder(environment)
    .addCaveat("limitedCalls", { limit: 10 })
    .addCaveat("timestamp", {
      afterThreshold: 0,
      beforeThreshold: expiresAt,
    })
    .build();
}

function makeRootDelegation(extraCaveats = []) {
  return createDelegation({
    environment,
    from: operator,
    to: coordinator,
    scope: {
      type: "functionCall",
      targets: [token],
      selectors: ["approve(address,uint256)"],
    },
    caveats: [...makeRootCaveats(), ...extraCaveats],
  });
}

function describeCaveats(delegation) {
  return delegation.caveats.map((caveat, index) => ({
    index,
    enforcer: caveat.enforcer,
    enforcerName:
      enforcerNames.get(caveat.enforcer.toLowerCase()) ?? "UnknownEnforcer",
    terms: caveat.terms,
    args: caveat.args ?? "0x",
    decoded: decodeCaveat({ caveat, environment }),
  }));
}

const amountZero = encodeAbiParameters([{ type: "uint256" }], [0n]);
const amountNinetyOne = encodeAbiParameters([{ type: "uint256" }], [91n]);
const amountCaveat = createCaveatBuilder(environment)
  .addCaveat("allowedCalldata", {
    startIndex: 36,
    value: amountZero,
  })
  .build()[0];
const spenderCaveat = createCaveatBuilder(environment)
  .addCaveat("allowedCalldata", {
    startIndex: 4,
    value: pad(originalSpender),
  })
  .build()[0];

const originalRoot = makeRootDelegation();
const amountBoundRoot = makeRootDelegation([amountCaveat]);
const spenderBoundRoot = makeRootDelegation([spenderCaveat]);
const fullyBoundRoot = makeRootDelegation([spenderCaveat, amountCaveat]);
const child = createDelegation({
  environment,
  from: coordinator,
  to: revoker,
  parentDelegation: {
    ...originalRoot,
    signature: "0x",
  },
  caveats: createCaveatBuilder(environment)
    .addCaveat("limitedCalls", { limit: 5 })
    .build(),
});

const scenarios = [
  {
    name: "original_helper_revoke",
    caveatSet: "original",
    spender: originalSpender,
    amount: 0n,
  },
  {
    name: "original_known_spender_nonzero",
    caveatSet: "original",
    spender: originalSpender,
    amount: 91n,
  },
  {
    name: "original_attacker_spender_nonzero",
    caveatSet: "original",
    spender: attackerSpender,
    amount: 91n,
  },
  {
    name: "amount_bound_attacker_spender_zero",
    caveatSet: "amount_bound",
    spender: attackerSpender,
    amount: 0n,
  },
  {
    name: "amount_bound_attacker_spender_nonzero",
    caveatSet: "amount_bound",
    spender: attackerSpender,
    amount: 91n,
  },
  {
    name: "spender_bound_attacker_spender_nonzero",
    caveatSet: "spender_bound",
    spender: attackerSpender,
    amount: 91n,
  },
  {
    name: "fully_bound_original_spender_zero",
    caveatSet: "fully_bound",
    spender: originalSpender,
    amount: 0n,
  },
  {
    name: "fully_bound_attacker_spender_nonzero",
    caveatSet: "fully_bound",
    spender: attackerSpender,
    amount: 91n,
  },
];

const result = {
  generatedAt: new Date().toISOString(),
  chainId,
  sdkVersion: "1.6.0",
  sourceRevision: "0b09accf3a19bb9712b28e9c2044c7db05fec669",
  sourcePath: "src/lib/wallet.ts",
  sourceLines: {
    rootDelegation: "287-329",
    scopeDefinition: "311-323",
    childDelegation: "337-365",
    redemptionCalldata: "589-632",
  },
  abi: {
    signature: "approve(address,uint256)",
    selector: toFunctionSelector("approve(address,uint256)"),
    spenderStartIndex: 4,
    amountStartIndex: 36,
    amountZero,
    amountNinetyOne,
  },
  originalRoot: {
    delegation: originalRoot,
    caveats: describeCaveats(originalRoot),
  },
  amountBoundRoot: {
    delegation: amountBoundRoot,
    caveats: describeCaveats(amountBoundRoot),
  },
  spenderBoundRoot: {
    delegation: spenderBoundRoot,
    caveats: describeCaveats(spenderBoundRoot),
  },
  fullyBoundRoot: {
    delegation: fullyBoundRoot,
    caveats: describeCaveats(fullyBoundRoot),
  },
  childDelegation: {
    delegation: child,
    caveats: describeCaveats(child),
  },
  scenarios,
  staticObservations: {
    originalCaveatNames: describeCaveats(originalRoot).map(
      (entry) => entry.enforcerName,
    ),
    originalBindsApprovalAmount: false,
    originalBindsApprovalSpender: false,
    amountBoundBindsApprovalAmount: true,
    amountBoundBindsApprovalSpender: false,
    spenderBoundBindsApprovalAmount: false,
    spenderBoundBindsApprovalSpender: true,
    fullyBoundBindsBoth: true,
  },
};

const expectedOriginalCaveats = [
  "AllowedTargetsEnforcer",
  "AllowedMethodsEnforcer",
  "ValueLteEnforcer",
  "LimitedCallsEnforcer",
  "TimestampEnforcer",
];
if (
  JSON.stringify(result.staticObservations.originalCaveatNames) !==
    JSON.stringify(expectedOriginalCaveats) ||
  result.staticObservations.originalBindsApprovalAmount ||
  result.staticObservations.originalBindsApprovalSpender
) {
  throw new Error("Field-binding result did not match the expected source behavior");
}

const json = JSON.stringify(
  result,
  (_key, value) => (typeof value === "bigint" ? value.toString() : value),
  2,
);
fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(outputPath, `${json}\n`);
console.log(
  JSON.stringify(
    {
      outputPath,
      originalCaveatNames: result.staticObservations.originalCaveatNames,
      originalBindsApprovalAmount:
        result.staticObservations.originalBindsApprovalAmount,
      originalBindsApprovalSpender:
        result.staticObservations.originalBindsApprovalSpender,
      amountBoundCaveatNames: result.amountBoundRoot.caveats.map(
        (entry) => entry.enforcerName,
      ),
      scenarioCount: scenarios.length,
    },
    null,
    2,
  ),
);
