from csv import DictReader
from hashlib import sha256
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
for line in (root / "SHA256SUMS.txt").read_text(encoding="utf8").splitlines():
    expected, name = line.split("  ", 1)
    if sha256((root / name).read_bytes()).hexdigest() != expected:
        raise ValueError(f"Checksum mismatch: {name}")

def read_results(path):
    report = json.loads(path.read_text(encoding="utf8"))
    if report["assertions"] != {"passed": True, "mismatches": []}:
        raise ValueError("Manager assertions failed")
    return report["results"]

def outcome(result):
    return tuple(result[k] for k in (
        "name", "spender", "amount", "initialAllowance", "finalAllowance", "status", "logCount"
    )), result.get("transfer")

saved = read_results(root / "evidence/manager-experiment.json")
with (root / "evidence/manager-scenarios.csv").open(encoding="utf8", newline="") as f:
    table = list(DictReader(f))
if len(saved) != 8 or len(table) != 8:
    raise ValueError("Expected eight manager cases")
for row, result in zip(table, saved):
    fields = {
        "scenario": "name", "spender": "spender", "amount": "amount",
        "initial_allowance": "initialAllowance", "final_allowance": "finalAllowance",
        "status": "status", "transaction_hash": "transactionHash", "log_count": "logCount",
    }
    if any(row[col] != str(result[key]) for col, key in fields.items()):
        raise ValueError(f"CSV and raw record disagree: {row['scenario']}")
    transfer_fields = {
        "transfer_status": "status", "transfer_amount": "amount",
        "spender_balance_before": "spenderBalanceBefore", "spender_balance_after": "spenderBalanceAfter",
    }
    transfer = result.get("transfer") or {}
    if any(row[col] != str(transfer.get(key, "")) for col, key in transfer_fields.items()):
        raise ValueError(f"CSV and raw transfer disagree: {row['scenario']}")
    if result["status"] == "reverted":
        if result["logCount"] != 0 or result["initialAllowance"] != result["finalAllowance"]:
            raise ValueError(f"Unexpected state effect: {result['name']}")
if len(sys.argv) > 1:
    fresh = read_results(Path(sys.argv[1]))
    def comparable(results):
        transfer_fields = ("status", "amount", "spenderBalanceBefore", "spenderBalanceAfter")
        return [(fields, tuple((transfer or {}).get(k) for k in transfer_fields))
                for fields, transfer in map(outcome, results)]
    if comparable(saved) != comparable(fresh):
        raise ValueError("Fresh and recorded outcomes differ")
print("Checksums and eight recorded scenarios verified.")
