# I08 local field-binding reproduction

Pinned application source: [scam-slayer, revision 0b09accf](https://github.com/blhafner/scam-slayer/tree/0b09accf3a19bb9712b28e9c2044c7db05fec669). The experiment uses SDK 1.6.0, viem 2.51.3, Ganache 7.9.2 and Solidity 0.8.17. The Ganache accounts use a public fixture mnemonic. The manager experiment runs against its in-process provider with an isolated test token.

1. Clone the pinned source into a disposable checkout. Run `npm ci --ignore-scripts --no-audit --no-fund` there. Compare its package lock with `source/package-lock.json`.
2. Copy `tools/i08-field-binding.test.ts` into that checkout as `src/lib/i08-field-binding.test.ts`. Run `npx --no-install vitest run src/lib/i08-field-binding.test.ts`.
3. Copy `tools/i08-field-binding.mjs`, `tools/i08-manager-experiment.mjs` and the `tools/runtime/` directory to the checkout's `tools/` directory. Run `npm ci --prefix tools/runtime --ignore-scripts --no-audit --no-fund`.
4. In the checkout, run `node tools/i08-field-binding.mjs` and `node tools/i08-manager-experiment.mjs`. Compare its `artifacts/manager-experiment.json` with the recorded outcome using the command below.

```text
python tools/verify-results.py [path-to-rerun-manager-experiment.json]
```

The constructor unit test calls the application function. The local manager script reconstructs the same five root caveats with the SDK and exercises actual local execution. The portable script changes dependency lookup from an absolute workstation path to the pinned runtime directory. The recorded JSON and CSV are copied byte-for-byte from the dated experimental artifact. Hashes, block numbers and time-dependent fields in a fresh run can differ. The verifier compares the case outcomes, allowance reads, log counts and transfer balances.

The corpus metadata shipped here retains the 47 repository names and pinned commits needed by `tools/clone-corpus.ps1`. Run the scanner with `I08_SCAN_OUTPUT` set to a separate output path to preserve the pinned snapshot list. The manual dispositions describe a source-screening exercise and one locally confirmed application mismatch. The public deployment record concerns asset identity. Browser signing, hosted bundler execution and disclosure are outside this package's verified experiments.
