const fs = require("node:fs");
const path = require("node:path");
const { createRequire } = require("node:module");

const experimentRoot = path.resolve(__dirname, "..");
const dependencyRoot =
  process.env.C01_DEPENDENCY_ROOT ??
  path.join(experimentRoot, "evidence", "c01-dependencies");
const dependencyRequire = createRequire(
  path.join(dependencyRoot, "package.json"),
);
const toolkit = dependencyRequire("@metamask/delegation-toolkit");
const viem = dependencyRequire("viem");

const chainId = 11155111;
const from = "0x1111111111111111111111111111111111111111";
const to = "0x2222222222222222222222222222222222222222";
const tokenAddress = "0xa2bDc7A104d0554Ca70A28f74177501E377b1Cd8";
const zeroAddress = "0x0000000000000000000000000000000000000000";

const abis = {
  mint: {
    name: "mint",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "to", type: "address" },
      { name: "amount", type: "uint256" },
    ],
    outputs: [],
  },
  transfer: {
    name: "transfer",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "to", type: "address" },
      { name: "amount", type: "uint256" },
    ],
    outputs: [{ name: "", type: "bool" }],
  },
  approve: {
    name: "approve",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "spender", type: "address" },
      { name: "amount", type: "uint256" },
    ],
    outputs: [{ name: "", type: "bool" }],
  },
  transferFrom: {
    name: "transferFrom",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "from", type: "address" },
      { name: "to", type: "address" },
      { name: "amount", type: "uint256" },
    ],
    outputs: [{ name: "", type: "bool" }],
  },
  permit: {
    name: "permit",
    type: "function",
    stateMutability: "nonpayable",
    inputs: [
      { name: "owner", type: "address" },
      { name: "spender", type: "address" },
      { name: "value", type: "uint256" },
      { name: "deadline", type: "uint256" },
      { name: "v", type: "uint8" },
      { name: "r", type: "bytes32" },
      { name: "s", type: "bytes32" },
    ],
    outputs: [],
  },
};

const environment = toolkit.getDeleGatorEnvironment(chainId);
const caveats = toolkit
  .createCaveatBuilder(environment, { allowEmptyCaveats: false })
  .addCaveat("allowedMethods", [
    "0x00000001",
    abis.mint,
    abis.transfer,
    abis.approve,
    abis.transferFrom,
    abis.permit,
  ])
  .addCaveat("allowedTargets", [zeroAddress, tokenAddress])
  .addCaveat("limitedCalls", 5)
  .build();

const delegation = toolkit.createDelegation({ from, to, caveats });
const enforcerNames = new Map(
  Object.entries(environment.caveatEnforcers).map(([name, address]) => [
    address.toLowerCase(),
    name,
  ]),
);
const selectorValues = [
  ["deployment-marker", "0x00000001"],
  ["mint(address,uint256)", viem.toFunctionSelector("mint(address,uint256)")],
  ["transfer(address,uint256)", viem.toFunctionSelector("transfer(address,uint256)")],
  ["approve(address,uint256)", viem.toFunctionSelector("approve(address,uint256)")],
  [
    "transferFrom(address,address,uint256)",
    viem.toFunctionSelector("transferFrom(address,address,uint256)"),
  ],
  [
    "permit(address,address,uint256,uint256,uint8,bytes32,bytes32)",
    viem.toFunctionSelector(
      "permit(address,address,uint256,uint256,uint8,bytes32,bytes32)",
    ),
  ],
];

const summary = delegation.caveats.map((caveat) => {
  const terms = caveat.terms.toLowerCase();
  const entry = {
    enforcer: caveat.enforcer,
    enforcerName:
      enforcerNames.get(caveat.enforcer.toLowerCase()) ?? "unknown",
    args: caveat.args,
    terms: caveat.terms,
    selectorTerms: selectorValues.map(([signature, selector]) => ({
      signature,
      selector,
      present: terms.includes(selector.slice(2).toLowerCase()),
    })),
  };
  if (entry.enforcerName === "AllowedTargetsEnforcer") {
    const body = caveat.terms.slice(2);
    entry.decodedTargets = [];
    for (let offset = 0; offset + 40 <= body.length; offset += 40) {
      entry.decodedTargets.push(`0x${body.slice(offset, offset + 40)}`);
    }
  }
  if (entry.enforcerName === "LimitedCallsEnforcer") {
    entry.decodedCallLimit = BigInt(caveat.terms).toString();
  }
  return entry;
});

const report = {
  candidateId: "C01",
  generatedAt: new Date().toISOString(),
  source: {
    primaryRepository: "miguelmota/account-abstraction-demos",
    primaryCommit: "7f184476e50b09b2be61ba788d55fc045393ddac",
    duplicateRepository: "mohammadali4542/account-abstraction-demos",
    duplicateCommit: "eb80dfc7752bb581ecf0e4d11f1f5ea4987d80ed",
    sourceFile:
      "src/demo-7702-4337-delegation/useDemo.ts",
    policyFile: "src/demo-7702-4337-delegation/Demo.tsx",
  },
  dependencyVersions: {
    delegationToolkit: "0.10.2",
    viem: "2.29.4",
  },
  constructorInputs: {
    from,
    to,
    allowedMethods: selectorValues.map(([, selector]) => selector),
    allowedTargets: [zeroAddress, tokenAddress],
    limitedCalls: 5,
  },
  constructorOutput: {
    caveatCount: delegation.caveats.length,
    caveats: summary,
    fieldBinding: {
      target: true,
      method: true,
      spender: false,
      amount: false,
    },
  },
  policyEvidence: [
    "First, approve the delegate to spend 10 TEST tokens from your wallet.",
    "Then, the delegate will transfer those tokens from your wallet to the delegator smart account.",
  ],
  classification:
    "policy_review_candidate; method-bound but ABI-field-unbound; execution not yet run",
  proposedTest: {
    intendedRequest: "approve(delegate, 10e18)",
    strongestCandidateRequest: "approve(attackerSpender, balanceOrLargeAmount)",
    controls: [
      "same chain with AllowedCalldata spender binding",
      "same chain with AllowedCalldata amount binding",
      "ExactExecution for the intended request",
      "wrong target and wrong selector",
    ],
    requiredStateRead: "TEST-token allowance and transferFrom result",
  },
};

const outputPath = path.join(
  experimentRoot,
  "reruns",
  "c01-constructor-reproduction.json",
);
fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(outputPath, `${JSON.stringify(report, null, 2)}\n`);
console.log(
  JSON.stringify(
    {
      outputPath,
      caveatCount: report.constructorOutput.caveatCount,
      caveats: summary.map((item) => item.enforcerName),
      fieldBinding: report.constructorOutput.fieldBinding,
    },
    null,
    2,
  ),
);
