import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");

function parseCsv(text) {
  const rows = [];
  let row = [];
  let value = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const character = text[index];
    if (character === '"') {
      if (quoted && text[index + 1] === '"') {
        value += '"';
        index += 1;
      } else {
        quoted = !quoted;
      }
    } else if (character === "," && !quoted) {
      row.push(value);
      value = "";
    } else if ((character === "\n" || character === "\r") && !quoted) {
      if (character === "\r" && text[index + 1] === "\n") index += 1;
      row.push(value);
      if (row.some((item) => item.length > 0)) rows.push(row);
      row = [];
      value = "";
    } else {
      value += character;
    }
  }
  if (value.length > 0 || row.length > 0) {
    row.push(value);
    rows.push(row);
  }
  const [header, ...data] = rows;
  return data.map((values) =>
    Object.fromEntries(header.map((key, index) => [key, values[index] ?? ""])),
  );
}

const scan = JSON.parse(
  fs.readFileSync(path.join(root, "evidence/field-completeness-scan.json"), "utf8"),
);
const groundTruth = parseCsv(
  fs.readFileSync(path.join(root, "evidence/ground-truth.csv"), "utf8"),
);
const constructorTriage = parseCsv(
  fs.readFileSync(path.join(root, "evidence/constructor-triage.csv"), "utf8"),
);
const groundTruthByRepo = new Map(groundTruth.map((row) => [row.repo, row]));
const constructorByRepo = new Map(
  constructorTriage.map((row) => [row.repo, row]),
);

const dispositions = scan.results.map((result) => {
  const repo = result.repo.replace("__", "/");
  const ground = groundTruthByRepo.get(repo);
  const constructor = constructorByRepo.get(repo);
  let family = result.analyzerTier;
  let executed = "no";
  let independent = "yes";
  let note = "Source-only disposition from the fixed snapshot.";
  if (ground) {
    family = ground.disposition;
    executed =
      /executed|browser|manager|receipt|transfer|target effect/i.test(
        `${ground.execution_evidence} ${ground.disposition}`,
      )
        ? "yes"
        : "no";
    if (family.includes("duplicate")) independent = "no";
    note =
      ground.execution_evidence ||
      ground.constructor_evidence ||
      ground.source_observation;
  } else if (constructor) {
    family = constructor.disposition;
    executed = /simulated|unreachable|script_only/.test(family) ? "no" : "no";
    note = constructor.source_observation;
  } else if (result.rawAnalyzerTier === "no_constructor") {
    family = "no_smart_accounts_kit_constructor_in_selected_snapshot";
    note = "No relevant SDK delegation constructor was present in the scanned app source.";
  } else if (result.rawAnalyzerTier === "field_bound_control") {
    family = "field_bound_control";
    note = "A calldata or exact-execution constraint was present.";
  }
  return {
    repo,
    commit: result.commit,
    analyzerTier: result.analyzerTier,
    dispositionFamily: family,
    executed,
    independent,
    note,
  };
});

const csvEscape = (value) =>
  `"${String(value ?? "").replaceAll('"', '""')}"`;
const header = [
  "repo",
  "commit",
  "analyzerTier",
  "dispositionFamily",
  "executed",
  "independent",
  "note",
];
const csv = [
  header.map(csvEscape).join(","),
  ...dispositions.map((row) =>
    header.map((key) => csvEscape(row[key])).join(","),
  ),
].join("\n");
fs.writeFileSync(
  path.join(root, "evidence/repository-dispositions.csv"),
  `${csv}\n`,
);

const familyCounts = {};
for (const row of dispositions) {
  familyCounts[row.dispositionFamily] =
    (familyCounts[row.dispositionFamily] ?? 0) + 1;
}
const summary = {
  repositories: dispositions.length,
  uniqueRepositories: new Set(dispositions.map((row) => row.repo)).size,
  familyCounts,
  executedPaths: dispositions.filter((row) => row.executed === "yes").length,
  independentRepositories: dispositions.filter((row) => row.independent === "yes")
    .length,
};
fs.writeFileSync(
  path.join(root, "evidence/repository-disposition-summary.json"),
  `${JSON.stringify(summary, null, 2)}\n`,
);
console.log(JSON.stringify(summary, null, 2));
if (summary.repositories !== 47 || summary.uniqueRepositories !== 47) {
  process.exitCode = 1;
}
