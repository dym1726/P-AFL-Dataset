import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const experimentRoot = path.resolve(__dirname, "..");
const workspaceRoot = path.resolve(experimentRoot, "../..");
const require = createRequire(import.meta.url);

function resolveArgument(name, fallback) {
  const index = process.argv.indexOf(name);
  return index >= 0 && process.argv[index + 1] ? process.argv[index + 1] : fallback;
}

function loadTypeScript() {
  const candidates = [
    process.env.FIELD_ANALYZER_TYPESCRIPT,
    path.join(
      workspaceRoot,
      "work/repro/scam-slayer/node_modules/typescript",
    ),
    "typescript",
  ].filter(Boolean);
  const errors = [];
  for (const candidate of candidates) {
    try {
      return require(candidate);
    } catch (error) {
      errors.push(`${candidate}: ${error.message}`);
    }
  }
  throw new Error(`Unable to load TypeScript\n${errors.join("\n")}`);
}

const ts = loadTypeScript();
const corpusRoot = path.resolve(
  resolveArgument(
    "--corpus",
    path.join(workspaceRoot, "work/repro/corpus"),
  ),
);
const scanPath = path.resolve(
  resolveArgument(
    "--scan",
    path.join(
      experimentRoot,
      "../artifact/i08-field-binding/evidence/integration-scan.json",
    ),
  ),
);
const manualPath = path.resolve(
  resolveArgument(
    "--manual",
    path.join(
      experimentRoot,
      "../artifact/i08-field-binding/evidence/manual-review.json",
    ),
  ),
);
const manualOverridesPath = path.join(
  experimentRoot,
  "evidence/manual-overrides.json",
);
const outDir = path.resolve(
  resolveArgument(
    "--out-dir",
    path.join(experimentRoot, "evidence"),
  ),
);

const scan = JSON.parse(fs.readFileSync(scanPath, "utf8"));
const manual = JSON.parse(fs.readFileSync(manualPath, "utf8"));
const manualByRepo = new Map();
for (const item of manual.manualDispositions) {
  const normalized = item.repo.replace("/", "__");
  manualByRepo.set(normalized, item);
}
if (fs.existsSync(manualOverridesPath)) {
  const overrides = JSON.parse(fs.readFileSync(manualOverridesPath, "utf8"));
  for (const item of overrides.manualDispositions ?? []) {
    const normalized = item.repo.replace("/", "__");
    manualByRepo.set(normalized, item);
  }
}

const sourceExtensions = new Set([
  ".ts",
  ".tsx",
  ".js",
  ".jsx",
  ".mjs",
  ".cjs",
  ".sol",
]);
const policyLanguage = /\b(revoke[- ]only|approval revocation|set them to zero|cancel token approvals|spend(?:ing)? (?:limit|cap)|allowance|authorized? calls?|only (?:call|approve|the [A-Za-z0-9_.]+ function)|(?:cannot|can't|can never) (?:move|spend|transfer|call)|nothing else is authorized|approve(?:d)?[^.]{0,60}spend\s+\d+|spend\s+\d+[^.]{0,40}tokens?)\b/gi;
const constructorNames = new Set([
  "createDelegation",
  "createOpenDelegation",
  "createRedelegation",
]);
const fieldBindingCaveats = new Set([
  "allowedCalldata",
  "approvalRevocation",
  "exactCalldata",
  "exactCalldataBatch",
  "exactExecution",
  "exactExecutionBatch",
  "argsEqualityCheck",
]);

function walkFiles(root) {
  const files = [];
  const excluded = new Set([
    ".git",
    "node_modules",
    "dist",
    "build",
    "coverage",
    ".next",
    "out",
    "target",
  ]);
  const stack = [root];
  while (stack.length) {
    const current = stack.pop();
    for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
      if (excluded.has(entry.name)) continue;
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) {
        stack.push(full);
      } else if (entry.isFile()) {
        const stat = fs.statSync(full);
        if (stat.size <= 1_000_000) files.push(full);
      }
    }
  }
  return files.sort();
}

function relativeFile(repoRoot, file) {
  return path.relative(repoRoot, file).replaceAll("\\", "/");
}

function nodeText(source, node) {
  return source.slice(node.getStart(), node.getEnd()).replace(/\s+/g, " ").trim();
}

function stringValue(node) {
  if (!node) return null;
  if (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) {
    return node.text;
  }
  return null;
}

function propertyName(node) {
  if (ts.isPropertyAssignment(node)) {
    if (ts.isIdentifier(node.name) || ts.isStringLiteral(node.name)) {
      return node.name.text;
    }
  }
  if (ts.isShorthandPropertyAssignment(node)) return node.name.text;
  return null;
}

function callName(call) {
  const expression = call.expression;
  if (ts.isIdentifier(expression)) return expression.text;
  if (ts.isPropertyAccessExpression(expression)) return expression.name.text;
  return null;
}

function enclosingFunctionName(node) {
  let current = node.parent;
  while (current) {
    if (
      ts.isFunctionDeclaration(current) ||
      ts.isFunctionExpression(current) ||
      ts.isArrowFunction(current)
    ) {
      if (current.name?.text) return current.name.text;
      if (
        ts.isVariableDeclaration(current.parent) &&
        ts.isIdentifier(current.parent.name)
      ) {
        return current.parent.name.text;
      }
      if (
        ts.isPropertyAssignment(current.parent) ||
        ts.isMethodDeclaration(current)
      ) {
        return propertyName(current.parent) ?? current.name?.text ?? null;
      }
    }
    current = current.parent;
  }
  return null;
}

function collectStringArray(node) {
  if (!node || !ts.isArrayLiteralExpression(node)) return [];
  return node.elements.map(stringValue).filter(Boolean);
}

function collectObjectInfo(objectNode) {
  const info = {
    types: [],
    targets: [],
    selectors: [],
    caveatNames: [],
    otherKeys: [],
  };
  if (!objectNode || !ts.isObjectLiteralExpression(objectNode)) return info;
  for (const property of objectNode.properties) {
    const name = propertyName(property);
    if (!name || !ts.isPropertyAssignment(property)) continue;
    if (name === "type") {
      const value = stringValue(property.initializer);
      if (value) info.types.push(value);
    } else if (name === "targets") {
      info.targets.push(...collectStringArray(property.initializer));
    } else if (name === "selectors") {
      info.selectors.push(...collectStringArray(property.initializer));
    } else {
      info.otherKeys.push(name);
    }
  }
  return info;
}

function abiObjectSignature(node) {
  if (!node || !ts.isObjectLiteralExpression(node)) return null;
  const fields = Object.fromEntries(
    node.properties
      .filter((property) => ts.isPropertyAssignment(property))
      .map((property) => [propertyName(property), property.initializer]),
  );
  const name = stringValue(fields.name);
  if (!name || !fields.inputs || !ts.isArrayLiteralExpression(fields.inputs)) {
    return null;
  }
  const types = fields.inputs.elements.map((input) => {
    if (!ts.isObjectLiteralExpression(input)) return null;
    const inputFields = Object.fromEntries(
      input.properties
        .filter((property) => ts.isPropertyAssignment(property))
        .map((property) => [propertyName(property), property.initializer]),
    );
    const type = stringValue(inputFields.type);
    if (!type) return null;
    if (type.startsWith("tuple") && inputFields.components) {
      const componentTypes = ts.isArrayLiteralExpression(inputFields.components)
        ? inputFields.components.elements
            .map((component) => {
              if (!ts.isObjectLiteralExpression(component)) return null;
              const typeProperty = component.properties.find(
                (property) =>
                  ts.isPropertyAssignment(property) &&
                  propertyName(property) === "type",
              );
              return typeProperty && ts.isPropertyAssignment(typeProperty)
                ? stringValue(typeProperty.initializer)
                : null;
            })
            .filter(Boolean)
        : [];
      return `(${componentTypes.join(",")})${type.slice("tuple".length)}`;
    }
    return type;
  });
  if (types.some((type) => !type)) return null;
  return `${name}(${types.join(",")})`;
}

function indexVariableInitializers(rootNode) {
  const variables = new Map();
  function visit(node) {
    if (ts.isVariableDeclaration(node) && ts.isIdentifier(node.name)) {
      variables.set(node.name.text, node.initializer ?? null);
    }
    ts.forEachChild(node, visit);
  }
  visit(rootNode);
  return variables;
}

function collectCaveatDetails(rootNode, variables) {
  const details = new Map();
  function visit(node) {
    if (ts.isCallExpression(node) && callName(node) === "addCaveat") {
      const name = stringValue(node.arguments[0]);
      if (name) {
        const detail = details.get(name) ?? { name, selectors: [], targetCount: 0 };
        if (name === "allowedMethods" && node.arguments[1]) {
          const methods = node.arguments[1];
          if (ts.isArrayLiteralExpression(methods)) {
            for (const method of methods.elements) {
              const selector = stringValue(method);
              if (selector?.startsWith("0x")) continue;
              if (selector) detail.selectors.push(selector);
              const resolvedMethod =
                ts.isIdentifier(method) && variables.get(method.text)
                  ? variables.get(method.text)
                  : method;
              const abiSignature = abiObjectSignature(resolvedMethod);
              if (abiSignature) detail.selectors.push(abiSignature);
            }
          }
        }
        if (name === "allowedTargets" && node.arguments[1]) {
          const targets = node.arguments[1];
          if (ts.isArrayLiteralExpression(targets)) {
            detail.targetCount = targets.elements.length;
          }
        }
        detail.selectors = [...new Set(detail.selectors)];
        details.set(name, detail);
      }
    }
    ts.forEachChild(node, visit);
  }
  visit(rootNode);
  return [...details.values()].sort((left, right) =>
    left.name.localeCompare(right.name),
  );
}

function isVendored(relative) {
  return /(^|\/)(vendor|vendored|third[_-]?party|openzeppelin|submodules?|lib\/openzeppelin)(\/|$)/i.test(
    relative,
  );
}

function isTestOrExample(relative) {
  return /(^|\/)(test|tests|__tests__|examples?|fixtures?)(\/|$)|\.(test|spec)\./i.test(
    relative,
  );
}

function selectorFields(selector) {
  const match = selector.match(/^[A-Za-z_][A-Za-z0-9_]*\((.*)\)$/);
  if (!match) return [];
  const body = match[1].trim();
  if (!body) return [];
  const parts = [];
  let depth = 0;
  let start = 0;
  for (let index = 0; index < body.length; index += 1) {
    const character = body[index];
    if (character === "(" || character === "[") depth += 1;
    if (character === ")" || character === "]") depth -= 1;
    if (character === "," && depth === 0) {
      parts.push(body.slice(start, index).trim());
      start = index + 1;
    }
  }
  parts.push(body.slice(start).trim());
  return parts
    .filter(Boolean)
    .map((value) => value.replace(/\s+[A-Za-z_][A-Za-z0-9_]*$/, ""));
}

function classifyConstructor(call, sourceFile, source, relative) {
  const args = call.arguments;
  const argumentTexts = args.map((argument) => nodeText(source, argument));
  const scopeInfo = collectObjectInfo(
    args.find(
      (argument) =>
        ts.isObjectLiteralExpression(argument) &&
        argument.properties.some(
          (property) => propertyName(property) === "scope",
        ),
    ),
  );
  let nestedScope = null;
  for (const argument of args) {
    if (!ts.isObjectLiteralExpression(argument)) continue;
    const scopeProperty = argument.properties.find(
      (property) =>
        ts.isPropertyAssignment(property) &&
        propertyName(property) === "scope",
    );
    if (scopeProperty && ts.isPropertyAssignment(scopeProperty)) {
      nestedScope = collectObjectInfo(scopeProperty.initializer);
    }
  }
  const effectiveScope = nestedScope ?? scopeInfo;
  const enclosingFunction = (() => {
    let current = call.parent;
    while (current) {
      if (
        ts.isFunctionDeclaration(current) ||
        ts.isFunctionExpression(current) ||
        ts.isArrowFunction(current) ||
        ts.isMethodDeclaration(current)
      ) {
        return current;
      }
      current = current.parent;
    }
    return sourceFile;
  })();
  const caveatDetails = collectCaveatDetails(
    enclosingFunction,
    indexVariableInitializers(sourceFile),
  );
  const caveats = [
    ...new Set([
      ...caveatDetails.map((detail) => detail.name),
      ...[...nodeText(source, call).matchAll(/CaveatType\.([A-Za-z0-9_]+)/g)].map(
        (match) => match[1].replace(/^./, (value) => value.toLowerCase()),
      ),
    ]),
  ].sort();
  const constructorText = nodeText(source, call);
  const selectorCandidates = [
    ...constructorText.matchAll(/["']([A-Za-z_][A-Za-z0-9_]*\([^"']*\))["']/g),
  ].map((match) => match[1]);
  const selectors = [
    ...new Set([
      ...effectiveScope.selectors,
      ...selectorCandidates,
      ...caveatDetails.flatMap((detail) => detail.selectors),
    ]),
  ];
  const fieldBound =
    caveats.some((name) => fieldBindingCaveats.has(name)) ||
    /\b(allowedCalldata|approvalRevocation|exactCalldata|exactExecution|argsEqualityCheck)\b/.test(
      constructorText,
    );
  const functionCallScope =
    effectiveScope.types.some((value) => /functionCall/i.test(value)) ||
    /FunctionCall/.test(argumentTexts.join(" "));
  const methodScope =
    functionCallScope || caveatDetails.some((detail) => detail.name === "allowedMethods");
  const abiFields = [...new Set(selectors.flatMap(selectorFields))];
  return {
    constructor: callName(call),
    functionName: enclosingFunctionName(call),
    file: relative,
    line:
      source.slice(0, call.getStart()).split("\n").length,
    selectors: [...new Set(selectors)],
    abiFields,
    caveats,
    caveatDetails,
    fieldBound,
    functionCallScope,
    methodScope,
    targets: effectiveScope.targets,
    sourceSnippet: nodeText(source, call).slice(0, 1200),
  };
}

function policyHints(files) {
  const hints = [];
  for (const file of files) {
    const relative = file.relative;
    if (isVendored(relative)) continue;
    const text = file.text;
    policyLanguage.lastIndex = 0;
    for (const match of text.matchAll(policyLanguage)) {
      const start = Math.max(0, match.index - 140);
      const end = Math.min(text.length, match.index + match[0].length + 220);
      hints.push({
        file: relative,
        line: text.slice(0, match.index).split("\n").length,
        match: match[0],
        context: text.slice(start, end).replace(/\s+/g, " ").trim(),
      });
      if (hints.length >= 40) return hints;
    }
  }
  return hints;
}

function functionReferenceCounts(files, constructors) {
  const counts = {};
  for (const constructor of constructors) {
    const name = constructor.functionName;
    if (!name) continue;
    const pattern = new RegExp(`\\b${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*\\(`, "g");
    counts[name] = files.reduce(
      (total, file) => total + (file.text.match(pattern)?.length ?? 0),
      0,
    );
  }
  return counts;
}

function manualClass(record, manualEntry) {
  if (!manualEntry) return null;
  return {
    classification: manualEntry.classification,
    disposition: manualEntry.disposition,
  };
}

const results = [];
for (const record of scan.records) {
  const repoRoot = path.join(corpusRoot, record.repo);
  if (!fs.existsSync(repoRoot)) {
    results.push({
      repo: record.repo,
      commit: record.commit,
      error: "repository_missing",
    });
    continue;
  }
  const files = walkFiles(repoRoot)
    .filter((file) => sourceExtensions.has(path.extname(file).toLowerCase()))
    .map((file) => ({
      absolute: file,
      relative: relativeFile(repoRoot, file),
      text: fs.readFileSync(file, "utf8"),
    }));
  const constructors = [];
  for (const file of files) {
    if (isVendored(file.relative)) continue;
    const scriptKind = file.absolute.endsWith(".tsx")
      ? ts.ScriptKind.TSX
      : file.absolute.endsWith(".ts")
        ? ts.ScriptKind.TS
        : file.absolute.endsWith(".jsx")
          ? ts.ScriptKind.JSX
          : ts.ScriptKind.JS;
    const sourceFile = ts.createSourceFile(
      file.absolute,
      file.text,
      ts.ScriptTarget.Latest,
      true,
      scriptKind,
    );
    function visit(node) {
      if (
        ts.isCallExpression(node) &&
        constructorNames.has(callName(node))
      ) {
        constructors.push(
          classifyConstructor(node, sourceFile, file.text, file.relative),
        );
      }
      ts.forEachChild(node, visit);
    }
    visit(sourceFile);
  }
  const references = functionReferenceCounts(files, constructors);
  const hints = policyHints(files);
  const manualEntry = manualByRepo.get(record.repo);
  const override = manualClass(record, manualEntry);
  const nonVendoredConstructors = constructors.filter(
    (item) => !isVendored(item.file),
  );
  const appConstructors = nonVendoredConstructors.filter(
    (item) => !isTestOrExample(item.file),
  );
  const scopeOnly = appConstructors.filter(
    (item) => item.methodScope && item.abiFields.length > 0 && !item.fieldBound,
  );
  const fieldBound = appConstructors.filter((item) => item.fieldBound);
  const reachableReferences = [...new Set(
    appConstructors
      .map((item) => item.functionName)
      .filter(Boolean)
      .map((name) => ({ name, count: references[name] ?? 0 }))
      .filter((item) => item.count > 1),
  )];
  let rawTier = "no_constructor";
  if (scopeOnly.length > 0 && hints.length > 0) {
    rawTier = "candidate_requires_policy_review";
  } else if (scopeOnly.length > 0) {
    rawTier = "unbound_fields_policy_unresolved";
  } else if (fieldBound.length > 0) {
    rawTier = "field_bound_control";
  } else if (appConstructors.length > 0) {
    rawTier = "constructor_without_abi_field_target";
  }
  const tier = override?.classification ?? rawTier;
  results.push({
    repo: record.repo,
    remote: record.remote,
    commit: record.commit,
    rawAnalyzerTier: rawTier,
    analyzerTier: tier,
    manualOverride: override,
    sourceFiles: files.length,
    constructorCount: appConstructors.length,
    constructors: appConstructors,
    reachableReferences,
    policyHints: hints,
    warnings: constructors.filter((item) => isVendored(item.file)).length
      ? [`Excluded ${constructors.filter((item) => isVendored(item.file)).length} vendored constructor hit(s).`]
      : [],
  });
}

const tierCounts = {};
const rawTierCounts = {};
for (const result of results) {
  const key = result.error ?? result.analyzerTier;
  tierCounts[key] = (tierCounts[key] ?? 0) + 1;
  const rawKey = result.error ?? result.rawAnalyzerTier;
  rawTierCounts[rawKey] = (rawTierCounts[rawKey] ?? 0) + 1;
}

const reviewedRepos = new Set(manualByRepo.keys());
const reviewedResults = results.filter((result) => reviewedRepos.has(result.repo));
const confirmed = reviewedResults.filter(
  (result) =>
    result.manualOverride?.classification === "confirmed_local_field_mismatch",
);
const broadCandidates = results.filter((result) =>
  [
    "candidate_requires_policy_review",
    "unbound_fields_policy_unresolved",
  ].includes(result.rawAnalyzerTier),
);
const reviewedBroadCandidates = broadCandidates.filter((result) =>
  reviewedRepos.has(result.repo),
);
const uniqueReviewedBroadCandidates = reviewedBroadCandidates.filter(
  (result) =>
    result.manualOverride?.classification !==
    "candidate_duplicate_not_independent",
);
const report = {
  generatedAt: new Date().toISOString(),
  analyzerVersion: "0.1.0",
  sourceBasis: {
    corpusRoot,
    scanPath,
    manualPath,
    manualOverridesPath,
    repositories: scan.repository_count,
  },
  scope: {
    input:
      "Fixed public repository snapshots and source files only. No runtime redemption is inferred from this scan.",
    candidateDefinition:
      "A non-vendored application constructor with a function-call scope, named ABI selectors, at least one ABI argument field, no exact or calldata field caveat, and a policy-language hint.",
    limitation:
      "The analyzer generates review candidates. It cannot establish user intent, deployment reachability, signature validity, target effects, or vulnerability prevalence.",
  },
  tierCounts,
  rawTierCounts,
  manualValidation: {
    reviewedRepositories: reviewedResults.length,
    confirmedLocalMismatches: confirmed.length,
    confirmedRepositories: confirmed.map((result) => result.repo),
    reviewedCandidateRows: reviewedBroadCandidates.length,
    deduplicatedCandidateFamilies: uniqueReviewedBroadCandidates.length,
    rawCandidatePrecisionForConfirmedMismatch:
      reviewedBroadCandidates.length > 0
        ? confirmed.length / reviewedBroadCandidates.length
        : null,
    deduplicatedCandidatePrecisionForConfirmedMismatch:
      uniqueReviewedBroadCandidates.length > 0
        ? confirmed.length / uniqueReviewedBroadCandidates.length
        : null,
    note:
      "This is validation on the manually reviewed subset, not a corpus-wide recall estimate.",
  },
  broadCandidateQueue: broadCandidates.map((result) => ({
    repo: result.repo,
    commit: result.commit,
    rawTier: result.rawAnalyzerTier,
    finalTier: result.analyzerTier,
    constructors: result.constructors.length,
    policyHintCount: result.policyHints.length,
    abiFields: [...new Set(result.constructors.flatMap((item) => item.abiFields))],
    selectors: [...new Set(result.constructors.flatMap((item) => item.selectors))],
    files: [...new Set(result.constructors.map((item) => item.file))],
  })),
  results,
};

fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(
  path.join(outDir, "field-completeness-scan.json"),
  `${JSON.stringify(report, null, 2)}\n`,
);

const csvEscape = (value) => {
  const text = value == null ? "" : String(value);
  return `"${text.replaceAll('"', '""')}"`;
};
const csvRows = [
  [
    "repo",
    "commit",
    "raw_tier",
    "tier",
    "constructor_count",
    "abi_fields",
    "selectors",
    "policy_hint_count",
    "files",
  ],
  ...results.map((result) => [
    result.repo,
    result.commit,
    result.error ?? result.rawAnalyzerTier,
    result.error ?? result.analyzerTier,
    result.constructorCount ?? 0,
    [...new Set((result.constructors ?? []).flatMap((item) => item.abiFields))].join(";"),
    [...new Set((result.constructors ?? []).flatMap((item) => item.selectors))].join(";"),
    result.policyHints?.length ?? 0,
    [...new Set((result.constructors ?? []).map((item) => item.file))].join(";"),
  ]),
];
fs.writeFileSync(
  path.join(outDir, "repository-tiers.csv"),
  `${csvRows.map((row) => row.map(csvEscape).join(",")).join("\n")}\n`,
);

console.log(
  JSON.stringify(
    {
      output: path.join(outDir, "field-completeness-scan.json"),
      repositories: results.length,
      tierCounts,
      rawTierCounts,
      reviewedRepositories: reviewedResults.length,
      confirmedLocalMismatches: confirmed.length,
    },
    null,
    2,
  ),
);
