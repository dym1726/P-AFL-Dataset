import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");
const scanPath = path.join(root, "evidence/field-completeness-scan.json");
const funnelPath = path.join(root, "evidence/funnel.json");
const scan = JSON.parse(fs.readFileSync(scanPath, "utf8"));
const funnel = JSON.parse(fs.readFileSync(funnelPath, "utf8"));
const c01Path = path.join(
  root,
  "evidence/c01-constructor-reproduction.json",
);
const c01 = JSON.parse(fs.readFileSync(c01Path, "utf8"));
const c01Manager = JSON.parse(
  fs.readFileSync(path.join(root, "evidence/c01-manager-experiment.json"), "utf8"),
);
const dispositionSummary = JSON.parse(
  fs.readFileSync(
    path.join(root, "evidence/repository-disposition-summary.json"),
    "utf8",
  ),
);

const failures = [];
const assert = (condition, message) => {
  if (!condition) failures.push(message);
};

assert(scan.sourceBasis.repositories === 47, "Expected 47 source repositories");
assert(scan.results.length === 47, `Expected 47 result rows, found ${scan.results.length}`);
assert(
  scan.manualValidation.confirmedLocalMismatches === 1,
  "Expected one confirmed local mismatch",
);
assert(
  funnel.sourcePopulation.githubReportedRepositories === 47,
  "Funnel source count is inconsistent",
);
assert(
  funnel.manualGroundTruth.reviewedRawCandidates === 4,
  "Expected four reviewed raw candidates",
);
assert(
  funnel.manualGroundTruth.rawCandidatePrecisionForConfirmedMismatch === 0.25,
  "Raw candidate precision is inconsistent with one confirmed mismatch among four rows",
);
assert(
  funnel.manualGroundTruth.deduplicatedCandidateFamilies === 3,
  "Expected three deduplicated candidate families",
);
assert(
  funnel.manualGroundTruth.reviewedRepositories === 9,
  "Expected nine reviewed repositories after C01 triage",
);
assert(
  dispositionSummary.repositories === 47 &&
    dispositionSummary.uniqueRepositories === 47,
  "Expected complete source dispositions for 47 repositories",
);
assert(
  dispositionSummary.executedPaths === 2,
  "Expected two independently executed application families",
);
const c01Scan = scan.results.find(
  (item) => item.repo === "miguelmota__account-abstraction-demos",
);
assert(
  c01Scan?.rawAnalyzerTier === "candidate_requires_policy_review",
  "Analyzer did not recover C01 as a raw policy-review candidate",
);
assert(
  c01.constructorOutput.caveatCount === 3,
  "C01 constructor did not emit the expected three caveats",
);
assert(
  c01.constructorOutput.fieldBinding.spender === false,
  "C01 unexpectedly binds the approve spender",
);
assert(
  c01.constructorOutput.fieldBinding.amount === false,
  "C01 unexpectedly binds the approve amount",
);
assert(c01Manager.assertions.passed, "C01 manager assertions did not pass");
const c01Attack = c01Manager.results.find(
  (item) => item.name === "source_attacker_large",
);
const c01Repair = c01Manager.results.find(
  (item) => item.name === "allowed_calldata_attacker_large",
);
const c01GeneralTransfer = c01Manager.results.find(
  (item) => item.name === "separated_general_transfer",
);
const c01SeparatedIntended = c01Manager.results.find(
  (item) => item.name === "separated_approve_only_intended",
);
const c01SeparatedAttack = c01Manager.results.find(
  (item) => item.name === "separated_approve_only_attack",
);
assert(
  c01Attack?.status === "success" &&
    c01Attack?.allowance === "1000000000000000000000" &&
    c01Attack?.transfer?.balance === "55",
  "C01 did not reproduce the local attacker allowance and transfer",
);
assert(
  c01Repair?.status === "reverted" && c01Repair?.allowance === "0",
  "C01 AllowedCalldata repair did not reject the attack",
);
assert(
  c01GeneralTransfer?.status === "success",
  "C01 separated design broke the general transfer action",
);
assert(
  c01SeparatedIntended?.status === "success" &&
    c01SeparatedAttack?.status === "reverted",
  "C01 separated approve-only controls did not preserve the intended request",
);

const expected = {
  "blhafner__scam-slayer": "confirmed_local_field_mismatch",
  "intuition-box__delegation": "field_bound_control",
  "vicdevman__qleva-delegation-prototype": "relational_scope_candidate",
  "toxfox69__tiamat-vault": "unresolved_argument_binding",
  "Ayomisco__Delegata": "unreachable_placeholder",
  "developerfred__metamask-delegation-agent": "unconnected_source_candidate",
  "CrystallineButterfly__Synthesis-MetaMask-Delegations":
    "classifier_false_positive",
};
for (const [repo, tier] of Object.entries(expected)) {
  const result = scan.results.find((item) => item.repo === repo);
  assert(Boolean(result), `Missing expected repository ${repo}`);
  if (result) {
    assert(
      result.analyzerTier === tier,
      `${repo}: expected ${tier}, found ${result.analyzerTier}`,
    );
  }
}

const i08 = scan.results.find((item) => item.repo === "blhafner__scam-slayer");
assert(Boolean(i08), "I08 result is missing");
if (i08) {
  const fields = new Set(i08.constructors.flatMap((item) => item.abiFields));
  assert(fields.has("address"), "I08 approval spender field was not extracted");
  assert(fields.has("uint256"), "I08 approval amount field was not extracted");
  assert(
    i08.constructors.some((item) =>
      item.selectors.includes("approve(address,uint256)"),
    ),
    "I08 approve selector was not extracted",
  );
  assert(
    i08.constructors
      .filter((item) => item.selectors.includes("approve(address,uint256)"))
      .every((item) => item.fieldBound === false),
    "A source constructor unexpectedly binds the approval fields",
  );
}

const fieldBound = scan.results.find(
  (item) => item.repo === "intuition-box__delegation",
);
assert(
  fieldBound?.constructors.some((item) => item.fieldBound),
  "Field-bound I04 control was not recognized",
);

const report = {
  passed: failures.length === 0,
  failures,
  repositories: scan.results.length,
  confirmedLocalMismatches: scan.manualValidation.confirmedLocalMismatches,
  reviewedRepositories: scan.manualValidation.reviewedRepositories,
  preparedCandidates: 1,
  executedCandidates: 1,
};
fs.writeFileSync(
  path.join(root, "evidence/analyzer-validation.json"),
  `${JSON.stringify(report, null, 2)}\n`,
);
console.log(JSON.stringify(report, null, 2));
if (!report.passed) process.exitCode = 1;
