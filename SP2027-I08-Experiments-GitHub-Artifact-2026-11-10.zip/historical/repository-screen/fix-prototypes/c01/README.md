# C01 proposed application fix design

The original demo uses one delegation for mint, transfer, approve, transferFrom, and permit. Adding a global `AllowedCalldata` spender or amount condition would also constrain the unrelated methods. A one-line patch is therefore not a safe fix.

The tested design separates capabilities:

1. Keep a method-scoped delegation for non-payment demo actions.
2. Add an approve-only delegation for the payment step.
3. Bind the approve spender and `TRANSFER_AMOUNT` with two `AllowedCalldata` caveats.
4. Set the leaf call limit to one.

The local manager experiment records:

- general delegation transfer: success;
- approve-only intended request: success;
- approve-only attacker request: reverted, allowance zero.

This is a design prototype in `tools/c01-manager-experiment.mjs`; no maintainer patch or acknowledgment is claimed.
