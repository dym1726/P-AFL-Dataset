# I08 proposed application fix

This patch adds an `AllowedCalldataEnforcer` condition at amount offset 36 with the encoded value zero in `createAgentDelegation`.

It keeps the existing target and approve-selector scope. The change binds the revoke-only amount without fixing the spender, because the user-facing helper supports revoking a selected spender.

Apply to a disposable checkout of commit `0b09accf3a19bb9712b28e9c2044c7db05fec669`:

```powershell
git apply wallet.patch
Copy-Item i08-fix.test.ts <repo>/src/lib/i08-fix.test.ts
npx --no-install vitest run src/lib/i08-fix.test.ts --reporter=verbose
```

The recorded test passed. This is an author-side fix prototype, not a maintainer commit or acknowledgment.
