import { describe, expect, it } from "vitest";
import {
  encodeAbiParameters,
  toHex,
} from "viem";
import { sepolia } from "viem/chains";
import {
  createAgentDelegation,
  setActiveChain,
} from "./wallet";

describe("I08 proposed application fix", () => {
  it("binds the approval amount to zero without replacing target and method scope", async () => {
    setActiveChain(sepolia.id);
    const operator = {
      address: "0x1000000000000000000000000000000000000001" as const,
      signDelegation: async () => "0x1234" as const,
    };
    const delegation = await createAgentDelegation(
      operator,
      "0x1000000000000000000000000000000000000002",
      {
        allowedTargets: [
          "0x036CbD53842c5426634e7929541eC2318f3dCF7e",
        ],
        maxCalls: 10,
        expiryDays: 30,
      },
    );
    const amountTerms = encodeAbiParameters([{ type: "uint256" }], [0n]);
    const indexTerms = toHex(36, { size: 32 });
    const allowedCalldata = delegation.caveats.find((caveat) =>
      caveat.terms
        .toLowerCase()
        .startsWith(`${indexTerms}${amountTerms.slice(2)}`.toLowerCase()),
    );
    expect(allowedCalldata).toBeDefined();
  });
});
