# Extended I08 direct-manager record

This folder preserves the 16-scenario JSON and CSV from the FieldBinding Artifact. All 16 rows have distinct transaction hashes. Nine succeeded and seven reverted. The reverted rows kept the initial allowance and recorded no logs. The older eight-case portable package remains under ../direct-manager/.

For a replay, use the pinned disposable application checkout and locked runtime described in ../direct-manager/README.md. Copy the runner in this folder to that checkout and set I08_RUNTIME_ROOT to the installed locked runtime directory. The extended source changes only local dependency resolution. Its archived result files are unchanged. The relocated script was syntax-checked.
