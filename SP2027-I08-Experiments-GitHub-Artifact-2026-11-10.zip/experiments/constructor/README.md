# I08 matched constructor experiment for Figure 1(b)

This artifact preserves the two TypeScript construction functions from the application revision recorded in source.json. The harness executes both functions with the Lab local chain, the official SDK manager and Hybrid contracts, local test signers, and a fixed constructor clock. It adds one amount caveat to the original root function for the patched condition. Four requests per condition start at the same block. The fixture uses raw token base units.

Run the offline evidence checks with Python 3.10 or later:

    python verify-constructor.py experiment.json

For a fresh execution on Windows, extract the official Web3 Agent Lab V0.16.0 portable release to C:/Web3Lab and run these commands from this archive directory:

    npm ci --no-audit --no-fund --ignore-scripts
    & 'C:/Web3Lab/runtime/node.exe' ./run-constructor.mjs C:/Web3Lab C:/Web3Lab/runtime/anvil.exe ./rerun
    python ./verify-constructor.py ./rerun/experiment.json

The two supplied functions are exact source excerpts, with LF line endings, from src/lib/wallet.ts at commit 0b09accf3a19bb9712b28e9c2044c7db05fec669. The source.json file records the upstream and excerpt SHA-256. The root and child signers are local fixtures. The run invokes the actual constructor logic and submits the resulting credentials. It does not exercise production signing or submission.

The archive contains the eight native receipts, both credential chains, allowance and balance reads, and setup records. The previous Signed Delegation Experiments code and evidence archive separately contains the 415-run signed suites and the 15-case wallet controls.
