export async function createAgentDelegation(
  operatorAccount: any,
  agentAddress: Address,
  opts: {
    allowedTargets?: Address[];
    maxCalls?: number;
    expiryDays?: number;
  } = {}
) {
  const environment = getSmartAccountsEnvironment(getChainId());

  if (!opts.allowedTargets?.length) {
    throw new Error("At least one ERC-20 target required for delegation scope");
  }

  // Extra caveats layered on top of the scope: rate-limit total redemptions
  // and expire the delegation after expiryDays (default 30).
  const expirySeconds =
    Math.floor(Date.now() / 1000) + (opts.expiryDays ?? 30) * 86400;
  const extraCaveats = createCaveatBuilder(environment)
    .addCaveat("limitedCalls", { limit: opts.maxCalls ?? 10 })
    .addCaveat("timestamp", { afterThreshold: 0, beforeThreshold: expirySeconds })
    .build();

  // functionCall scope restricts to approve(address,uint256) on the given
  // ERC-20 targets only, with value=0 (no native token movement).
  const delegation = createDelegation({
    environment,
    to: agentAddress,
    from: operatorAccount.address,
    scope: {
      type: "functionCall",
      targets: opts.allowedTargets,
      selectors: ["approve(address,uint256)"],
    },
    caveats: extraCaveats,
  });

  // Sign with operator's account (triggers MetaMask popup)
  const signature = await operatorAccount.signDelegation({ delegation });

  return { ...delegation, signature };
}

export async function createRedelegation(
  coordinatorAccount: any,
  parentSignedDelegation: any,
  subAgentAddress: Address,
  opts: { maxCalls?: number; salt?: Hex } = {}
) {
  const environment = getSmartAccountsEnvironment(getChainId());

  // Attenuation: child can redeem fewer times than the parent allows.
  const childCaveats = createCaveatBuilder(environment)
    .addCaveat("limitedCalls", { limit: opts.maxCalls ?? 5 })
    .build();

  const delegation = createDelegation({
    environment,
    to: subAgentAddress,
    from: coordinatorAccount.address,
    parentDelegation: parentSignedDelegation,
    caveats: childCaveats,
    // A unique salt yields a unique delegation hash, so single-use leaves
    // (limitedCalls(1)) created per relay don't collide with prior ones.
    ...(opts.salt ? { salt: opts.salt } : {}),
  });

  // Coordinator signs locally — no MetaMask popup (autonomous A2A handoff).
  const signature = await coordinatorAccount.signDelegation({ delegation });

  return { ...delegation, signature };
}
