import assert from 'node:assert/strict';
import { stripTypeScriptTypes } from 'node:module';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createServer } from 'node:net';
import path from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';

const [labPath, anvilPath, outputPath] = process.argv.slice(2).map(p => path.resolve(p));
const require = createRequire(process.env.I08_DEPENDENCY_ROOT
  ? path.join(path.resolve(process.env.I08_DEPENDENCY_ROOT), 'package.json') : import.meta.url);
const { createPublicClient, createWalletClient, encodeFunctionData, http, defineChain,
  bytesToHex, pad, toHex, parseAbi, parseAbiItem, decodeEventLog, keccak256 } = require('viem');
const { mnemonicToAccount } = require('viem/accounts');
const { createDelegation, createExecution, ExecutionMode, Implementation, getSmartAccountsEnvironment,
  signDelegation, toMetaMaskSmartAccount } = require('@metamask/smart-accounts-kit');
const { createCaveatBuilder, deploySmartAccountsEnvironment, overrideDeployedEnvironment, hashDelegation } =
  require('@metamask/smart-accounts-kit/utils');
const { DelegationManager } = require('@metamask/smart-accounts-kit/contracts');

process.env.LAB_LIBRARY_ONLY = '1';
process.env.LAB_AGENT_WORKER = '1';
process.env.LAB_ROOT = labPath;
process.env.LAB_DATA_DIR = path.join(outputPath, 'internal');
const labBundle = path.join(labPath, 'dist', 'server.mjs');
const { ChainLab } = await import(pathToFileURL(labBundle).href);
const probe = createServer();
await new Promise((res, rej) => { probe.once('error', rej); probe.listen(0, '127.0.0.1', res); });
const rpcUrl = 'http://127.0.0.1:' + probe.address().port;
await new Promise((res, rej) => probe.close(e => e ? rej(e) : res()));
const chainId = 31337;
const lab = new ChainLab({ rpcUrl, anvilPath, dataDir: path.join(outputPath, 'baseline') });
const chain = defineChain({ id: chainId, name: 'Local Anvil', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
  rpcUrls: { default: { http: [rpcUrl] } } });
const client = createPublicClient({ chain, transport: http(rpcUrl), cacheTime: 0, pollingInterval: 30 });

const rpc = (method, params = []) => client.request({ method, params });
const abi = parseAbi([
  'function approve(address spender,uint256 value) returns (bool)',
  'function transfer(address to,uint256 value) returns (bool)',
  'function transferFrom(address from,address to,uint256 value) returns (bool)',
  'function mint(address to,uint256 value)',
  'function allowance(address owner,address spender) view returns (uint256)',
  'function balanceOf(address owner) view returns (uint256)',
  'event Approval(address indexed owner,address indexed spender,uint256 value)',
]);
const approvalEvent = parseAbiItem('event Approval(address indexed owner,address indexed spender,uint256 value)');
// Default public Anvil test accounts. No external wallet or RPC is used.
const localAccount = index => mnemonicToAccount('test test test test test test test test test test test junk', { addressIndex: index });
const [admin, rootOwner, coordOwner, extraOwner, leafA, leafB, named, second, outside] =
  Array.from({ length: 9 }, (_, i) => localAccount(i));
const wallet = createWalletClient({ account: admin, chain, transport: http(rpcUrl), pollingInterval: 30 });
const toJson = value => JSON.stringify(value, (_, x) => typeof x === 'bigint' ? x.toString() : x);
const equal = (a,b) => a?.toLowerCase() === b?.toLowerCase();
const save = async (name, value) => writeFile(path.join(outputPath, name), toJson(value) + '\n');
const sha = async file => createHash('sha256').update(await readFile(file)).digest('hex');
const cases = [];
const credentials = {};
const setup = [];
let root, coordinator, env, tokenA, tokenB, serial = 1;
let longExpiry;
const spenders = { named, second, outside };
const tokenData = (functionName, args) => encodeFunctionData({ abi, functionName, args });
const approve = (spender, amount) => tokenData('approve', [spender.address, amount]);
const execute = (token, data) => createExecution({ target: token, value: 0n, callData: data });
const allowance = (token, owner, spender, blockNumber) => client.readContract({
  address: token, abi, functionName: 'allowance', args: [owner, spender], blockNumber,
});
const balance = (token, account, blockNumber) => client.readContract({
  address: token, abi, functionName: 'balanceOf', args: [account], blockNumber,
});

async function transact({ account, to, data, gas = 3_000_000n }) {
  const hash = await wallet.sendTransaction({ account, to, data, gas });
  const receipt = await client.waitForTransactionReceipt({ hash });
  return { hash, from: account.address, to, data, receipt };
}

async function hybrid(owner, deploySalt) {
  const account = await toMetaMaskSmartAccount({ client, implementation: Implementation.Hybrid,
    deployParams: [owner.address, [], [], []], deploySalt, signer: { account: owner } });
  if (!(await account.isDeployed())) {
    const { factory, factoryData } = await account.getFactoryArgs();
    const tx = await transact({ account: admin, to: factory, data: factoryData });
    assert.equal(tx.receipt.status, 'success');
    setup.push(tx);
  }
  assert.ok(await account.isDeployed());
  return account;
}

function caveats(name, token, amount = 0n) {
  if (name === 'original') return [];
  const builder = createCaveatBuilder(env);
  if (name === 'amount' || name === 'both') {
    builder.addCaveat('allowedCalldata', { startIndex: 36, value: toHex(amount, { size: 32 }) });
  }
  if (name === 'spender' || name === 'both') {
    builder.addCaveat('allowedCalldata', { startIndex: 4, value: pad(named.address) });
  }
  if (name === 'exact') builder.addCaveat('exactExecution', { execution: execute(token, approve(named, amount)) });
  return builder.build();
}

async function signed({ from, to, owner, parent, scope, conditions = [] }) {
  const delegation = createDelegation({ environment: env, from: from.address, to: to.address,
    salt: toHex(serial++, { size: 32 }), ...(parent ? { parentDelegation: parent } : { scope }),
    caveats: conditions });
  const signature = await signDelegation({ privateKey: bytesToHex(owner.getHdKey().privKeyBytes),
    delegation, delegationManager: env.DelegationManager, chainId });
  return { ...delegation, signature };
}

async function makeRoot(name, delegate, token, amount, expiry) {
  const lifetime = createCaveatBuilder(env)
    .addCaveat('limitedCalls', { limit: 10 })
    .addCaveat('timestamp', { afterThreshold: 0, beforeThreshold: expiry ?? longExpiry }).build();
  return signed({ from: root, to: delegate, owner: rootOwner,
    scope: { type: 'functionCall', targets: [token], selectors: ['approve(address,uint256)'] },
    conditions: [...lifetime, ...caveats(name, token, amount)] });
}

async function makeChild(from, owner, to, parent, conditions = []) {
  return signed({ from, to, owner, parent, conditions: [
    ...createCaveatBuilder(env).addCaveat('limitedCalls', { limit: 5 }).build(), ...conditions,
  ] });
}

function register(id, stack, sender) {
  assert.ok(!credentials[id]);
  credentials[id] = { stack, sender: sender.address };
  return { id, stack, sender };
}

async function makePath(id, { name = 'original', token = tokenA, depth = 2, amount = 0n,
  expiry, leaf = leafA, child = 'original' } = {}) {
  const parent = await makeRoot(name, depth === 1 ? leaf : coordinator, token, amount, expiry);
  if (depth === 1) return register(id, [parent], leaf);
  const middle = await makeChild(coordinator, coordOwner, leaf, parent, caveats(child, token));
  return register(id, [middle, parent], leaf);
}

function redemption(grant, token, data) {
  return DelegationManager.encode.redeemDelegations({ delegations: [grant.stack],
    modes: [ExecutionMode.SingleDefault], executions: [[execute(token, data)]] });
}

async function blockState() {
  const block = await client.getBlock({ blockTag: 'latest' });
  const b = block.number;
  const ids = ['named','second','outside'];
  const vals = await Promise.all([
    ...ids.map(id => allowance(tokenA,root.address,spenders[id].address,b)),
    allowance(tokenB,root.address,named.address,b),
    allowance(tokenA,coordinator.address,named.address,b),
    balance(tokenA,root.address,b),
    ...ids.map(id => balance(tokenA,spenders[id].address,b)),
  ]);
  const [namedVal,secondVal,outsideVal,otherToken,otherOwner,rootBalance,namedBalance,secondBalance,outsideBalance] = vals;
  return { number: b, hash: block.hash, timestamp: block.timestamp,
    allowances: { named: namedVal, second: secondVal, outside: outsideVal, otherToken, otherOwner },
    balances: { root: rootBalance, named: namedBalance, second: secondBalance, outside: outsideBalance } };
}

async function redeem({ id, suite, grant, spender = 'named', amount, expect, token = tokenA,
  data = approve(spenders[spender], amount), affects = true, context = {} }) {
  const before = await blockState();
  const sent = await transact({ account: grant.sender, to: env.DelegationManager,
    data: redemption(grant, token, data) });
  const after = await blockState();
  const { receipt } = sent;
  const args = { token, spender, amount, data };
  const approvals = receipt.logs.flatMap(log => {
    if (!equal(log.address, token)) return [];
    try { return [decodeEventLog({ abi: [approvalEvent], data: log.data, topics: log.topics }).args]; }
    catch { return []; }
  });
  const row = { id, suite, credential: grant.id, context, request: args, expect,
    before, after, tx: sent, approvals };
  cases.push(row);
  assert.equal(receipt.status, expect ? 'success' : 'reverted', id);
  assert.equal(after.hash, receipt.blockHash, id);
  for (const [key, value] of Object.entries(before.allowances)) {
    assert.equal(after.allowances[key], expect && affects && key === spender ? amount : value, id + ': ' + key);
  }
  assert.deepEqual(before.balances, after.balances, id);
  assert.equal(approvals.length, expect && affects ? 1 : 0, id);
  if (expect && affects) {
    assert.ok(equal(approvals[0].owner, root.address) && equal(approvals[0].spender, spenders[spender].address), id);
    assert.equal(approvals[0].value, amount, id);
  }
  if (!expect) assert.equal(receipt.logs.length, 0, id);
  return row;
}

async function seed(grantA, grantB, profile) {
  const transactions = [];
  for (const [token, spender, amount, grant] of [
    ...Object.entries(profile).map(([id, val]) => [tokenA, spenders[id], val, grantA]),
    [tokenB, named, 17n, grantB],
  ]) {
    const tx = await transact({ account: grant.sender, to: env.DelegationManager,
      data: redemption(grant, token, approve(spender, amount)) });
    assert.equal(tx.receipt.status, 'success');
    transactions.push(tx);
  }
  setup.push({ profile, transactions, state: await blockState() });
  for (const [id, q] of Object.entries(profile)) {
    assert.equal(setup.at(-1).state.allowances[id], q);
  }
  assert.equal(setup.at(-1).state.allowances.otherToken, 17n);
}

const scriptFolder = path.dirname(fileURLToPath(import.meta.url));
const sourceInfo = JSON.parse(await readFile(path.join(scriptFolder,'source.json'),'utf8'));
const constructorPath = path.join(scriptFolder,'constructors.ts');
assert.equal(await sha(constructorPath), sourceInfo.function_source_sha256);
const constructorSource = await readFile(constructorPath,'utf8');
const anchor = '  const extraCaveats = createCaveatBuilder(environment)\n';
assert.equal(constructorSource.split(anchor).length,2);
const fixedSource = constructorSource.replace(anchor,anchor+
  '    .addCaveat("allowedCalldata", { startIndex: 36, value: toHex(0n, { size: 32 }) })\n');

function loadConstructors(source, timestamp) {
  const js = stripTypeScriptTypes(source,{mode:'strip'}).replace(/^export async function /gm,'async function ');
  return Function('getSmartAccountsEnvironment','getChainId','createCaveatBuilder','createDelegation','toHex','Date',
    js+'\nreturn {createAgentDelegation,createRedelegation};'
  )(getSmartAccountsEnvironment,()=>chainId,createCaveatBuilder,createDelegation,toHex,{now:()=>timestamp*1000});
}

function signer(account, owner) {
  return {address:account.address,signDelegation:({delegation})=>signDelegation({
    privateKey:bytesToHex(owner.getHdKey().privKeyBytes),delegation,
    delegationManager:env.DelegationManager,chainId,
  })};
}

await mkdir(outputPath,{recursive:true});
try {
  await lab.start();
  assert.equal(await client.getChainId(),chainId);
  ({tokenA,tokenB}=lab.env().contracts);
  env=await deploySmartAccountsEnvironment(wallet,client,chain);
  overrideDeployedEnvironment(chainId,'1.3.0',env);
  root=await hybrid(rootOwner,'0x11');
  coordinator=await hybrid(coordOwner,'0x22');
  longExpiry=Number((await client.getBlock()).timestamp)+86400;
  const seedA=await makePath('setup-A',{depth:1,token:tokenA});
  const seedB=await makePath('setup-B',{depth:1,token:tokenB});
  await seed(seedA,seedB,{named:37n,second:13n,outside:23n});
  const starting=await blockState();
  const opts={allowedTargets:[tokenA],maxCalls:10,expiryDays:30};
  const grants={};
  for (const [name,source] of [['original',constructorSource],['patched',fixedSource]]) {
    const api=loadConstructors(source,Number(starting.timestamp));
    const parent=await api.createAgentDelegation(signer(root,rootOwner),coordinator.address,opts);
    const child=await api.createRedelegation(signer(coordinator,coordOwner),parent,leafA.address,
      {maxCalls:5,salt:toHex(999,{size:32})});
    grants[name]=register(name,[child,parent],leafA);
  }
  const unpatched=grants.original.stack[1];
  const patched=grants.patched.stack[1];
  for (const key of ['delegate','delegator','authority']) assert.equal(unpatched[key],patched[key]);
  const extraCaveat=patched.caveats.filter(c=>equal(c.enforcer,env.caveatEnforcers.AllowedCalldataEnforcer));
  assert.equal(extraCaveat.length,1);
  assert.deepEqual(extraCaveat,caveats('amount',tokenA));
  assert.deepEqual(unpatched.caveats,patched.caveats.filter(c=>!equal(c.enforcer,extraCaveat[0].enforcer)));
  const rows=[['named-zero','named',0n],['named-positive','named',91n],
    ['named-decrease','named',36n],['second-zero','second',0n]];
  for (const [kind,grant] of Object.entries(grants)) for (const [id,spender,amount] of rows) {
    const snap=await rpc('evm_snapshot');
    try {
      const result=await redeem({id:kind+'/'+id,suite:'constructor',grant,spender,amount,
        expect:kind==='original'||amount===0n});
      assert.equal(result.before.hash,starting.hash);
    } finally { assert.equal(await rpc('evm_revert',[snap]),true); }
  }
  await save('experiment.json',{source:sourceInfo, chainId, manager:env.DelegationManager, contracts:{tokenA,tokenB},
    root:root.address,coordinator:coordinator.address,spenders:Object.fromEntries(Object.entries(spenders).map(([k,a])=>[k,a.address])),
    sdk:'1.6.0',viem:'2.51.3',node:process.version,anvil:lab.env().versions.anvil,
    labServerSha256:await sha(labBundle),anvilSha256:await sha(anvilPath),extraCaveat:extraCaveat[0],
    starting,setup,credentials,cases});
  console.log(cases.map(x=>[x.id,x.tx.receipt.status,x.after.allowances.named,x.after.allowances.second].join(' ')).join('\n'));
} finally { await lab.stop(); }
