import hashlib
import json
import sys
from pathlib import Path

APPROVAL = "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925"
APPROVE = "0x095ea7b3"

def word(x):
    return format(x, "064x") if isinstance(x, int) else x.lower()[2:].zfill(64)

def verify(path):
    d = json.loads(Path(path).read_text(encoding="utf-8"))
    a, b = [d["credentials"][k]["stack"] for k in ("original","patched")]
    assert len(a) == len(b) == 2
    extra = d["extraCaveat"]
    assert extra["terms"] == "0x"+word(36)+word(0)
    assert [c for c in b[1]["caveats"] if c != extra] == a[1]["caveats"]
    assert len(b[1]["caveats"]) == len(a[1]["caveats"]) + 1
    assert a[0]["caveats"] == b[0]["caveats"]
    for stack in (a,b):
        assert stack[1]["delegator"].lower() == d["root"].lower()
        assert stack[0]["delegator"].lower() == stack[1]["delegate"].lower() == d["coordinator"].lower()
        assert all(len(c["signature"]) == 132 for c in stack)
    source = Path(__file__).resolve().parent / "constructors.ts"
    assert hashlib.sha256(source.read_bytes()).hexdigest() == d["source"]["function_source_sha256"]
    tests = {"named-zero":("named",0),"named-positive":("named",91),
             "named-decrease":("named",36),"second-zero":("second",0)}
    rows = {r["id"]:r for r in d["cases"]}
    assert len(rows) == len(d["cases"]) == 8
    assert set(rows) == {f"{g}/{t}" for g in ("original","patched") for t in tests}
    assert len({r["tx"]["hash"] for r in rows.values()}) == 8
    for id, row in rows.items():
        grant, request = id.split("/")
        spender, amount = tests[request]
        ok = grant=="original" or amount==0
        call = APPROVE+word(d["spenders"][spender])+word(amount)
        assert row["request"]["data"] == call
        assert row["request"]["token"] == d["contracts"]["tokenA"]
        assert row["tx"]["to"].lower() == d["manager"].lower()
        assert row["tx"]["from"].lower() == d["credentials"][grant]["sender"].lower()
        assert (d["contracts"]["tokenA"].lower()[2:]+word(0)+call[2:]) in row["tx"]["data"].lower()
        assert row["before"] == d["starting"]
        assert row["before"]["allowances"] == dict(named="37",second="13",outside="23",otherToken="17",otherOwner="0")
        r = row["tx"]["receipt"]
        assert r["status"] == ("success" if ok else "reverted")
        assert r["transactionHash"] == row["tx"]["hash"]
        assert r["blockHash"] == row["after"]["hash"]
        assert int(r["blockNumber"]) == int(row["before"]["number"])+1 == int(row["after"]["number"])
        expected = row["before"]["allowances"].copy()
        if ok:
            expected[spender] = str(amount)
            assert sum(log["topics"] == [APPROVAL,"0x"+word(d["root"]),"0x"+word(d["spenders"][spender])]
                       and int(log["data"],16)==amount and log["address"].lower()==d["contracts"]["tokenA"].lower()
                       for log in r["logs"]) == 1
        else:
            assert not r["logs"]
        assert row["after"]["allowances"] == expected
        assert row["before"]["balances"] == row["after"]["balances"]
    return rows

if __name__ == "__main__":
    rows = verify(sys.argv[1])
    print("Verified",len(rows),"included receipts, source hash, caveat words, same starting block, and allowance observations.")
