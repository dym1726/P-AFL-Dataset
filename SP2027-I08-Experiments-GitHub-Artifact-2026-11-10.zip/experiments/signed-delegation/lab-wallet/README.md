# Web3 Agent Lab V0.16.0 allowance experiment

This archive contains 15 executed local scenarios on Anvil chain 31337. Twelve are paired task runs and three are single-field rejection controls. Each pair shares a seeded before-block hash. Setup receipts are archived separately inside each case. The two already-satisfied cases had no attempted transaction. The three rejected requests were prepared, then blocked by the external revoke adapter before the Lab wallet signed or broadcast them.

The fixed-amount trials use the release's deterministic plan and built-in checker. The revoke trials use the release's ChainLab transaction path plus the adapter supplied in this archive. The server bundle was byte-identical to the official V0.16.0 Windows x64 release. The experiment did not use LLM inference or add a MetaMask delegation credential to the Lab wallet. The paper's separate I08 experiments cover the on-chain delegation mechanism.

## Inspect saved records

Use Python 3.10 or later. From this directory run:

    python verify-evidence.py .

The script verifies file hashes and decodes raw RPC allowance outputs, mined calldata, and approval logs. It checks block links, paired starts, unchanged controls, no-op and denial records. These checks recompute the outcome from retained evidence. For new native transactions, rerun the harness below.

## Reproduce on Windows

Download and verify the [V0.16.0 Windows x64 ZIP](https://github.com/ZhanHaowen/Web3-Agent-Lab/releases/tag/V0.16.0). The expected release SHA-256 is in manifest.json. Extract it to a short path such as C:/Web3Lab. From this directory in PowerShell run:

    & 'C:/Web3Lab/runtime/node.exe' ./run-allowances.mjs C:/Web3Lab C:/Web3Lab/runtime/anvil.exe ./rerun
    python verify-evidence.py ./rerun --write

The harness creates its own loopback Anvil process and shuts it down on exit. Transaction and block identifiers can differ across reruns. Compare scope, call data, allowance values, and the paired outcomes. The four unaffected allowances were preset to nonzero values and checked in all 15 scenarios.
