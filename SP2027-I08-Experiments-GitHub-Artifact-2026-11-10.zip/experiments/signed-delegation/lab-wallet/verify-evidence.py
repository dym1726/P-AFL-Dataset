"""Check the saved allowance experiment from calldata and raw RPC records."""
import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

BASE = 1_000_000
APPROVE = "0x095ea7b3"
ALLOWANCE = "0xdd62ed3e"
APPROVAL_EVENT = "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925"


def word(value):
    return value.lower().removeprefix("0x").zfill(64)


def expected_case(case_id):
    fixture, mode = case_id.rsplit("-", 1)
    if mode not in ("revoke", "fixed"):
        return 37 * BASE, 37 * BASE, "blocked-before-signing"
    start, fixed = {
        "decrease": (37 * BASE, 20 * BASE),
        "increase": (5 * BASE, 20 * BASE),
        "empty": (0, 20 * BASE),
        "already-exact": (20 * BASE, 20 * BASE),
        "fractional": (1_250_000, 500_000),
        "minimum": (1, 2),
    }[fixture]
    end = 0 if mode == "revoke" else fixed
    return start, end, "no-op" if start == end else "mined"


def verify(root):
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    cases = manifest["cases"]
    assert len({c["id"] for c in cases}) == len(cases) == 15
    assert manifest["chainId"] == 31337 and manifest["sourceTag"] == "V0.16.0"
    keys = {k["id"]: k for k in manifest["observedKeys"]}
    target = keys["target"]
    guards = {k: int(v) * BASE for k, v in (
        ("other-spender", 13), ("other-token", 11), ("other-owner", 7), ("other-token-spender", 17)
    )}
    assert len({tuple(k[x].lower() for x in ("token", "owner", "spender")) for k in keys.values()}) == 5
    assert keys["other-spender"]["token"] == target["token"]
    assert keys["other-spender"]["owner"] == target["owner"]
    assert keys["other-spender"]["spender"] != target["spender"]
    seen_initial, seen_hashes, rows = {}, set(), []
    for item in cases:
        case_id = item["id"]
        doc = json.loads((root / f"{case_id}.json").read_text(encoding="utf-8"))
        assert doc["id"] == case_id
        start, end, status = expected_case(case_id)
        for phase, amount in (("before", start), ("after", end)):
            state = doc[phase]
            assert state["state"]["blockHash"] == state["block"]["hash"]
            assert int(state["block"]["number"], 16) == int(state["state"]["blockNumber"])
            assert len(state["reads"]) == len(keys)
            reads = {read["id"]: read for read in state["reads"]}
            assert set(reads) == set(keys)
            for key_id, key in keys.items():
                read = reads[key_id]
                assert read["request"]["to"].lower() == key["token"].lower()
                assert read["request"]["data"] == ALLOWANCE + word(key["owner"]) + word(key["spender"])
                assert read["blockNumber"] == state["block"]["number"]
                assert read["blockHash"] == state["block"]["hash"]
                assert len(read["raw"]) == 66
                assert int(read["raw"], 16) == int(read["value"]) == (
                    amount if key_id == "target" else guards[key_id]
                )
        before, after = doc["before"]["block"], doc["after"]["block"]
        assert item["matchedInitialBlock"] == before["hash"]
        assert (int(item["targetBefore"]), int(item["targetAfter"]), item["status"]) == (start, end, status)
        for balance in ("agentA", "agentB", "recipientA", "recipientB"):
            assert doc["before"]["state"]["balances"][balance] == doc["after"]["state"]["balances"][balance]
        if doc["condition"] in ("revoke", "fixed"):
            fixture = doc["fixture"]["id"]
            previous = seen_initial.setdefault(fixture, before["hash"])
            assert previous == before["hash"]
        if doc["condition"] == "fixed":
            assert doc["nativeCheck"]["status"] == "success"
            assert all(a["passed"] for a in doc["nativeCheck"]["assertions"])
        event_types = [e["type"] for e in doc["events"]]
        if status == "mined":
            assert len(doc["raw"]) == len(doc["transactions"]) == 1
            assert event_types.count("tx.broadcast") == event_types.count("tx.receipt") == 1
            transaction, receipt = (doc["raw"][0][k] for k in ("transaction", "receipt"))
            assert transaction["hash"] == receipt["transactionHash"] == item["tx"]
            assert item["tx"] not in seen_hashes
            seen_hashes.add(item["tx"])
            assert receipt["status"] == "0x1" and after["parentHash"] == before["hash"]
            assert transaction["blockHash"] == receipt["blockHash"] == after["hash"]
            assert receipt["blockNumber"] == after["number"]
            assert item["tx"] in after["transactions"]
            assert transaction["from"].lower() == target["owner"].lower()
            assert transaction["to"].lower() == target["token"].lower()
            assert int(transaction["value"], 16) == 0
            assert transaction["input"] == APPROVE + word(target["spender"]) + format(end, "064x")
            assert int(item["gas"]) == int(receipt["gasUsed"], 16)
            matching = [log for log in receipt["logs"] if log["address"].lower() == target["token"].lower()
                        and log["topics"] == [APPROVAL_EVENT, "0x" + word(target["owner"]),
                                               "0x" + word(target["spender"])]
                        and int(log["data"], 16) == end]
            assert len(matching) == 1
        else:
            assert before["hash"] == after["hash"]
            assert not doc["raw"] and not doc["transactions"]
            assert "tx.broadcast" not in event_types and "tx.receipt" not in event_types
            if status == "blocked-before-signing":
                assert doc["denial"] == "OUTSIDE_REVOKE_SCOPE"
                prepared = [e["payload"] for e in doc["events"] if e["type"] == "tx.prepared"]
                assert len(prepared) == 1
                call = prepared[0]
                assert call["from"].lower() == target["owner"].lower()
                target_changed = call["to"].lower() != target["token"].lower()
                spender_changed = call["data"][10:74] != word(target["spender"])
                amount_changed = int(call["data"][74:], 16) != 0
                assert (amount_changed, spender_changed, target_changed) == {
                    "positive-amount": (True, False, False),
                    "different-spender": (False, True, False),
                    "different-token": (False, False, True),
                }[doc["condition"]]
            else:
                assert not doc["calls"] and not doc["events"]
        rows.append({
            "case": case_id, "mode": doc["condition"], "target_before_base_units": start,
            "target_after_base_units": end, "status": status,
            "block_before": before["hash"], "block_after": after["hash"],
            "tx": item["tx"], "gas": item["gas"], "unchanged_other_allowances": len(guards),
        })
    counts = Counter(row["status"] for row in rows)
    assert counts == {"mined": 10, "no-op": 2, "blocked-before-signing": 3}
    summary = {
        "cases": len(rows), "matched_pairs": len(seen_initial), "distinct_mined_transactions": len(seen_hashes),
        "status_counts": dict(counts), "real_revocations": sum(
            row["mode"] == "revoke" and row["target_before_base_units"] > 0 and row["target_after_base_units"] == 0
            for row in rows
        ), "protected_allowance_comparisons": sum(row["unchanged_other_allowances"] for row in rows),
    }
    if "--write" in sys.argv:
        with (root / "case-summary.csv").open("w", encoding="utf-8", newline="") as out:
            writer = csv.DictWriter(out, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        (root / "independent-check.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    directory = Path(sys.argv[1])
    checksums = directory / "SHA256SUMS.txt"
    if checksums.exists():
        for line in checksums.read_text(encoding="utf-8").splitlines():
            digest, filename = line.split("  ", 1)
            assert hashlib.sha256((directory / filename).read_bytes()).hexdigest() == digest, filename
    verify(directory)
