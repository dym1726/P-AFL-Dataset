import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createServer } from 'node:net';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [labPath, anvilPath, evidencePath] = process.argv.slice(2).map(x => path.resolve(x));
process.env.LAB_LIBRARY_ONLY = '1';
process.env.LAB_AGENT_WORKER = '1';
process.env.LAB_ROOT = labPath;
process.env.LAB_DATA_DIR = path.join(evidencePath, 'lab-internal');
const modulePath = path.join(labPath, 'dist', 'server.mjs');
const { ChainLab, checkTask, scriptedCalls, parseAbi, encodeFunctionData, decodeFunctionData } =
  await import(pathToFileURL(modulePath).href);
const abi = parseAbi([
  'function allowance(address owner,address spender) view returns (uint256)',
  'function approve(address spender,uint256 amount) returns (bool)',
]);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const equalAddress = (a, b) => a?.toLowerCase() === b?.toLowerCase();
const serialize = value => JSON.stringify(value, (_, val) => typeof val === 'bigint' ? val.toString() : val, 2) + '\n';
const blocked = 'OUTSIDE_REVOKE_SCOPE';
const free = createServer();
await new Promise((resolve, reject) => {
  free.once('error', reject);
  free.listen(0, '127.0.0.1', resolve);
});
const port = free.address().port;
await new Promise((resolve, reject) => free.close(error => error ? reject(error) : resolve()));
const chain = new ChainLab({ rpcUrl: 'http://127.0.0.1:' + port, anvilPath, dataDir: path.join(evidencePath, 'baseline') });
await mkdir(evidencePath, { recursive: true });
const save = (name, value) => writeFile(path.join(evidencePath, name + '.json'), serialize(value));
const toolCall = (token, spender, amount) => ({ token, spender, amount });
const fixtures = [
  { id: 'decrease', initial: '37', approve: '20', initialUnits: '37000000', approveUnits: '20000000' },
  { id: 'increase', initial: '5', approve: '20', initialUnits: '5000000', approveUnits: '20000000' },
  { id: 'empty', initial: '0', approve: '20', initialUnits: '0', approveUnits: '20000000' },
  { id: 'already-exact', initial: '20', approve: '20', initialUnits: '20000000', approveUnits: '20000000' },
  { id: 'fractional', initial: '1.25', approve: '0.5', initialUnits: '1250000', approveUnits: '500000' },
  { id: 'minimum', initial: '0.000001', approve: '0.000002', initialUnits: '1', approveUnits: '2' },
];
const cases = [];
try {
  await chain.start();
  const { contracts, accounts, versions, chainId } = chain.env();
  assert.equal(chainId, 31337);
  const { tokenA, tokenB, amm, vault } = contracts;
  const { agent, recipient, deployer } = accounts;
  const observedKeys = [
    { id: 'target', token: tokenA, owner: agent, spender: amm, expectedGuard: null },
    { id: 'other-spender', token: tokenA, owner: agent, spender: recipient, expectedGuard: '13000000' },
    { id: 'other-token', token: tokenB, owner: agent, spender: amm, expectedGuard: '11000000' },
    { id: 'other-owner', token: tokenA, owner: deployer, spender: amm, expectedGuard: '7000000' },
    { id: 'other-token-spender', token: tokenB, owner: agent, spender: vault, expectedGuard: '17000000' },
  ];
  const rpc = (method, params) => chain.publicClient.request({ method, params });
  const observe = async () => {
    const state = await chain.state();
    const blockNumber = '0x' + BigInt(state.blockNumber).toString(16);
    const block = await rpc('eth_getBlockByNumber', [blockNumber, false]);
    assert.equal(block.hash, state.blockHash);
    const reads = await Promise.all(observedKeys.map(async ({ id, token, owner, spender }) => {
      const request = { to: token, data: encodeFunctionData({ abi, functionName: 'allowance', args: [owner, spender] }) };
      const raw = await rpc('eth_call', [request, blockNumber]);
      return { id, request, blockNumber, blockHash: block.hash, raw, value: BigInt(raw).toString() };
    }));
    return { state, block, reads, allowances: Object.fromEntries(reads.map(({ id, value }) => [id, value])) };
  };
  const seed = async fixture => {
    await chain.reset();
    const approvals = [];
    for (const args of [
      toolCall('A', recipient, '13'), toolCall('B', 'amm', '11'), toolCall('B', 'vault', '17'),
      ...(fixture.initialUnits === '0' ? [] : [toolCall('A', 'amm', fixture.initial)]),
    ]) {
      const tx = await chain.execute('approve_token', args);
      assert.equal(tx.status, 'success');
      approvals.push(tx);
    }
    const hash = await rpc('eth_sendTransaction', [{
      from: deployer, to: tokenA,
      data: encodeFunctionData({ abi, functionName: 'approve', args: [amm, 7_000_000n] }),
      gas: '0x186a0',
    }]);
    const otherOwnerReceipt = await rpc('eth_getTransactionReceipt', [hash]);
    assert.equal(otherOwnerReceipt.status, '0x1');
    return { approvals, otherOwnerReceipt };
  };
  const scopeGuard = descriptor => {
    const decoded = decodeFunctionData({ abi, data: descriptor.data });
    if (!equalAddress(descriptor.from, agent) || !equalAddress(descriptor.to, tokenA) ||
        decoded.functionName !== 'approve' || !equalAddress(decoded.args[0], amm) || decoded.args[1] !== 0n) {
      throw new Error(blocked);
    }
  };

  async function run(fixture, condition, setup, negativeArgs) {

    const before = await observe();
    assert.equal(before.allowances.target, fixture.initialUnits);
    for (const key of observedKeys.slice(1)) assert.equal(before.allowances[key.id], key.expectedGuard);
    const events = [];
    const hooks = { emit: async (type, payload, links) => { events.push({ type, payload, links }); } };
    const firstTx = chain.transactions.length;
    let calls, denial = null;
    if (condition === 'fixed') {
      calls = scriptedCalls('approve', [], before.state, 'continuous', { amount: fixture.approve });
    } else {
      hooks.beforeSubmit = scopeGuard;
      calls = negativeArgs ? [{ name: 'approve_token', args: negativeArgs }]
        : fixture.initialUnits === '0' ? [] : [{ name: 'approve_token', args: toolCall('A', 'amm', '0') }];
    }
    for (const { name, args } of calls) {
      try { await chain.execute(name, args, hooks); }
      catch (error) {
        if (error.message !== blocked) throw error;
        denial = error.message;
      }
    }
    const transactions = chain.transactions.slice(firstTx);
    const after = await observe();
    const raw = await Promise.all(transactions.map(async tx => ({
      transaction: await rpc('eth_getTransactionByHash', [tx.hash]),
      receipt: await rpc('eth_getTransactionReceipt', [tx.hash]),
    })));
    const nativeCheck = condition === 'fixed' ? checkTask('approve', before.state, after.state, transactions,
      '', [], { experimentMode: 'continuous', taskParameters: { amount: fixture.approve } }) : null;
    const targetExpected = negativeArgs ? fixture.initialUnits : condition === 'fixed' ? fixture.approveUnits : '0';
    const exact = after.allowances.target === targetExpected;
    const guardsIntact = observedKeys.slice(1).every(key => before.allowances[key.id] === after.allowances[key.id]);
    const expectedTransactions = negativeArgs ? 0 : Number(fixture.initialUnits !== targetExpected);
    const approval = raw.every(({ receipt, transaction }) => {
      const decoded = decodeFunctionData({ abi, data: transaction.input });
      return receipt.status === '0x1' && receipt.blockHash === after.block.hash
        && equalAddress(transaction.from, agent) && equalAddress(transaction.to, tokenA)
        && decoded.functionName === 'approve' && equalAddress(decoded.args[0], amm)
        && decoded.args[1].toString() === targetExpected;
    });
    const negativePreserved = !negativeArgs || (denial === blocked && before.block.hash === after.block.hash
      && events.some(x => x.type === 'tx.prepared') && events.every(x => x.type !== 'tx.broadcast'));
    const erc20BalancesIntact = ['agentA','agentB','recipientA','recipientB'].every(
      key => before.state.balances[key] === after.state.balances[key]);
    const assertions = { exact, guardsIntact, approved: approval && transactions.length === expectedTransactions,
      negativePreserved, erc20BalancesIntact, nativeCheck: nativeCheck ? nativeCheck.status === 'success' : null };
    const id = fixture.id + '-' + condition;
    const result = { id, condition, fixture, calls, setup, before, after, transactions, raw, events,
      denial, targetExpected, assertions, nativeCheck };
    await save(id, result);
    assert.ok(Object.values(assertions).every(value => value !== false), id + ' failed: ' + JSON.stringify(assertions));
    cases.push({ id, condition, targetBefore: before.allowances.target, targetAfter: after.allowances.target,
      guardsIntact, status: denial ? 'blocked-before-signing' : raw.length ? 'mined' : 'no-op',
      tx: raw[0]?.receipt.transactionHash ?? null, gas: raw.length ? BigInt(raw[0].receipt.gasUsed).toString() : null,
      matchedInitialBlock: before.block.hash });
    console.log(id, cases.at(-1).status, before.allowances.target, after.allowances.target);
  }

  for (const fixture of fixtures) {
    const setup = await seed(fixture);
    const id = await chain.snapshot();
    await run(fixture, 'revoke', setup);
    await chain.restore(id);
    await run(fixture, 'fixed', setup);
    assert.equal(cases.at(-1).matchedInitialBlock, cases.at(-2).matchedInitialBlock);
  }
  const negativeSetup = await seed(fixtures[0]);
  await run(fixtures[0], 'positive-amount', negativeSetup, toolCall('A', 'amm', '20'));
  await run(fixtures[0], 'different-spender', negativeSetup, toolCall('A', recipient, '0'));
  await run(fixtures[0], 'different-token', negativeSetup, toolCall('B', 'amm', '0'));
  await save('manifest', { sourceTag: 'V0.16.0', sourceCommit: 'db2899fb2e0ec09771f51f1ff1e88ae30725eb50',
    releaseSha256: '289ffd557c417f22a72ab3b19589f37e999bd7d2c9129dca098d06cecde19609',
    serverSha256: sha(await readFile(modulePath)), anvilSha256: sha(await readFile(anvilPath)),
    node: process.version, versions, chainId, contracts, accounts, observedKeys, cases });
} finally {
  await chain.stop();
}
