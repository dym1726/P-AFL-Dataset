# I08 signed delegation experiments and Lab controls

The signed-manager directory contains the new experiment runner, npm lockfile, offline verifier, and evidence for Section 4 of the paper. The lab-wallet directory contains the earlier deterministic Lab controls from Section 3.3, their code, and their evidence.

## Audit the saved signed-manager records

From the archive root, with Python 3.10 or later:

    python signed-manager/verify-signed.py signed-manager/evidence

The verifier reconstructs the full matrix and its policy-specific errors. It checks credential paths, request calldata, receipts, approval events, allowance and balance reads, management flags and events, and event order in the batch suite. The verifier compares captured evidence. The native rerun below executes new transactions.

## Rerun the native signed experiments on Windows

1. Download and extract the [official Web3 Agent Lab V0.16.0 Windows x64 release](https://github.com/ZhanHaowen/Web3-Agent-Lab/releases/tag/V0.16.0) to a short directory such as C:/Web3Lab. The release ZIP SHA-256 is 289ffd557c417f22a72ab3b19589f37e999bd7d2c9129dca098d06cecde19609. The experiment imports the release's bundled server module in library mode. The published server bundle and the one used in the run are byte-identical.
2. From the archive root, run the following in PowerShell with npm available. The runner starts and stops its own loopback Anvil instance. Use a fresh output directory on each invocation.

    Set-Location ./signed-manager
    npm ci --no-audit --no-fund --ignore-scripts
    & 'C:/Web3Lab/runtime/node.exe' ./run-signed.mjs C:/Web3Lab C:/Web3Lab/runtime/anvil.exe ./rerun
    python ./verify-signed.py ./rerun --write

The first stage seeds the test token via separate signed credentials. That setup is excluded from experiment counts. The harness uses public development-only test accounts. It does not contact hosted RPCs, inference APIs, or a production bundler. It evaluates Hybrid accounts and the SDK-shipped manager and enforcers on the Lab token implementation. Credentials are reconstructed test policies.

## Files and counts

- evidence/cases.jsonl contains 390 included single-request executions. There are 163 successful and 227 reverted receipts. The use of snapshots yields 265 distinct transaction hashes. Identify rows by suite and case ID when hashes recur.
- evidence/management.json contains five credential-management transactions. Four authorized calls succeeded and one unauthorized call reverted.
- evidence/batches.json contains 20 two-entry manager transactions. Nine succeeded and 11 reverted.
- evidence/credentials.json contains signed test credentials. evidence/setup.json contains seeding and other setup receipts. evidence/manifest.json pins runtime identities and deployed code hashes.
- evidence/audit.json is the verifier's aggregate report. evidence/summary.csv provides row-level lookup for the 390 single-request executions.
- SHA256SUMS.txt contains the digest of each archived file. Verify these digests before comparing artifacts. New runs can have different transaction hashes or signature-dependent gas costs.

The previous Lab wallet experiment is separate. Its README gives the matching rerun and audit commands.
