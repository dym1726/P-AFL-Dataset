"""Independently recompute decisions and state effects from archived receipts."""
import csv
import json
import sys
from collections import Counter
from itertools import product
from pathlib import Path

APPROVE = "095ea7b3"
TRANSFER = "a9059cbb"
SPEND = "23b872dd"
APPROVAL_EVENT = "0x8c5be1e5ebec7d5bd14f71427d1e84f3dd0314c0f7b2291e5b200ac8c7c3b925"
AMOUNTS = (0, 1, 36, 37, 91, 2**256 - 1)
NAMES = ("original", "spender", "amount", "both", "exact")
PROFILES = ("positive", "empty", "mixed")
SPENDERS = ("named", "second", "outside")
LIFECYCLES = ("old-only", "repaired-only", "coexist", "expired-old")
DISABLE_MODES = ("untouched", "disable-child", "disable-root", "wrong-issuer", "reenable-root")


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def word(value):
    if isinstance(value, int):
        return format(value, "064x")
    return value.lower().removeprefix("0x").zfill(64)


def encode(selector, *args):
    return "0x" + selector + "".join(map(word, args))


def expect_for(suite, parts):
    if suite == "matrix":
        _, grant, spender, amount = parts
        amount_ok = grant in ("original", "spender") or int(amount) == 0
        spender_ok = grant in ("original", "amount") or spender == "named"
        return amount_ok and spender_ok
    if suite == "scope-control":
        return False
    if suite == "branches":
        mode, branch, amount = parts
        return int(amount) == 0 or mode == "original" or (mode == "oneChild" and branch == "B")
    if suite == "fixed20":
        _, spender, amount = parts
        return spender == "named" and int(amount) == 20
    if suite == "cost":
        return True
    if suite == "disabled-grants":
        mode, branch, amount = parts
        if branch == "repaired":
            return int(amount) == 0
        return mode != "disable-root" and (mode, branch) != ("disable-child", "A")
    if suite == "lifecycle":
        mode, step = parts
        return step == "revoke" or step != "first-spend" and mode in ("old-only", "coexist")
    raise ValueError(suite)


def verify(folder, write=False):
    manifest = read(folder / "manifest.json")
    assert not manifest["smoke"]
    chain = manifest["contracts"]
    addr = manifest["spenders"]
    credentials = read(folder / "credentials.json")
    rows = [json.loads(line) for line in (folder / "cases.jsonl").read_text(encoding="utf-8").splitlines()]
    expected = {
        "matrix": {"/".join(map(str, p)) for p in product(PROFILES, NAMES, SPENDERS, AMOUNTS)},
        "scope-control": {"/".join(p) for p in product(NAMES, ("token", "selector"))},
        "branches": {"/".join(p) for p in product(("original", "root", "oneChild", "bothChildren"), ("A", "B"), ("0", "91"))},
        "fixed20": {"/".join(p) for p in product(("positive", "empty"), ("named", "second"), ("0", "20", "21"))},
        "cost": {"/".join(p) for p in product(PROFILES, ("1", "2", "3"), ("original", "amount", "both", "exact"))},
        "lifecycle": {"/".join(p) for p in product(LIFECYCLES, ("revoke", "first-spend", "reapply", "second-spend"))},
    }
    expected["disabled-grants"] = {"/".join(p) for p in product(DISABLE_MODES, ("A","B","repaired"), ("0","91"))}
    rowmap = {(row["suite"], row["id"]): row for row in rows}
    assert len(rowmap) == len(rows) == manifest["total"] == sum(map(len, expected.values()))
    assert set(rowmap) == {(s, case) for s, ids in expected.items() for case in ids}
    distinct_hashes = len({r["tx"]["hash"] for r in rows})
    accepts = Counter()
    keys_preserved = 0
    output = []
    for row in rows:
        suite, case = row["suite"], row["id"]
        parts = case.split("/")
        expect = expect_for(suite, parts)
        before, after = row["before"], row["after"]
        tx, req = row["tx"], row["request"]
        receipt = tx["receipt"]
        assert receipt["transactionHash"] == tx["hash"]
        assert receipt["blockHash"] == after["hash"]
        assert int(receipt["blockNumber"]) == int(after["number"]) == int(before["number"]) + 1
        assert row["expect"] == expect
        assert receipt["status"] == ("success" if expect else "reverted")
        if not expect:
            assert not receipt["logs"]
        accepts[suite] += int(expect)
        old, new = ({k:int(v) for k,v in x["allowances"].items()} for x in (before,after))
        amounts_before, amounts_after = ({k:int(v) for k,v in x["balances"].items()} for x in (before,after))
        amount = int(req["amount"])
        if req.get("action") == "spend":
            assert tx["data"].lower() == encode(SPEND, chain["root"], addr["named"], 55)
            assert tx["to"].lower() == chain["tokenA"].lower() and tx["from"].lower() == addr["named"].lower()
            affected = "named" if expect else None
            value = old["named"] - 55
            assert amounts_after["root"] - amounts_before["root"] == (-55 if expect else 0)
            assert amounts_after["named"] - amounts_before["named"] == (55 if expect else 0)
            assert all(amounts_after[k] == amounts_before[k] for k in ("second","outside"))
        else:
            credential = credentials[row["credential"]]
            assert tx["to"].lower() == chain["manager"].lower()
            assert tx["from"].lower() == credential["sender"].lower()
            assert credential["stack"][0]["delegate"].lower() == tx["from"].lower()
            assert credential["stack"][-1]["delegator"].lower() == chain["root"].lower()
            assert all(len(link["signature"]) == 132 for link in credential["stack"])
            assert all(a["delegator"].lower() == b["delegate"].lower()
                       for a,b in zip(credential["stack"],credential["stack"][1:]))
            if suite == "scope-control":
                assert req["token"] == chain["tokenB" if parts[-1] == "token" else "tokenA"]
            else:
                assert req["token"] == chain["tokenA"]
            assert req["data"].lower() == (
                encode(TRANSFER, addr["named"],0) if suite == "scope-control" and parts[-1] == "selector"
                else encode(APPROVE,addr[req["spender"]],amount)
            )
            assert (req["token"].lower()[2:] + word(0) + req["data"].lower()[2:]) in tx["data"].lower()
            assert amounts_after == amounts_before
            affected = req["spender"] if expect else None
            value = amount
            if expect:
                assert sum(log["address"].lower() == chain["tokenA"].lower()
                    and log["topics"] == [APPROVAL_EVENT, "0x"+word(chain["root"]), "0x"+word(addr[affected])]
                    and int(log["data"],16) == amount for log in receipt["logs"]) == 1
        for key in old:
            assert new[key] == (value if key == affected else old[key])
        assert old["otherToken"] == new["otherToken"] == 17
        assert old["otherOwner"] == new["otherOwner"] == 29
        keys_preserved += sum(key != affected for key in old)
        output.append({"suite":suite,"case":case,"outcome":receipt["status"],"tx_hash":tx["hash"],
                       "before_block":before["hash"],"after_block":after["hash"],
                       "gas":int(receipt["gasUsed"]),"calldata_bytes":(len(tx["data"])-2)//2,
                       "named_before":old["named"],"named_after":new["named"]})
    matrix = [r for r in rows if r["suite"] == "matrix"]
    matrix_stats = {}
    for name in NAMES:
        rr = [r for r in matrix if r["context"]["name"] == name]
        assert len(rr) == 54
        record = {}
        for policy in ("named-only","token-wide"):
            intended = lambda r: int(r["request"]["amount"]) == 0 and (
                policy == "token-wide" or r["request"]["spender"] == "named")
            accepted = lambda r: r["tx"]["receipt"]["status"] == "success"
            record[policy] = {
                "outside":sum(accepted(r) and not intended(r) for r in rr),
                "missed":sum(not accepted(r) and intended(r) for r in rr),
            }
        record["accepted"] = sum(accepted(r) for r in rr)
        record["positive_accepted"] = sum(accepted(r) and int(r["request"]["amount"])>0 for r in rr)
        record["nonzero_still_positive_from_decrease"] = sum(
            accepted(r) and 0<int(r["request"]["amount"])<int(r["before"]["allowances"][r["request"]["spender"]]) for r in rr)
        record["actual_clears"] = sum(accepted(r) and int(r["request"]["amount"])==0 and
            int(r["before"]["allowances"][r["request"]["spender"]])>0 for r in rr)
        matrix_stats[name] = record
    for profile in PROFILES:
        block_hashes = {r["before"]["hash"] for r in matrix if r["context"]["profile"]==profile}
        assert len(block_hashes) == 1
        profile_rows = [r for r in matrix if r["context"]["profile"]==profile]
        assert all(all(int(r["before"]["allowances"][key])==int(value)
                       for key,value in manifest["profiles"][profile].items()) for r in profile_rows)
        assert len({r["before"]["hash"] for r in rows if r["suite"]=="cost" and r["context"]["profile"]==profile})==1
    branch_stats = {}
    for mode in ("original","root","oneChild","bothChildren"):
        a = rowmap[("branches",mode+"/A/91")]
        b = rowmap[("branches",mode+"/B/91")]
        assert credentials[a["credential"]]["stack"][-1]==credentials[b["credential"]]["stack"][-1]
        assert credentials[a["credential"]]["stack"][0]["delegate"]!=credentials[b["credential"]]["stack"][0]["delegate"]
        assert len({rowmap[("branches",f"{mode}/{branch}/{amount}")]["before"]["hash"]
                    for branch,amount in product("AB",(0,91))})==1
        branch_stats[mode]=[a["tx"]["receipt"]["status"],b["tx"]["receipt"]["status"]]
    gas = {}
    for depth in (1,2,3):
        gas[depth] = {}
        for name in ("original","amount","both","exact"):
            r = [rowmap[("cost",f"{profile}/{depth}/{name}")] for profile in PROFILES]
            assert all(len(credentials[x["credential"]]["stack"])==depth for x in r)
            gas[depth][name] = {
                "by_profile": {profile:int(x["tx"]["receipt"]["gasUsed"]) for profile,x in zip(PROFILES,r)},
                "bytes": (len(r[0]["tx"]["data"])-2)//2,
            }
    lifecycle = {}
    for mode in LIFECYCLES:
        steps = {step:rowmap[("lifecycle",f"{mode}/{step}")] for step in
                 ("revoke","first-spend","reapply","second-spend")}
        assert steps["revoke"]["after"]["hash"] == steps["first-spend"]["before"]["hash"]
        assert steps["reapply"]["after"]["hash"] == steps["second-spend"]["before"]["hash"]
        assert (steps["first-spend"]["after"]["hash"] != steps["reapply"]["before"]["hash"]) == (mode=="expired-old")
        lifecycle[mode] = {"reapply":steps["reapply"]["tx"]["receipt"]["status"],
                           "after_reapply":steps["reapply"]["after"]["allowances"]["named"],
                           "after_spend":steps["second-spend"]["after"]["allowances"]["named"],
                           "spender_balance":steps["second-spend"]["after"]["balances"]["named"],
                           "first_spend":steps["first-spend"]["tx"]["receipt"]["status"]}
    management = read(folder / "management.json")
    assert len(management) == 5
    actual_management = {}
    flags = {
        ("disable-child","disableDelegation"):(False,True,"success"),
        ("disable-root","disableDelegation"):(False,True,"success"),
        ("wrong-issuer","disableDelegation"):(False,False,"reverted"),
        ("reenable-root","disableDelegation"):(False,True,"success"),
        ("reenable-root","enableDelegation"):(True,False,"success"),
    }
    for rec in management:
        key = rec["mode"],rec["operation"]
        assert key not in actual_management
        tx, target = rec["tx"],rec["target"]
        receipt = tx["receipt"]
        assert tx["hash"] == receipt["transactionHash"]
        assert tx["to"].lower() == chain["manager"].lower()
        assert tx["from"].lower() == manifest["delegates"]["A"].lower()
        assert (rec["beforeFlag"],rec["afterFlag"],receipt["status"]) == flags[key]
        original_a = credentials["disable-"+rec["mode"]+"-A"]["stack"]
        assert target == original_a[0 if rec["mode"] == "disable-child" else -1]
        if receipt["status"] == "success":
            grant = credentials[rec["adminCredential"]]["stack"]
            assert len(grant)==1 and grant[0]["delegator"].lower()==target["delegator"].lower()
            assert rec["data"].lower()[2:] in tx["data"].lower()
            assert any(len(log["topics"]) == 4 and log["address"].lower() == chain["manager"].lower()
                       and log["topics"][1:]==[rec["targetHash"],"0x"+word(target["delegator"]),
                                               "0x"+word(target["delegate"])]
                       for log in receipt["logs"])
        else:
            assert tx["data"]==rec["data"] and not receipt["logs"] and rec["adminCredential"] is None
        actual_management[key]=True
    assert set(actual_management)==set(flags)
    disable = {}
    for mode in DISABLE_MODES:
        group = [rowmap[("disabled-grants",f"{mode}/{branch}/{q}")] for branch,q in product(("A","B","repaired"),("0","91"))]
        assert len({r["before"]["hash"] for r in group})==1
        disable[mode] = {branch:[rowmap[("disabled-grants",f"{mode}/{branch}/{q}")]["tx"]["receipt"]["status"]
                                 for q in ("0","91")] for branch in ("A","B","repaired")}
    orders = {
        "repeat-zero": [("named",0),("named",0)],
        "two-spenders": [("named",0),("second",0)],
        "zero-then-positive": [("named",0),("named",91)],
        "positive-then-zero": [("named",91),("named",0)],
        "zero-then-outside-positive": [("named",0),("outside",91)],
    }
    batches = read(folder / "batches.json")
    batch_map = {(r["name"],r["order"]):r for r in batches}
    assert len(batch_map)==len(batches)==20
    batch_variants = ("original","amount","both","exact")
    assert set(batch_map)==set(product(batch_variants,orders))
    assert len({r["before"]["hash"] for r in batches})==1
    batch_stats = {}
    for (name,order),rec in batch_map.items():
        calls = orders[order]
        batch_expected = all(expect_for("matrix",("positive",name,spender,str(q))) for spender,q in calls)
        assert rec["expected"] == batch_expected
        tx = rec["tx"]
        receipt = tx["receipt"]
        assert tx["hash"] == receipt["transactionHash"]
        assert receipt["blockHash"] == rec["after"]["hash"]
        assert int(rec["after"]["number"]) == int(rec["before"]["number"]) + 1
        assert tx["to"].lower() == chain["manager"].lower()
        assert tx["from"].lower() == credentials[rec["credential"]]["sender"].lower()
        assert receipt["status"] == ("success" if batch_expected else "reverted")
        assert [(c["spender"],int(c["amount"])) for c in rec["calls"]] == calls
        assert len(rec["calls"])==2
        for call,(spender,q) in zip(rec["calls"],calls):
            assert call["data"].lower()==encode(APPROVE,addr[spender],q)
            assert (chain["tokenA"].lower()[2:]+word(0)+call["data"].lower()[2:]) in tx["data"].lower()
        logged = [(log["topics"][2],int(log["data"],16)) for log in receipt["logs"]
                  if log["address"].lower() == chain["tokenA"].lower() and len(log["topics"]) == 3
                  and log["topics"][:2] == [APPROVAL_EVENT,"0x"+word(chain["root"])]]
        assert logged==([("0x"+word(addr[spender]),q) for spender,q in calls] if batch_expected else [])
        if not batch_expected:
            assert not receipt["logs"]
        assert rec["before"]["balances"] == rec["after"]["balances"]
        allowances = {k:int(v) for k,v in rec["before"]["allowances"].items()}
        assert allowances == {"named":37,"second":13,"outside":23,"otherToken":17,"otherOwner":29}
        if batch_expected:
            allowances.update(calls)
        assert allowances == {k:int(v) for k,v in rec["after"]["allowances"].items()}
        batch_stats.setdefault(name,{})[order] = {"status":receipt["status"],"named":allowances["named"],
                                                  "second":allowances["second"],"outside":allowances["outside"]}
    n_batches_ok = sum(r["tx"]["receipt"]["status"] == "success" for r in batches)
    summary = {"management_transactions":len(management),"transactions":len(rows),"distinct_transaction_hashes":distinct_hashes,"preserved_key_comparisons":keys_preserved,
               "by_suite":{suite:{"total":len(ids),"success":accepts[suite]} for suite,ids in expected.items()},
               "matrix":matrix_stats,"branches":branch_stats,"lifecycle":lifecycle,"gas":gas,"disable":disable,
               "ordered_batches":{"total":len(batches),"success":n_batches_ok,"by_case":batch_stats}}
    if write:
        with (folder/"summary.csv").open("w",encoding="utf-8",newline="") as f:
            writer = csv.DictWriter(f,fieldnames=list(output[0]))
            writer.writeheader()
            writer.writerows(output)
        (folder/"audit.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(summary,indent=2))


if __name__ == "__main__":
    verify(Path(sys.argv[1]), "--write" in sys.argv)
