import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createServer } from 'node:net';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const [labPath, anvilPath, outputPath] = process.argv.slice(2).map(p => path.resolve(p));
const require = createRequire(process.env.I08_DEPENDENCY_ROOT
  ? path.join(path.resolve(process.env.I08_DEPENDENCY_ROOT), 'package.json') : import.meta.url);
const { createPublicClient, createWalletClient, encodeFunctionData, http, defineChain,
  bytesToHex, pad, toHex, parseAbi, parseAbiItem, decodeEventLog, keccak256 } = require('viem');
const { mnemonicToAccount } = require('viem/accounts');
const { createDelegation, createExecution, ExecutionMode, Implementation,
  signDelegation, toMetaMaskSmartAccount } = require('@metamask/smart-accounts-kit');
const { createCaveatBuilder, deploySmartAccountsEnvironment, overrideDeployedEnvironment, hashDelegation } =
  require('@metamask/smart-accounts-kit/utils');
const { DelegationManager } = require('@metamask/smart-accounts-kit/contracts');

process.env.LAB_LIBRARY_ONLY = '1';
process.env.LAB_AGENT_WORKER = '1';
process.env.LAB_ROOT = labPath;
process.env.LAB_DATA_DIR = path.join(outputPath, 'internal');
const labBundle = path.join(labPath, 'dist', 'server.mjs');
const { ChainLab } = await import(pathToFileURL(labBundle).href);
const probe = createServer();
await new Promise((res, rej) => { probe.once('error', rej); probe.listen(0, '127.0.0.1', res); });
const rpcUrl = 'http://127.0.0.1:' + probe.address().port;
await new Promise((res, rej) => probe.close(e => e ? rej(e) : res()));
const chainId = 31337;
const lab = new ChainLab({ rpcUrl, anvilPath, dataDir: path.join(outputPath, 'baseline') });
const chain = defineChain({ id: chainId, name: 'Local Anvil', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
  rpcUrls: { default: { http: [rpcUrl] } } });
const client = createPublicClient({ chain, transport: http(rpcUrl), cacheTime: 0, pollingInterval: 30 });

const rpc = (method, params = []) => client.request({ method, params });
const abi = parseAbi([
  'function approve(address spender,uint256 value) returns (bool)',
  'function transfer(address to,uint256 value) returns (bool)',
  'function transferFrom(address from,address to,uint256 value) returns (bool)',
  'function mint(address to,uint256 value)',
  'function allowance(address owner,address spender) view returns (uint256)',
  'function balanceOf(address owner) view returns (uint256)',
  'event Approval(address indexed owner,address indexed spender,uint256 value)',
]);
const approvalEvent = parseAbiItem('event Approval(address indexed owner,address indexed spender,uint256 value)');
const expectedMax = (1n << 256n) - 1n;
// Default public Anvil test accounts. No external wallet or RPC is used.
const localAccount = index => mnemonicToAccount('test test test test test test test test test test test junk', { addressIndex: index });
const [admin, rootOwner, coordOwner, extraOwner, leafA, leafB, named, second, outside] =
  Array.from({ length: 9 }, (_, i) => localAccount(i));
const wallet = createWalletClient({ account: admin, chain, transport: http(rpcUrl), pollingInterval: 30 });
const toJson = value => JSON.stringify(value, (_, x) => typeof x === 'bigint' ? x.toString() : x);
const equal = (a,b) => a?.toLowerCase() === b?.toLowerCase();
const save = async (name, value) => writeFile(path.join(outputPath, name), toJson(value) + '\n');
const sha = async file => createHash('sha256').update(await readFile(file)).digest('hex');
const cases = [];
const credentials = {};
const setup = [];
let root, coordinator, extra, env, tokenA, tokenB, serial = 1;
let longExpiry;
const spenders = { named, second, outside };
const tokenData = (functionName, args) => encodeFunctionData({ abi, functionName, args });
const approve = (spender, amount) => tokenData('approve', [spender.address, amount]);
const execute = (token, data) => createExecution({ target: token, value: 0n, callData: data });
const allowance = (token, owner, spender, blockNumber) => client.readContract({
  address: token, abi, functionName: 'allowance', args: [owner, spender], blockNumber,
});
const balance = (token, account, blockNumber) => client.readContract({
  address: token, abi, functionName: 'balanceOf', args: [account], blockNumber,
});

async function transact({ account, to, data, gas = 3_000_000n }) {
  const hash = await wallet.sendTransaction({ account, to, data, gas });
  const receipt = await client.waitForTransactionReceipt({ hash });
  return { hash, from: account.address, to, data, receipt };
}

async function hybrid(owner, deploySalt) {
  const account = await toMetaMaskSmartAccount({ client, implementation: Implementation.Hybrid,
    deployParams: [owner.address, [], [], []], deploySalt, signer: { account: owner } });
  if (!(await account.isDeployed())) {
    const { factory, factoryData } = await account.getFactoryArgs();
    const tx = await transact({ account: admin, to: factory, data: factoryData });
    assert.equal(tx.receipt.status, 'success');
    setup.push(tx);
  }
  assert.ok(await account.isDeployed());
  return account;
}

function caveats(name, token, amount = 0n) {
  if (name === 'original') return [];
  const builder = createCaveatBuilder(env);
  if (name === 'amount' || name === 'both') {
    builder.addCaveat('allowedCalldata', { startIndex: 36, value: toHex(amount, { size: 32 }) });
  }
  if (name === 'spender' || name === 'both') {
    builder.addCaveat('allowedCalldata', { startIndex: 4, value: pad(named.address) });
  }
  if (name === 'exact') builder.addCaveat('exactExecution', { execution: execute(token, approve(named, amount)) });
  return builder.build();
}

async function signed({ from, to, owner, parent, scope, conditions = [] }) {
  const delegation = createDelegation({ environment: env, from: from.address, to: to.address,
    salt: toHex(serial++, { size: 32 }), ...(parent ? { parentDelegation: parent } : { scope }),
    caveats: conditions });
  const signature = await signDelegation({ privateKey: bytesToHex(owner.getHdKey().privKeyBytes),
    delegation, delegationManager: env.DelegationManager, chainId });
  return { ...delegation, signature };
}

async function makeRoot(name, delegate, token, amount, expiry) {
  const lifetime = createCaveatBuilder(env)
    .addCaveat('limitedCalls', { limit: 10 })
    .addCaveat('timestamp', { afterThreshold: 0, beforeThreshold: expiry ?? longExpiry }).build();
  return signed({ from: root, to: delegate, owner: rootOwner,
    scope: { type: 'functionCall', targets: [token], selectors: ['approve(address,uint256)'] },
    conditions: [...lifetime, ...caveats(name, token, amount)] });
}

async function makeChild(from, owner, to, parent, conditions = []) {
  return signed({ from, to, owner, parent, conditions: [
    ...createCaveatBuilder(env).addCaveat('limitedCalls', { limit: 5 }).build(), ...conditions,
  ] });
}

function register(id, stack, sender) {
  assert.ok(!credentials[id]);
  credentials[id] = { stack, sender: sender.address };
  return { id, stack, sender };
}

async function makePath(id, { name = 'original', token = tokenA, depth = 2, amount = 0n,
  expiry, leaf = leafA, child = 'original' } = {}) {
  const parent = await makeRoot(name, depth === 1 ? leaf : coordinator, token, amount, expiry);
  if (depth === 1) return register(id, [parent], leaf);
  const middle = await makeChild(coordinator, coordOwner, depth === 2 ? leaf : extra, parent, caveats(child, token));
  if (depth === 2) return register(id, [middle, parent], leaf);
  const terminal = await makeChild(extra, extraOwner, leaf, middle);
  return register(id, [terminal, middle, parent], leaf);
}

function redemption(grant, token, data) {
  return DelegationManager.encode.redeemDelegations({ delegations: [grant.stack],
    modes: [ExecutionMode.SingleDefault], executions: [[execute(token, data)]] });
}

async function blockState() {
  const block = await client.getBlock({ blockTag: 'latest' });
  const b = block.number;
  const ids = ['named','second','outside'];
  const vals = await Promise.all([
    ...ids.map(id => allowance(tokenA,root.address,spenders[id].address,b)),
    allowance(tokenB,root.address,named.address,b),
    allowance(tokenA,coordinator.address,named.address,b),
    balance(tokenA,root.address,b),
    ...ids.map(id => balance(tokenA,spenders[id].address,b)),
  ]);
  const [namedVal,secondVal,outsideVal,otherToken,otherOwner,rootBalance,namedBalance,secondBalance,outsideBalance] = vals;
  return { number: b, hash: block.hash, timestamp: block.timestamp,
    allowances: { named: namedVal, second: secondVal, outside: outsideVal, otherToken, otherOwner },
    balances: { root: rootBalance, named: namedBalance, second: secondBalance, outside: outsideBalance } };
}

async function redeem({ id, suite, grant, spender = 'named', amount, expect, token = tokenA,
  data = approve(spenders[spender], amount), affects = true, context = {} }) {
  const before = await blockState();
  const sent = await transact({ account: grant.sender, to: env.DelegationManager,
    data: redemption(grant, token, data) });
  const after = await blockState();
  const { receipt } = sent;
  const args = { token, spender, amount, data };
  const approvals = receipt.logs.flatMap(log => {
    if (!equal(log.address, token)) return [];
    try { return [decodeEventLog({ abi: [approvalEvent], data: log.data, topics: log.topics }).args]; }
    catch { return []; }
  });
  const row = { id, suite, credential: grant.id, context, request: args, expect,
    before, after, tx: sent, approvals };
  cases.push(row);
  assert.equal(receipt.status, expect ? 'success' : 'reverted', id);
  assert.equal(after.hash, receipt.blockHash, id);
  for (const [key, value] of Object.entries(before.allowances)) {
    assert.equal(after.allowances[key], expect && affects && key === spender ? amount : value, id + ': ' + key);
  }
  assert.deepEqual(before.balances, after.balances, id);
  assert.equal(approvals.length, expect && affects ? 1 : 0, id);
  if (expect && affects) {
    assert.ok(equal(approvals[0].owner, root.address) && equal(approvals[0].spender, spenders[spender].address), id);
    assert.equal(approvals[0].value, amount, id);
  }
  if (!expect) assert.equal(receipt.logs.length, 0, id);
  return row;
}

async function seed(grantA, grantB, profile) {
  const transactions = [];
  for (const [token, spender, amount, grant] of [
    ...Object.entries(profile).map(([id, val]) => [tokenA, spenders[id], val, grantA]),
    [tokenB, named, 17n, grantB],
  ]) {
    const tx = await transact({ account: grant.sender, to: env.DelegationManager,
      data: redemption(grant, token, approve(spender, amount)) });
    assert.equal(tx.receipt.status, 'success');
    transactions.push(tx);
  }
  setup.push({ profile, transactions, state: await blockState() });
  for (const [id, q] of Object.entries(profile)) {
    assert.equal(setup.at(-1).state.allowances[id], q);
  }
  assert.equal(setup.at(-1).state.allowances.otherToken, 17n);
}

async function sendSpend(id, expect) {
  const before = await blockState();
  const tx = await transact({ account: named, to: tokenA,
    data: tokenData('transferFrom', [root.address, named.address, 55n]), gas: 200_000n });
  const after = await blockState();
  cases.push({ id, suite: 'lifecycle', request: { action: 'spend', amount: 55n, token: tokenA },
    expect, before, after, tx });
  assert.equal(tx.receipt.status, expect ? 'success' : 'reverted', id);
  assert.equal(tx.receipt.blockHash, after.hash, id);
  assert.equal(after.balances.named - before.balances.named, expect ? 55n : 0n, id);
  assert.equal(after.balances.root - before.balances.root, expect ? -55n : 0n, id);
  for (const [key, value] of Object.entries(before.allowances)) {
    assert.equal(after.allowances[key], expect && key === 'named' ? value - 55n : value, id);
  }
}

await mkdir(outputPath, { recursive: true });
try {
  await lab.start();
  assert.equal(await client.getChainId(), chainId);
  ({ tokenA, tokenB } = lab.env().contracts);
  env = await deploySmartAccountsEnvironment(wallet, client, chain);
  overrideDeployedEnvironment(chainId, '1.3.0', env);
  root = await hybrid(rootOwner, '0x11');
  coordinator = await hybrid(coordOwner, '0x22');
  extra = await hybrid(extraOwner, '0x33');
  longExpiry = Number((await client.getBlock()).timestamp) + 86400;
  const mint = await transact({ account: admin, to: tokenA, data: tokenData('mint', [root.address, 1_000_000n]) });
  assert.equal(mint.receipt.status,'success'); setup.push(mint);
  const seeds = {
    A: await makePath('setup-A', { depth: 1, token: tokenA }),
    B: await makePath('setup-B', { depth: 1, token: tokenB }),
  };
  const otherOwner = register('setup-other-owner', [await signed({
    from: coordinator, to: leafA, owner: coordOwner,
    scope: { type:'functionCall',targets:[tokenA],selectors:['approve(address,uint256)'] },
  })], leafA);
  const otherOwnerTx = await transact({ account: leafA, to:env.DelegationManager,
    data:redemption(otherOwner,tokenA,approve(named,29n)) });
  assert.equal(otherOwnerTx.receipt.status,'success');
  setup.push(otherOwnerTx);
  assert.equal((await blockState()).allowances.otherOwner,29n);
  const profiles = { positive: { named:37n,second:13n,outside:23n },
    empty: { named:0n,second:0n,outside:0n },
    mixed: { named:1n,second:0n,outside:41n } };
  const encodings = ['original', 'spender', 'amount', 'both', 'exact'];
  const grants = Object.fromEntries(await Promise.all(encodings.map(async name => [name,
    await makePath('matrix-' + name, { name })])));
  const classify = (name, spender, q) => (q === 0n || !['amount','both','exact'].includes(name)) &&
    (spender === 'named' || !['spender','both','exact'].includes(name));
  let start = await rpc('evm_snapshot');
  const reset = async () => {
    assert.equal(await rpc('evm_revert', [start]), true);
    start = await rpc('evm_snapshot');
  };
  const seedProfile = async name => { await reset(); await seed(seeds.A, seeds.B, profiles[name]); };
  const isolated = async fn => {
    const snap = await rpc('evm_snapshot');
    try { return await fn(); }
    finally { assert.equal(await rpc('evm_revert', [snap]), true); }
  };
  const smoke = process.env.I08_SMOKE === '1';
  for (const profile of smoke ? ['positive'] : Object.keys(profiles)) {
    await seedProfile(profile);
    const baseBlock = (await blockState()).hash;
    for (const name of encodings) for (const spender of Object.keys(spenders))
      for (const amount of smoke ? [0n,91n] : [0n,1n,36n,37n,91n,expectedMax]) {
        const row = await isolated(() => redeem({ id: [profile,name,spender,amount].join('/'),
          suite: 'matrix', grant: grants[name], spender, amount,
          expect: classify(name,spender,amount), context: { profile, name } }));
        assert.equal(row.before.hash, baseBlock);
      }
    console.log('matrix', profile, cases.length);
  }

  await seedProfile('positive');
  for (const name of encodings) for (const mismatch of ['token','selector']) {
    await isolated(() => redeem({ id: name + '/' + mismatch, suite: 'scope-control', grant: grants[name], amount: 0n,
      ...(mismatch === 'token' ? {token:tokenB} : { data:tokenData('transfer',[named.address,0n]) }),
      expect: false, affects: false, context: { name, mismatch } }));
  }
  console.log('scope controls', cases.length);

  const branchModes = { original:[false,false,false], root:[true,false,false],
    oneChild:[false,true,false], bothChildren:[false,true,true] };
  for (const [mode, [guardRoot, guardA, guardB]] of Object.entries(branchModes)) {
    const parent = await makeRoot(guardRoot ? 'amount' : 'original',coordinator,tokenA);
    for (const [branch, leaf, guard] of [['A',leafA,guardA],['B',leafB,guardB]]) {
      const child = await makeChild(coordinator,coordOwner,leaf,parent,guard ? caveats('amount',tokenA) : []);
      const grant = register('branches-' + mode + '-' + branch,[child,parent],leaf);
      for (const amount of [0n,91n]) await isolated(() => redeem({ id: [mode,branch,amount].join('/'),
        suite:'branches', grant, amount, expect: amount===0n || (!guardRoot && !guard), context: {mode,branch} }));
    }
  }
  console.log('branches', cases.length);

  const exact20 = await makePath('fixed20', { name:'exact',amount:20n });
  for (const profile of ['positive','empty']) {
    await seedProfile(profile);
    for (const spender of ['named','second']) for (const amount of [0n,20n,21n])
      await isolated(() => redeem({ id:[profile,spender,amount].join('/'), suite:'fixed20',
        grant:exact20, spender,amount,expect:spender==='named' && amount===20n,context:{profile} }));
  }
  console.log('fixed amount', cases.length);

  const costGrants = {};
  for (const depth of [1,2,3]) for (const name of ['original','amount','both','exact']) {
    costGrants[depth + '/' + name] = await makePath('cost-' + depth + '-' + name,{name,depth});
  }
  for (const profile of Object.keys(profiles)) {
    await seedProfile(profile);
    for (const [nameKey,grant] of Object.entries(costGrants)) {
      const [depth,name] = nameKey.split('/');
      await isolated(() => redeem({ id:profile+'/'+nameKey,suite:'cost',grant,amount:0n,
        expect:true,context:{profile,depth:Number(depth),name} }));
    }
  }
  console.log('gas controls', cases.length);

  for (const mode of ['old-only','repaired-only','coexist','expired-old']) {
    await seedProfile('positive');
    const expires = Number((await client.getBlock()).timestamp) + 120;
    const old = await makePath('lifecycle-' + mode + '-old', {expiry:expires});
    const repair = await makePath('lifecycle-' + mode + '-repair',{name:'amount'});
    const revoking = mode === 'old-only' ? old : repair;
    await redeem({ id:mode+'/revoke', suite:'lifecycle', grant:revoking, amount:0n, expect:true });
    await sendSpend(mode+'/first-spend',false);
    if (mode==='expired-old') {
      await rpc('evm_setNextBlockTimestamp',[expires+1]);
      await rpc('evm_mine');
    }
    const reapply = mode === 'repaired-only' ? repair : old;
    const canRaise = mode==='old-only' || mode==='coexist';
    await redeem({ id:mode+'/reapply', suite:'lifecycle', grant:reapply, amount:91n, expect:canRaise });
    await sendSpend(mode+'/second-spend',canRaise);
  }
  console.log('lifecycle', cases.length);

  const management = [];
  const disabled = delegation => DelegationManager.read.disabledDelegations({
    client, contractAddress: env.DelegationManager, delegationHash: hashDelegation(delegation),
  });
  async function manage(mode, operation, target, issuer, issuerOwner) {
    const beforeFlag = await disabled(target);
    const data = DelegationManager.encode[operation]({ delegation: target });
    let tx, adminCredential = null;
    if (issuer) {
      const grant = await signed({ from: issuer, to: leafA, owner: issuerOwner,
        scope: { type:'functionCall',targets:[env.DelegationManager],selectors:[data.slice(0,10)] },
        conditions: createCaveatBuilder(env).addCaveat('exactExecution', {
          execution: execute(env.DelegationManager, data),
        }).build(),
      });
      adminCredential = register('admin-' + mode + '-' + operation, [grant], leafA).id;
      tx = await transact({ account: leafA, to: env.DelegationManager,
        data: redemption({stack:[grant]},env.DelegationManager,data) });
    } else {
      tx = await transact({ account: leafA, to: env.DelegationManager, data });
    }
    const afterFlag = await disabled(target);
    assert.equal(tx.receipt.status, issuer ? 'success' : 'reverted');
    assert.equal(afterFlag, issuer ? operation==='disableDelegation' : beforeFlag);
    management.push({ mode, operation, targetHash: hashDelegation(target), target,
      beforeFlag, afterFlag, data, tx, adminCredential });
  }

  for (const mode of ['untouched','disable-child','disable-root','wrong-issuer','reenable-root']) {
    await seedProfile('positive');
    const parent = await makeRoot('original',coordinator,tokenA);
    const childA = await makeChild(coordinator,coordOwner,leafA,parent);
    const childB = await makeChild(coordinator,coordOwner,leafB,parent);
    const paths = { A:register('disable-'+mode+'-A',[childA,parent],leafA),
      B:register('disable-'+mode+'-B',[childB,parent],leafB),
      repaired:await makePath('disable-'+mode+'-repair',{name:'amount'}) };
    if (mode==='disable-child') await manage(mode,'disableDelegation',childA,coordinator,coordOwner);
    if (mode==='disable-root' || mode==='reenable-root')
      await manage(mode,'disableDelegation',parent,root,rootOwner);
    if (mode==='wrong-issuer') await manage(mode,'disableDelegation',parent);
    if (mode==='reenable-root') await manage(mode,'enableDelegation',parent,root,rootOwner);
    const startBlock = (await blockState()).hash;
    for (const [branch,grant] of Object.entries(paths)) for (const amount of [0n,91n]) {
      const expect = branch==='repaired' ? amount===0n
        : mode!=='disable-root' && !(mode==='disable-child' && branch==='A');
      const row = await isolated(() => redeem({ id:[mode,branch,amount].join('/'), suite:'disabled-grants',
        grant, amount, expect, context:{mode,branch} }));
      assert.equal(row.before.hash,startBlock);
    }
  }
  await save('management.json',management);
  console.log('manager disable controls', cases.length);

  const batches = [];
  const orders = {
    'repeat-zero': [['named',0n],['named',0n]],
    'two-spenders': [['named',0n],['second',0n]],
    'zero-then-positive': [['named',0n],['named',91n]],
    'positive-then-zero': [['named',91n],['named',0n]],
    'zero-then-outside-positive': [['named',0n],['outside',91n]],
  };
  await seedProfile('positive');
  const batchStart = (await blockState()).hash;
  for (const name of ['original','amount','both','exact']) {
    const grant = grants[name];
    for (const [order,requests] of Object.entries(orders)) await isolated(async () => {
      const before = await blockState();
      assert.equal(before.hash,batchStart);
      const expected = requests.every(([spender,q]) => classify(name,spender,q));
      const calls = requests.map(([spender,amount]) => ({ spender, amount,
        data:approve(spenders[spender],amount) }));
      const data = DelegationManager.encode.redeemDelegations({
        delegations:calls.map(() => grant.stack),
        modes:calls.map(() => ExecutionMode.SingleDefault),
        executions:calls.map(call => [execute(tokenA,call.data)]),
      });
      const tx = await transact({ account:grant.sender,to:env.DelegationManager,data,gas:5_000_000n });
      const after = await blockState();
      assert.equal(tx.receipt.status,expected ? 'success' : 'reverted');
      assert.equal(after.hash,tx.receipt.blockHash);
      const projected = {...before.allowances};
      if (expected) for (const [spender,q] of requests) projected[spender]=q;
      assert.deepEqual(after.allowances,projected);
      assert.deepEqual(after.balances,before.balances);
      const approvals = tx.receipt.logs.flatMap(log => {
        if (!equal(log.address,tokenA)) return [];
        try { return [decodeEventLog({abi:[approvalEvent],data:log.data,topics:log.topics}).args]; }
        catch { return []; }
      });
      assert.equal(approvals.length,expected ? 2 : 0);
      if (expected) for (const [i,[spender,q]] of requests.entries()) {
        assert.ok(equal(approvals[i].owner,root.address) && equal(approvals[i].spender,spenders[spender].address));
        assert.equal(approvals[i].value,q);
      }
      if (!expected) assert.equal(tx.receipt.logs.length,0);
      batches.push({name,order,calls,credential:grant.id,expected,before,after,tx,approvals});
    });
  }
  await save('batches.json',batches);
  console.log('ordered manager batches',batches.length);

  const contracts = { tokenA,tokenB,root:root.address,coordinator:coordinator.address,intermediate:extra.address,
    manager:env.DelegationManager };
  const runtimeCodeHashes = Object.fromEntries(await Promise.all(Object.entries(contracts).map(async ([key,address]) =>
    [key,keccak256(await client.getCode({address}))])));
  await save('manifest.json',{ schema:1, smoke, labTag:'V0.16.0',
    labCommit:'db2899fb2e0ec09771f51f1ff1e88ae30725eb50', sdkVersion:'1.6.0', viemVersion:'2.51.3',
    anvil:lab.env().versions.anvil, node:process.version, labServerSha256:await sha(labBundle),
    anvilSha256:await sha(anvilPath), chainId, contracts, runtimeCodeHashes, enforcers:env.caveatEnforcers,
    spenders:Object.fromEntries(Object.entries(spenders).map(([id,a])=>[id,a.address])),
    delegates:{ A:leafA.address,B:leafB.address }, profiles, total:cases.length });
  await save('credentials.json',credentials);
  await save('setup.json',setup);
  await writeFile(path.join(outputPath,'cases.jsonl'), cases.map(toJson).join('\n') + '\n');
} catch (error) {
  await save('partial-cases.json',cases);
  throw error;
} finally {
  await lab.stop();
}
